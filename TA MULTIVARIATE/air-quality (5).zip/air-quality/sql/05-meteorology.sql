-- Idempotent meteorology schema migration.
-- Executed by pipeline-control-init on every Docker Compose startup.
-- All timestamps use TIMESTAMP WITHOUT TIME ZONE in Asia/Jakarta wall-clock time,
-- matching staging.air_quality_raw and warehouse.dim_time.

CREATE SCHEMA IF NOT EXISTS staging;
CREATE SCHEMA IF NOT EXISTS warehouse;

CREATE TABLE IF NOT EXISTS staging.meteorology_raw (
    source_id BIGSERIAL PRIMARY KEY,
    city VARCHAR(100) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    valid_at TIMESTAMP NOT NULL,
    temperature_2m DOUBLE PRECISION,
    relative_humidity_2m DOUBLE PRECISION,
    wind_speed_10m DOUBLE PRECISION,
    wind_direction_10m DOUBLE PRECISION,
    precipitation DOUBLE PRECISION,
    boundary_layer_height DOUBLE PRECISION,
    shortwave_radiation DOUBLE PRECISION,
    source_name VARCHAR(100) NOT NULL DEFAULT 'Open-Meteo Historical Forecast API',
    source_model VARCHAR(50) NOT NULL DEFAULT 'ecmwf_ifs',
    ingested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (city, valid_at)
);

CREATE INDEX IF NOT EXISTS idx_meteorology_raw_valid_at
    ON staging.meteorology_raw(valid_at);
CREATE INDEX IF NOT EXISTS idx_meteorology_raw_city_valid_at
    ON staging.meteorology_raw(city, valid_at);

-- Spark recreates this clean table on each transformation run.
CREATE TABLE IF NOT EXISTS staging.meteorology_clean (
    city VARCHAR(100) NOT NULL,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    valid_at TIMESTAMP NOT NULL,
    temperature_2m DOUBLE PRECISION,
    relative_humidity_2m DOUBLE PRECISION,
    wind_speed_10m DOUBLE PRECISION,
    wind_direction_10m DOUBLE PRECISION,
    precipitation DOUBLE PRECISION,
    boundary_layer_height DOUBLE PRECISION,
    shortwave_radiation DOUBLE PRECISION,
    source_name VARCHAR(100),
    source_model VARCHAR(50),
    ingested_at TIMESTAMPTZ,
    processed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS warehouse.fact_meteorology (
    location_key BIGINT NOT NULL REFERENCES warehouse.dim_location(location_key),
    time_key BIGINT NOT NULL REFERENCES warehouse.dim_time(time_key),
    temperature_2m DOUBLE PRECISION,
    relative_humidity_2m DOUBLE PRECISION,
    wind_speed_10m DOUBLE PRECISION,
    wind_direction_10m DOUBLE PRECISION,
    precipitation DOUBLE PRECISION,
    boundary_layer_height DOUBLE PRECISION,
    shortwave_radiation DOUBLE PRECISION,
    source_model VARCHAR(50) NOT NULL DEFAULT 'ecmwf_ifs',
    loaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (location_key, time_key)
);

CREATE INDEX IF NOT EXISTS idx_fact_meteorology_time
    ON warehouse.fact_meteorology(time_key);
CREATE INDEX IF NOT EXISTS idx_fact_meteorology_location
    ON warehouse.fact_meteorology(location_key);

-- Convenience view for the later scatter-plot and correlation analytics.
-- It contains only city/timestamp pairs present in both fact tables.
CREATE OR REPLACE VIEW warehouse.vw_air_quality_meteorology AS
SELECT
    l.city,
    t.valid_at,
    aq.pm2_5,
    aq.pm10,
    aq.carbon_monoxide,
    aq.nitrogen_dioxide,
    aq.european_aqi,
    met.temperature_2m,
    met.relative_humidity_2m,
    met.wind_speed_10m,
    met.wind_direction_10m,
    met.precipitation,
    met.boundary_layer_height,
    met.shortwave_radiation,
    met.source_model AS meteorology_source_model
FROM warehouse.fact_air_quality aq
JOIN warehouse.fact_meteorology met
  ON met.location_key = aq.location_key
 AND met.time_key = aq.time_key
JOIN warehouse.dim_location l
  ON l.location_key = aq.location_key
JOIN warehouse.dim_time t
  ON t.time_key = aq.time_key;

COMMENT ON TABLE staging.meteorology_raw IS
    'Raw hourly meteorology from Open-Meteo Historical Forecast API (ECMWF IFS).';
COMMENT ON TABLE warehouse.fact_meteorology IS
    'Hourly meteorology fact table sharing dim_location and dim_time with air quality.';
COMMENT ON VIEW warehouse.vw_air_quality_meteorology IS
    'Timestamp-aligned air quality and meteorology records for exploratory analytics.';
