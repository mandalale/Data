-- Runtime controls for the three independent pipeline paths.
-- This migration is idempotent and is executed by the pipeline-control-init
-- Compose service on every `docker compose up` (safe with persistent volumes).

\connect air_quality_dw;

CREATE SCHEMA IF NOT EXISTS control;

CREATE TABLE IF NOT EXISTS control.pipeline_settings (
    id SMALLINT PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    streaming_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    batch_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    ml_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by VARCHAR(100) NOT NULL DEFAULT 'system'
);

INSERT INTO control.pipeline_settings (
    id, streaming_enabled, batch_enabled, ml_enabled, updated_at, updated_by
)
VALUES (1, TRUE, TRUE, TRUE, NOW(), 'system')
ON CONFLICT (id) DO NOTHING;
