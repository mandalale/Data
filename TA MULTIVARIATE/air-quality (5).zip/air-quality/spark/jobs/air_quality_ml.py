#!/usr/bin/env python3
"""Train/evaluate PM2.5 models and save six-hour forecasts.

Input:
  staging.air_quality_raw

Outputs:
  ml.model_metrics
  ml.air_quality_forecast

`valid_at` is a TIMESTAMP WITHOUT TIME ZONE containing Asia/Jakarta local-clock
labels from Open-Meteo. The script deliberately preserves those wall-clock
timestamps and excludes future rows from training.
"""
from __future__ import annotations

import logging
import os
import sys
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
from sklearn.ensemble import RandomForestRegressor

# Phase 4 decision: PM2.5 is the only prediction target and model input.
PARAMETERS = ["pm2_5"]
LAGS = [0, 1, 2, 3, 6, 12, 24]
HORIZONS = range(1, 7)
MIN_HISTORY_ROWS = 200
MIN_TRAIN_ROWS = 100
MIN_TEST_ROWS = 10
RF_TREES = 100

logging.basicConfig(
    level=os.getenv("ML_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [E9-ML] %(message)s",
)
log = logging.getLogger("air_quality_ml")


def db_connection():
    """Connect to the project's PostgreSQL data warehouse."""
    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=int(os.getenv("DW_PORT", "5432")),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=10,
    )


def ensure_ml_tables(conn) -> None:
    """Create ML output tables and add PM2.5 candidate columns to existing tables."""
    ddl = """
    CREATE SCHEMA IF NOT EXISTS ml;

    CREATE TABLE IF NOT EXISTS ml.model_metrics (
        metric_id BIGSERIAL PRIMARY KEY,
        evaluated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        run_id TEXT NOT NULL,
        city VARCHAR(100) NOT NULL,
        parameter_name VARCHAR(50) NOT NULL,
        horizon_hours SMALLINT NOT NULL CHECK (horizon_hours BETWEEN 1 AND 6),
        model_name VARCHAR(50) NOT NULL,
        mae DOUBLE PRECISION NOT NULL,
        rmse DOUBLE PRECISION NOT NULL,
        train_rows INTEGER NOT NULL,
        test_rows INTEGER NOT NULL,
        is_selected BOOLEAN NOT NULL,
        evaluation_start TIMESTAMP WITHOUT TIME ZONE,
        evaluation_end TIMESTAMP WITHOUT TIME ZONE
    );

    CREATE INDEX IF NOT EXISTS idx_ml_metrics_city_evaluated
        ON ml.model_metrics (city, evaluated_at DESC);

    CREATE TABLE IF NOT EXISTS ml.air_quality_forecast (
        city VARCHAR(100) NOT NULL,
        forecast_origin TIMESTAMP WITHOUT TIME ZONE NOT NULL,
        forecast_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
        horizon_hours SMALLINT NOT NULL CHECK (horizon_hours BETWEEN 1 AND 6),
        parameter_name VARCHAR(50) NOT NULL,
        predicted_value DOUBLE PRECISION NOT NULL,
        selected_model VARCHAR(50) NOT NULL,
        holdout_mae DOUBLE PRECISION NOT NULL,
        holdout_rmse DOUBLE PRECISION NOT NULL,
        random_forest_value DOUBLE PRECISION,
        persistence_value DOUBLE PRECISION,
        seasonal_naive_value DOUBLE PRECISION,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        PRIMARY KEY (city, forecast_origin, forecast_at, parameter_name)
    );

    ALTER TABLE ml.air_quality_forecast
        ADD COLUMN IF NOT EXISTS random_forest_value DOUBLE PRECISION,
        ADD COLUMN IF NOT EXISTS persistence_value DOUBLE PRECISION,
        ADD COLUMN IF NOT EXISTS seasonal_naive_value DOUBLE PRECISION;

    CREATE INDEX IF NOT EXISTS idx_ml_forecast_city_at
        ON ml.air_quality_forecast (city, forecast_at DESC);
    """
    with conn.cursor() as cur:
        cur.execute(ddl)
    conn.commit()


def load_historical_data(conn) -> pd.DataFrame:
    """Read observed PM2.5 history only; keep Asia/Jakarta wall-clock timestamps."""
    sql = """
        SELECT city, valid_at, pm2_5
        FROM staging.air_quality_raw
        WHERE valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
        ORDER BY city, valid_at
    """
    with conn.cursor() as cur:
        cur.execute(sql)
        rows = cur.fetchall()
        columns = [column[0] for column in cur.description]

    data = pd.DataFrame(rows, columns=columns)
    if data.empty:
        raise RuntimeError("staging.air_quality_raw has no historical rows.")

    data["valid_at"] = pd.to_datetime(data["valid_at"])
    data["pm2_5"] = pd.to_numeric(data["pm2_5"], errors="coerce")

    invalid = data["pm2_5"].isna() | (data["pm2_5"] < 0)
    data.loc[invalid, "pm2_5"] = np.nan
    return data


def regularize_city_series(city_frame: pd.DataFrame) -> pd.DataFrame:
    """Create an hourly PM2.5 index; missing hours remain NaN, never fabricated."""
    city_frame = (
        city_frame.sort_values("valid_at")
        .drop_duplicates(subset=["valid_at"], keep="last")
        .set_index("valid_at")[PARAMETERS]
    )
    if city_frame.empty:
        raise RuntimeError("No usable records remain for this city.")

    hourly_index = pd.date_range(
        start=city_frame.index.min().floor("h"),
        end=city_frame.index.max().floor("h"),
        freq="h",
    )
    return city_frame.reindex(hourly_index).astype(float)


def make_supervised(
    series: pd.DataFrame, horizon: int
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.DatetimeIndex]:
    """Build PM2.5 lag and target-time calendar features for one horizon."""
    features = pd.DataFrame(index=series.index)
    for lag in LAGS:
        features[f"pm2_5_lag_{lag}"] = series["pm2_5"].shift(lag)

    target_times = series.index + pd.Timedelta(hours=int(horizon))
    features["target_hour_sin"] = np.sin(2 * np.pi * target_times.hour / 24.0)
    features["target_hour_cos"] = np.cos(2 * np.pi * target_times.hour / 24.0)
    features["target_dow_sin"] = np.sin(2 * np.pi * target_times.dayofweek / 7.0)
    features["target_dow_cos"] = np.cos(2 * np.pi * target_times.dayofweek / 7.0)

    targets = series[["pm2_5"]].shift(-horizon)
    valid = features.notna().all(axis=1) & targets.notna().all(axis=1)
    return features, targets, valid, target_times


def error_metrics(actual: np.ndarray, predicted: np.ndarray) -> Tuple[float, float]:
    mae = float(np.mean(np.abs(actual - predicted)))
    rmse = float(np.sqrt(np.mean(np.square(actual - predicted))))
    return mae, rmse


def make_model() -> RandomForestRegressor:
    return RandomForestRegressor(
        n_estimators=RF_TREES,
        min_samples_leaf=3,
        max_features=0.9,
        n_jobs=-1,
        random_state=42,
    )


def train_evaluate_city(
    city: str, series: pd.DataFrame, run_id: str
) -> Tuple[List[tuple], List[tuple]]:
    """Evaluate RF against baselines and save six future PM2.5 forecasts."""
    observed_index = series.index[series["pm2_5"].notna()]
    if len(observed_index) < MIN_HISTORY_ROWS:
        raise RuntimeError(
            f"{city}: {len(observed_index)} complete hourly PM2.5 observations; "
            f"at least {MIN_HISTORY_ROWS} are required."
        )

    latest_origin = observed_index.max()
    cutoff_position = min(int(len(series.index) * 0.8), len(series.index) - 1)
    cutoff = series.index[cutoff_position]
    metric_rows: List[tuple] = []
    forecast_rows: List[tuple] = []

    for horizon in HORIZONS:
        X, y, valid, target_times = make_supervised(series, horizon)
        train_mask = valid & (target_times < cutoff)
        test_mask = valid & (target_times >= cutoff)
        train_count = int(train_mask.sum())
        test_count = int(test_mask.sum())
        if train_count < MIN_TRAIN_ROWS or test_count < MIN_TEST_ROWS:
            raise RuntimeError(
                f"{city} horizon={horizon}: insufficient evaluation rows "
                f"(train={train_count}, test={test_count}). Check data continuity."
            )

        X_train, y_train = X.loc[train_mask], y.loc[train_mask, "pm2_5"]
        X_test, y_test = X.loc[test_mask], y.loc[test_mask, "pm2_5"]
        test_origins = X_test.index

        validation_model = make_model()
        validation_model.fit(X_train, y_train)
        rf_predictions = np.asarray(validation_model.predict(X_test), dtype=float).reshape(-1)

        persistence_predictions = series.loc[test_origins, "pm2_5"].to_numpy(dtype=float)
        seasonal_origins = test_origins + pd.Timedelta(hours=int(horizon) - 24)
        seasonal_predictions = series.reindex(seasonal_origins)["pm2_5"].to_numpy(dtype=float)
        seasonal_predictions = np.where(
            np.isnan(seasonal_predictions),
            persistence_predictions,
            seasonal_predictions,
        )

        actual = y_test.to_numpy(dtype=float)
        metrics_by_model: Dict[str, Tuple[float, float]] = {
            "persistence": error_metrics(actual, persistence_predictions),
            "seasonal_naive_24h": error_metrics(actual, seasonal_predictions),
            "random_forest": error_metrics(actual, rf_predictions),
        }
        selected_name = min(metrics_by_model, key=lambda name: metrics_by_model[name][0])

        evaluation_start = pd.Timestamp(target_times[test_mask].min()).to_pydatetime()
        evaluation_end = pd.Timestamp(target_times[test_mask].max()).to_pydatetime()

        for model_name, (mae, rmse) in metrics_by_model.items():
            metric_rows.append(
                (
                    run_id,
                    city,
                    "pm2_5",
                    horizon,
                    model_name,
                    mae,
                    rmse,
                    train_count,
                    test_count,
                    model_name == selected_name,
                    evaluation_start,
                    evaluation_end,
                )
            )

        # Refit Random Forest on every available supervised historical sample.
        final_model = make_model()
        final_model.fit(X.loc[valid], y.loc[valid, "pm2_5"])

        if latest_origin not in X.index or X.loc[latest_origin].isna().any():
            raise RuntimeError(
                f"{city}: latest origin {latest_origin} lacks complete PM2.5 lag "
                "features. A continuous recent history of at least 24 hours is needed."
            )

        rf_future = float(
            np.asarray(final_model.predict(X.loc[[latest_origin]]), dtype=float).reshape(-1)[0]
        )
        persistence_future = float(series.loc[latest_origin, "pm2_5"])

        seasonal_time = latest_origin + pd.Timedelta(hours=int(horizon) - 24)
        seasonal_value = series.reindex([seasonal_time])["pm2_5"].iloc[0]
        seasonal_future = (
            persistence_future if pd.isna(seasonal_value) else float(seasonal_value)
        )

        candidate_values = {
            "random_forest": max(0.0, rf_future),
            "persistence": max(0.0, persistence_future),
            "seasonal_naive_24h": max(0.0, seasonal_future),
        }
        selected_value = candidate_values[selected_name]
        holdout_mae, holdout_rmse = metrics_by_model[selected_name]
        forecast_at = latest_origin + pd.Timedelta(hours=int(horizon))

        forecast_rows.append(
            (
                city,
                latest_origin.to_pydatetime(),
                forecast_at.to_pydatetime(),
                horizon,
                "pm2_5",
                selected_value,
                selected_name,
                holdout_mae,
                holdout_rmse,
                candidate_values["random_forest"],
                candidate_values["persistence"],
                candidate_values["seasonal_naive_24h"],
            )
        )

    log.info(
        "%s: origin=%s, PM2.5 forecasts=%d",
        city,
        latest_origin,
        len(forecast_rows),
    )
    return metric_rows, forecast_rows


def persist_results(conn, metric_rows: List[tuple], forecast_rows: List[tuple]) -> None:
    metrics_sql = """
        INSERT INTO ml.model_metrics (
            run_id, city, parameter_name, horizon_hours, model_name,
            mae, rmse, train_rows, test_rows, is_selected,
            evaluation_start, evaluation_end
        ) VALUES %s
    """
    forecasts_sql = """
        INSERT INTO ml.air_quality_forecast (
            city, forecast_origin, forecast_at, horizon_hours, parameter_name,
            predicted_value, selected_model, holdout_mae, holdout_rmse,
            random_forest_value, persistence_value, seasonal_naive_value
        ) VALUES %s
        ON CONFLICT (city, forecast_origin, forecast_at, parameter_name)
        DO UPDATE SET
            horizon_hours = EXCLUDED.horizon_hours,
            predicted_value = EXCLUDED.predicted_value,
            selected_model = EXCLUDED.selected_model,
            holdout_mae = EXCLUDED.holdout_mae,
            holdout_rmse = EXCLUDED.holdout_rmse,
            random_forest_value = EXCLUDED.random_forest_value,
            persistence_value = EXCLUDED.persistence_value,
            seasonal_naive_value = EXCLUDED.seasonal_naive_value,
            created_at = NOW()
    """
    with conn.cursor() as cur:
        execute_values(cur, metrics_sql, metric_rows, page_size=500)
        execute_values(cur, forecasts_sql, forecast_rows, page_size=500)
    conn.commit()


def main() -> int:
    run_id = os.getenv("AIRFLOW_CTX_DAG_RUN_ID", "manual")
    conn = db_connection()
    try:
        ensure_ml_tables(conn)
        data = load_historical_data(conn)
        all_metrics: List[tuple] = []
        all_forecasts: List[tuple] = []

        for city, city_frame in data.groupby("city", sort=True):
            log.info("Training/evaluating PM2.5 city=%s", city)
            series = regularize_city_series(city_frame)
            city_metrics, city_forecasts = train_evaluate_city(city, series, run_id)
            all_metrics.extend(city_metrics)
            all_forecasts.extend(city_forecasts)

        if not all_metrics or not all_forecasts:
            raise RuntimeError("ML run produced no PM2.5 metrics or forecasts.")

        persist_results(conn, all_metrics, all_forecasts)
        log.info(
            "SUCCESS: saved %d PM2.5 metric rows and upserted %d PM2.5 forecast rows.",
            len(all_metrics),
            len(all_forecasts),
        )
        return 0
    except Exception:
        conn.rollback()
        log.exception("ML forecast task failed")
        return 1
    finally:
        conn.close()


if __name__ == "__main__":
    sys.exit(main())
