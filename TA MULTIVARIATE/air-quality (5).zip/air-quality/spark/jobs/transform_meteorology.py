from __future__ import annotations

import os
from pyspark.sql import SparkSession, functions as F


def env(name: str, default: str) -> str:
    return os.getenv(name, default)


spark = (
    SparkSession.builder
    .appName("MeteorologyCleanTransform")
    .getOrCreate()
)

jdbc_url = (
    f"jdbc:postgresql://{env('DW_HOST', 'postgres')}:"
    f"{env('DW_PORT', '5432')}/{env('DW_DB', 'air_quality_dw')}"
)

jdbc_options = {
    "user": env("DW_USER", "platform"),
    "password": env("DW_PASSWORD", "platform123"),
    "driver": "org.postgresql.Driver",
}

weather_columns = [
    "temperature_2m",
    "relative_humidity_2m",
    "wind_speed_10m",
    "wind_direction_10m",
    "precipitation",
    "boundary_layer_height",
    "shortwave_radiation",
]

print("[SPARK-METEO] Reading staging.meteorology_raw ...")
raw = spark.read.jdbc(
    url=jdbc_url,
    table="staging.meteorology_raw",
    properties=jdbc_options,
)

raw_count = raw.count()
print(f"[SPARK-METEO] Raw rows: {raw_count}")

clean = raw.filter(
    F.col("valid_at").isNotNull()
    & F.col("city").isNotNull()
)

# Remove physically invalid values while retaining NULLs for coverage checks.
range_rules = {
    "temperature_2m": (F.col("temperature_2m") >= -90) & (F.col("temperature_2m") <= 65),
    "relative_humidity_2m": (F.col("relative_humidity_2m") >= 0) & (F.col("relative_humidity_2m") <= 100),
    "wind_speed_10m": F.col("wind_speed_10m") >= 0,
    "wind_direction_10m": (F.col("wind_direction_10m") >= 0) & (F.col("wind_direction_10m") <= 360),
    "precipitation": F.col("precipitation") >= 0,
    "boundary_layer_height": F.col("boundary_layer_height") >= 0,
    "shortwave_radiation": F.col("shortwave_radiation") >= 0,
}

for column_name, valid_rule in range_rules.items():
    clean = clean.withColumn(
        column_name,
        F.when(F.col(column_name).isNull(), F.lit(None))
         .when(valid_rule, F.col(column_name))
         .otherwise(F.lit(None)),
    )

clean = (
    clean
    .dropDuplicates(["city", "valid_at"])
    .withColumn("processed_at", F.current_timestamp())
    .select(
        "city",
        "latitude",
        "longitude",
        "valid_at",
        *weather_columns,
        "source_name",
        "source_model",
        "ingested_at",
        "processed_at",
    )
)

clean_count = clean.count()
print(f"[SPARK-METEO] Clean rows: {clean_count}")

# Clean staging is rebuilt from the idempotent RAW landing table.
(
    clean.write
    .mode("overwrite")
    .jdbc(
        url=jdbc_url,
        table="staging.meteorology_clean",
        properties=jdbc_options,
    )
)

print("[SPARK-METEO] staging.meteorology_clean written successfully")
spark.stop()
