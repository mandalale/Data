#!/usr/bin/env python3
"""Fetch the next six hours of CAMS Global PM2.5 forecasts from Open-Meteo.

The API timestamps are preserved as Asia/Jakarta local-clock values. The script
does not interpolate or fabricate hourly values: it stores only timestamps and
values actually returned by the API.
"""
from __future__ import annotations

import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

import psycopg2
import requests
from psycopg2.extras import execute_values

API_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
TIMEZONE_NAME = "Asia/Jakarta"
LOCAL_TZ = ZoneInfo(TIMEZONE_NAME)
DOMAIN = "cams_global"
FORECAST_DAYS = 2
MAX_HORIZON_HOURS = 6
REQUEST_TIMEOUT = (10, 60)

CITIES = [
    {"city": "Semarang", "latitude": -6.9667, "longitude": 110.4167},
    {"city": "Jakarta", "latitude": -6.2088, "longitude": 106.8456},
    {"city": "Bandung", "latitude": -6.9175, "longitude": 107.6191},
    {"city": "Surabaya", "latitude": -7.2575, "longitude": 112.7521},
    {"city": "Yogyakarta", "latitude": -7.7956, "longitude": 110.3695},
    {"city": "Samarinda", "latitude": -0.5022, "longitude": 117.1536},
    {"city": "Balikpapan", "latitude": -1.2675, "longitude": 116.8289},
    {"city": "Bontang", "latitude": 0.1324, "longitude": 117.4854},
]

logging.basicConfig(
    level=os.getenv("CAMS_LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s [CAMS-PM25] %(message)s",
)
log = logging.getLogger("air_quality_cams_forecast")


def db_connection():
    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=int(os.getenv("DW_PORT", "5432")),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=10,
    )


def ensure_cams_table(conn) -> None:
    ddl = """
    CREATE SCHEMA IF NOT EXISTS ml;

    CREATE TABLE IF NOT EXISTS ml.cams_air_quality_forecast (
        city VARCHAR(100) NOT NULL,
        forecast_origin TIMESTAMP WITHOUT TIME ZONE NOT NULL,
        forecast_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
        horizon_hours SMALLINT NOT NULL
            CHECK (horizon_hours BETWEEN 1 AND 6),
        pm2_5 DOUBLE PRECISION NOT NULL CHECK (pm2_5 >= 0),
        domain VARCHAR(30) NOT NULL DEFAULT 'cams_global',
        retrieved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        PRIMARY KEY (city, forecast_origin, forecast_at)
    );

    CREATE INDEX IF NOT EXISTS idx_ml_cams_forecast_city_at
        ON ml.cams_air_quality_forecast (city, forecast_at DESC);
    """
    with conn.cursor() as cur:
        cur.execute(ddl)
    conn.commit()


def latest_observation_origin(conn, city: str) -> datetime:
    """Use the same last-observed PM2.5 timestamp as the ML forecast origin."""
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT MAX(valid_at)
            FROM staging.air_quality_raw
            WHERE city = %s
              AND pm2_5 IS NOT NULL
              AND pm2_5 >= 0
              AND valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
            """,
            (city,),
        )
        row = cur.fetchone()

    if not row or row[0] is None:
        raise RuntimeError(f"{city}: no historical PM2.5 observation is available.")
    return row[0]


def parse_local_timestamp(value: str) -> datetime:
    """Parse an API timestamp into a naive Asia/Jakarta wall-clock timestamp."""
    parsed = datetime.fromisoformat(str(value))
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(LOCAL_TZ).replace(tzinfo=None)
    return parsed


def fetch_city_forecast(
    city_config: dict,
    forecast_origin: datetime,
    retrieved_at: datetime,
    session: requests.Session,
) -> list[tuple]:
    city = city_config["city"]
    params = {
        "latitude": city_config["latitude"],
        "longitude": city_config["longitude"],
        "hourly": "pm2_5",
        "timezone": TIMEZONE_NAME,
        "domains": DOMAIN,
        "forecast_days": FORECAST_DAYS,
    }

    log.info(
        "API request | city=%s | domain=%s | origin=%s",
        city,
        DOMAIN,
        forecast_origin,
    )
    response = session.get(API_URL, params=params, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    payload = response.json()

    hourly = payload.get("hourly") or {}
    times = hourly.get("time") or []
    values = hourly.get("pm2_5") or []
    if not times or len(times) != len(values):
        raise RuntimeError(
            f"{city}: API response has missing or mismatched hourly time/pm2_5 arrays."
        )

    rows: list[tuple] = []
    max_target = forecast_origin + timedelta(hours=MAX_HORIZON_HOURS)

    for timestamp, value in zip(times, values):
        if value is None:
            continue

        forecast_at = parse_local_timestamp(timestamp)
        delta_hours = (forecast_at - forecast_origin).total_seconds() / 3600.0

        # Only keep future API timestamps within the model's six-hour horizon.
        if forecast_at <= forecast_origin or forecast_at > max_target:
            continue

        # The project compares exact valid times. Do not round/interpolate
        # timestamps that are not on a whole-hour boundary.
        rounded_horizon = round(delta_hours)
        if abs(delta_hours - rounded_horizon) > 1e-8:
            log.warning(
                "Skipping non-hourly timestamp | city=%s | timestamp=%s",
                city,
                timestamp,
            )
            continue

        numeric_value = float(value)
        if numeric_value < 0:
            log.warning(
                "Skipping negative CAMS PM2.5 value | city=%s | timestamp=%s | value=%s",
                city,
                timestamp,
                numeric_value,
            )
            continue

        horizon = int(rounded_horizon)
        if not 1 <= horizon <= MAX_HORIZON_HOURS:
            continue

        rows.append(
            (
                city,
                forecast_origin,
                forecast_at,
                horizon,
                numeric_value,
                DOMAIN,
                retrieved_at,
            )
        )

    if not rows:
        raise RuntimeError(
            f"{city}: CAMS API returned no usable PM2.5 forecast timestamps "
            f"within +1 to +{MAX_HORIZON_HOURS} hours of origin {forecast_origin}."
        )

    log.info(
        "VALIDATED | city=%s | origin=%s | future_points=%d | first=%s | last=%s",
        city,
        forecast_origin,
        len(rows),
        min(row[2] for row in rows),
        max(row[2] for row in rows),
    )
    return rows


def persist_forecasts(conn, rows: list[tuple]) -> None:
    sql = """
        INSERT INTO ml.cams_air_quality_forecast (
            city, forecast_origin, forecast_at, horizon_hours,
            pm2_5, domain, retrieved_at
        ) VALUES %s
        ON CONFLICT (city, forecast_origin, forecast_at)
        DO UPDATE SET
            horizon_hours = EXCLUDED.horizon_hours,
            pm2_5 = EXCLUDED.pm2_5,
            domain = EXCLUDED.domain,
            retrieved_at = EXCLUDED.retrieved_at,
            created_at = NOW()
    """
    with conn.cursor() as cur:
        execute_values(cur, sql, rows, page_size=500)
    conn.commit()


def main() -> int:
    conn = db_connection()
    try:
        ensure_cams_table(conn)
        retrieved_at = datetime.now(timezone.utc)
        all_rows: list[tuple] = []

        with requests.Session() as session:
            for city_config in CITIES:
                city = city_config["city"]
                origin = latest_observation_origin(conn, city)
                city_rows = fetch_city_forecast(
                    city_config=city_config,
                    forecast_origin=origin,
                    retrieved_at=retrieved_at,
                    session=session,
                )
                all_rows.extend(city_rows)

        if not all_rows:
            raise RuntimeError("CAMS extraction produced no forecast rows.")

        persist_forecasts(conn, all_rows)
        log.info(
            "SUCCESS: upserted %d CAMS Global PM2.5 forecast rows for %d cities.",
            len(all_rows),
            len(CITIES),
        )
        return 0
    except Exception:
        conn.rollback()
        log.exception("CAMS PM2.5 forecast task failed")
        return 1
    finally:
        conn.close()


if __name__ == "__main__":
    sys.exit(main())
