"""Read centralized runtime switches for the Air Quality pipelines.

The control row is provisioned by sql/04-pipeline-control.sql.
This module intentionally fails closed: if PostgreSQL/control state cannot be
read, a controlled pipeline is not allowed to start work.
"""
from __future__ import annotations

import os
import sys
from contextlib import closing

import psycopg2

SETTING_COLUMNS = {
    "streaming": "streaming_enabled",
    "batch": "batch_enabled",
    "ml": "ml_enabled",
}


def get_connection():
    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=5,
    )


def is_enabled(pipeline: str) -> bool:
    """Return the enabled flag for streaming, batch, or ml."""
    if pipeline not in SETTING_COLUMNS:
        raise ValueError(f"Unknown pipeline: {pipeline!r}")
    column = SETTING_COLUMNS[pipeline]
    with closing(get_connection()) as conn:
        with conn.cursor() as cur:
            cur.execute(f"SELECT {column} FROM control.pipeline_settings WHERE id = 1")
            row = cur.fetchone()
    if row is None:
        raise RuntimeError("control.pipeline_settings has no singleton row (id=1)")
    return bool(row[0])


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] not in SETTING_COLUMNS:
        print("Usage: pipeline_control.py <streaming|batch|ml>", file=sys.stderr)
        return 2
    pipeline = sys.argv[1]
    try:
        enabled = is_enabled(pipeline)
    except Exception as exc:
        print(f"Cannot read {pipeline} pipeline setting: {exc}", file=sys.stderr)
        return 2
    print(f"{pipeline}={'enabled' if enabled else 'disabled'}")
    return 0 if enabled else 1


if __name__ == "__main__":
    raise SystemExit(main())
