
"""
HISTORICAL PM2.5 DATA ENRICHMENT
Source : Open-Meteo CAMS Global
Target : PostgreSQL ml.pm25_historical_enrichment

Purpose:
Mengambil data historis PM2.5 untuk lima kota
sebagai tambahan dataset model time series forecasting.
"""

import os
import math
import logging
import requests
import psycopg2

from datetime import datetime, date, timedelta
from calendar import monthrange
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from psycopg2.extras import execute_values


# ============================================================
# 1. CONFIGURATION
# ============================================================

API_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"

CITIES = [
    {"city": "Semarang", "latitude": -6.9667, "longitude": 110.4167},
    {"city": "Jakarta", "latitude": -6.2088, "longitude": 106.8456},
    {"city": "Bandung", "latitude": -6.9175, "longitude": 107.6191},
    {"city": "Surabaya", "latitude": -7.2575, "longitude": 112.7521},
    {"city": "Yogyakarta", "latitude": -7.7956, "longitude": 110.3695},
    {"city": "Samarinda", "latitude": -0.5022, "longitude": 117.1536},
    {"city": "Balikpapan", "latitude": -1.2675, "longitude": 116.8289},
    {"city": "Bontang", "latitude": 0.1324, "longitude": 117.4854},
]

TARGET_TABLE = "ml.pm25_historical_enrichment"

SOURCE_NAME = "Open-Meteo"
SOURCE_DOMAIN = "cams_global"

BATCH_SIZE = 500

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

logger = logging.getLogger(__name__)


# ============================================================
# 2. DATABASE CONNECTION
# ============================================================

def get_db_connection():

    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123")
    )


# ============================================================
# 3. HTTP SESSION WITH RETRY
# ============================================================

def create_api_session():

    session = requests.Session()

    retry_strategy = Retry(
        total=4,
        connect=4,
        read=4,
        backoff_factor=2,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
        respect_retry_after_header=True
    )

    adapter = HTTPAdapter(max_retries=retry_strategy)

    session.mount("https://", adapter)

    session.headers.update({
        "User-Agent": "AirQualityAnalytics/1.0"
    })

    return session


# ============================================================
# 4. DETERMINE HISTORICAL PERIOD
# ============================================================

def get_historical_start_dates(conn):

    query = """
        SELECT
            city,
            MIN(valid_at)::date AS first_date
        FROM staging.air_quality_raw
        WHERE city = ANY(%s)
        GROUP BY city;
    """

    city_names = [city["city"] for city in CITIES]

    with conn.cursor() as cur:
        cur.execute(query, (city_names,))
        results = cur.fetchall()

    start_dates = {
        city: first_date - timedelta(days=365)
        for city, first_date in results
    }

    return start_dates


# ============================================================
# 5. GENERATE MONTHLY DATE RANGES
# ============================================================

def generate_monthly_ranges(start_date, end_date):

    current = date(start_date.year, start_date.month, 1)

    while current <= end_date:

        last_day = monthrange(
            current.year,
            current.month
        )[1]

        month_end = date(
            current.year,
            current.month,
            last_day
        )

        yield (
            max(current, start_date),
            min(month_end, end_date)
        )

        if current.month == 12:
            current = date(current.year + 1, 1, 1)
        else:
            current = date(
                current.year,
                current.month + 1,
                1
            )


# ============================================================
# 6. FETCH HISTORICAL PM2.5 FROM OPEN-METEO
# ============================================================

def fetch_pm25_data(session, city, start_date, end_date):

    params = {
        "latitude": city["latitude"],
        "longitude": city["longitude"],
        "hourly": "pm2_5",
        "domains": SOURCE_DOMAIN,
        "timezone": "Asia/Jakarta",
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat()
    }

    logger.info(
        "Fetching %s | %s to %s",
        city["city"],
        start_date,
        end_date
    )

    response = session.get(
        API_URL,
        params=params,
        timeout=(10, 60)
    )

    response.raise_for_status()

    payload = response.json()

    if "hourly" not in payload:
        raise ValueError("API response does not contain hourly data")

    hourly = payload["hourly"]

    if "time" not in hourly or "pm2_5" not in hourly:
        raise ValueError("Missing time or pm2_5 in API response")

    timestamps = hourly["time"]
    values = hourly["pm2_5"]

    if len(timestamps) != len(values):
        raise ValueError("Timestamp and PM2.5 array lengths differ")

    expected_hours = (
        (end_date - start_date).days + 1
    ) * 24

    if len(timestamps) != expected_hours:
        raise ValueError(
            f"Incomplete hourly response: "
            f"expected {expected_hours}, got {len(timestamps)}"
        )

    logger.info(
        "API returned %s hourly observations for %s",
        len(timestamps),
        city["city"]
    )

    return timestamps, values


# ============================================================
# 7. VALIDATE AND PREPARE RECORDS
# ============================================================

def prepare_records(city, timestamps, values, start_date, end_date):

    records = []

    null_count = 0
    invalid_count = 0

    previous_timestamp = None

    for timestamp, value in zip(timestamps, values):

        valid_at = datetime.fromisoformat(timestamp)

        # Check historical date boundaries
        if not (
            start_date <= valid_at.date() <= end_date
        ):
            raise ValueError(
                f"Timestamp outside requested range: {timestamp}"
            )

        # Check hourly continuity
        if previous_timestamp is not None:

            if valid_at - previous_timestamp != timedelta(hours=1):
                raise ValueError(
                    f"Missing or irregular timestamp: {timestamp}"
                )

        previous_timestamp = valid_at

        # Null values are not inserted
        if value is None:
            null_count += 1
            continue

        try:
            pm25 = float(value)
        except (TypeError, ValueError):
            invalid_count += 1
            continue

        # Reject negative and non-finite values
        if not math.isfinite(pm25) or pm25 < 0:
            invalid_count += 1
            continue

        records.append((
            city["city"],
            city["latitude"],
            city["longitude"],
            valid_at,
            pm25,
            SOURCE_NAME,
            SOURCE_DOMAIN
        ))

    logger.info(
        "%s validation | valid=%s | null=%s | invalid=%s",
        city["city"],
        len(records),
        null_count,
        invalid_count
    )

    if not records:
        raise ValueError(
            f"No valid PM2.5 observations for {city['city']}"
        )

    return records


# ============================================================
# 8. BATCH UPSERT TO POSTGRESQL
# ============================================================

def save_batch_to_postgres(conn, records):

    upsert_sql = f"""
        INSERT INTO {TARGET_TABLE} (
            city,
            latitude,
            longitude,
            valid_at,
            pm2_5,
            source_name,
            source_domain
        )
        VALUES %s

        ON CONFLICT (city, valid_at)
        DO UPDATE SET
            latitude = EXCLUDED.latitude,
            longitude = EXCLUDED.longitude,
            pm2_5 = EXCLUDED.pm2_5,
            source_name = EXCLUDED.source_name,
            source_domain = EXCLUDED.source_domain,
            ingested_at = NOW();
    """

    total_submitted = 0

    try:

        with conn.cursor() as cur:

            for start in range(0, len(records), BATCH_SIZE):

                batch = records[
                    start:start + BATCH_SIZE
                ]

                execute_values(
                    cur,
                    upsert_sql,
                    batch,
                    page_size=BATCH_SIZE
                )

                total_submitted += len(batch)

        conn.commit()

    except Exception:

        conn.rollback()
        raise

    logger.info(
        "Database UPSERT completed | submitted=%s",
        total_submitted
    )

    return total_submitted


# ============================================================
# 9. MAIN EXECUTION
# ============================================================

def main():

    logger.info(
        "Starting PM2.5 historical enrichment"
    )

    conn = get_db_connection()
    session = create_api_session()

    total_submitted = 0

    try:

        start_dates = get_historical_start_dates(conn)

        for city in CITIES:

            city_name = city["city"]

            if city_name not in start_dates:

                logger.warning(
                    "No operational data found for %s",
                    city_name
                )

                continue

            historical_start = start_dates[city_name]

            # Exactly 365 calendar days
            historical_end = (
                historical_start + timedelta(days=364)
            )

            logger.info(
                "Processing %s | %s to %s",
                city_name,
                historical_start,
                historical_end
            )

            for month_start, month_end in generate_monthly_ranges(
                historical_start,
                historical_end
            ):

                # 1. Extract
                timestamps, values = fetch_pm25_data(
                    session,
                    city,
                    month_start,
                    month_end
                )

                # 2. Validate and prepare
                records = prepare_records(
                    city,
                    timestamps,
                    values,
                    month_start,
                    month_end
                )

                # 3. Batch UPSERT
                submitted = save_batch_to_postgres(
                    conn,
                    records
                )

                total_submitted += submitted

                logger.info(
                    "Completed %s | %s to %s | submitted=%s",
                    city_name,
                    month_start,
                    month_end,
                    submitted
                )

        logger.info(
            "Historical enrichment completed | total submitted=%s",
            total_submitted
        )

    except Exception:

        logger.exception(
            "Historical enrichment failed"
        )

        raise

    finally:

        session.close()
        conn.close()


if __name__ == "__main__":
    main()
