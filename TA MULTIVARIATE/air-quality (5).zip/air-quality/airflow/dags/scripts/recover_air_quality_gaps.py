"""Automatic historical gap recovery for Open-Meteo CAMS Global air quality data.

The script checks hourly timestamps from GAP_RECOVERY_START_DATE (default
2026-01-01) through the latest common complete historical date available for
all configured cities. It downloads only city-month ranges that contain gaps,
then repairs missing (city, valid_at) records and NULL values for PM10, CO,
and NO2 in staging.air_quality_raw.

Existing non-NULL values are preserved. Recovery fills only the selected
pollutant columns when they are NULL, and inserts complete API rows for missing
timestamps. The unique key on (city, valid_at) makes the operation idempotent.

Examples inside the Airflow container:
    python /opt/airflow/dags/scripts/recover_air_quality_gaps.py --dry-run
    python /opt/airflow/dags/scripts/recover_air_quality_gaps.py
    python /opt/airflow/dags/scripts/recover_air_quality_gaps.py \
        --start-date 2026-01-01 --end-date 2026-10-31
"""

from __future__ import annotations

import argparse
import json
import logging
import math
import os
import sys
from calendar import monthrange
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import psycopg2
import requests
from psycopg2.extras import execute_values
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# The control helper lives in the Airflow DAG folder (one directory above scripts).
DAGS_DIR = str(Path(__file__).resolve().parents[1])
if DAGS_DIR not in sys.path:
    sys.path.insert(0, DAGS_DIR)
from pipeline_control import is_enabled  # noqa: E402


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

API_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
API_DOMAIN = "cams_global"
LOCAL_TIMEZONE = "Asia/Jakarta"
LOCAL_TZ = ZoneInfo(LOCAL_TIMEZONE)

DEFAULT_START_DATE = date(2026, 1, 1)
DEFAULT_LATEST_LOOKBACK_DAYS = 7
TARGET_TABLE = "staging.air_quality_raw"
SOURCE_NAME = "Open-Meteo"
DB_PAGE_SIZE = 500
REQUEST_TIMEOUT = (10, 60)

# One PostgreSQL advisory lock serializes startup recovery and scheduled checks.
# Keep this integer stable between releases of this script.
ADVISORY_LOCK_ID = 7420261101

CITIES: list[dict[str, Any]] = [
    {"city": "Semarang", "latitude": -6.9667, "longitude": 110.4167},
    {"city": "Jakarta", "latitude": -6.2088, "longitude": 106.8456},
    {"city": "Bandung", "latitude": -6.9175, "longitude": 107.6191},
    {"city": "Surabaya", "latitude": -7.2575, "longitude": 112.7521},
    {"city": "Yogyakarta", "latitude": -7.7956, "longitude": 110.3695},
    {"city": "Samarinda", "latitude": -0.5022, "longitude": 117.1536},
    {"city": "Balikpapan", "latitude": -1.2675, "longitude": 116.8289},
    {"city": "Bontang", "latitude": 0.1324, "longitude": 117.4854},
]

PARAMETERS = (
    "pm2_5",
    "pm10",
    "carbon_monoxide",
    "nitrogen_dioxide",
    "sulphur_dioxide",
    "ozone",
    "european_aqi",
)

ENRICHMENT_PARAMETERS = (
    "pm10",
    "carbon_monoxide",
    "nitrogen_dioxide",
)

logging.basicConfig(
    level=os.getenv("GAP_RECOVERY_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("air_quality_gap_recovery")


# ---------------------------------------------------------------------------
# Date and API helpers
# ---------------------------------------------------------------------------

def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"Tanggal harus berformat YYYY-MM-DD: {value}"
        ) from exc


def expected_timestamps(start_date: date, end_date: date) -> list[datetime]:
    """Return every local hourly timestamp, inclusive of both calendar dates."""
    current = datetime.combine(start_date, time.min)
    final = datetime.combine(end_date, time.min) + timedelta(hours=23)
    result: list[datetime] = []
    while current <= final:
        result.append(current)
        current += timedelta(hours=1)
    return result


def monthly_ranges(start_date: date, end_date: date):
    """Yield month-bounded date ranges, including partial first/last months."""
    current = date(start_date.year, start_date.month, 1)
    while current <= end_date:
        last_day = monthrange(current.year, current.month)[1]
        month_end = date(current.year, current.month, last_day)
        yield max(start_date, current), min(end_date, month_end)
        if current.month == 12:
            current = date(current.year + 1, 1, 1)
        else:
            current = date(current.year, current.month + 1, 1)


def create_api_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=5,
        connect=5,
        read=5,
        status=5,
        backoff_factor=1.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        respect_retry_after_header=True,
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update({"User-Agent": "AirQualityAnalytics/1.0"})
    return session


def request_hourly(
    session: requests.Session,
    city: dict[str, Any],
    start_date: date,
    end_date: date,
) -> dict[str, Any]:
    params = {
        "latitude": city["latitude"],
        "longitude": city["longitude"],
        "hourly": ",".join(PARAMETERS),
        "domains": API_DOMAIN,
        "timezone": LOCAL_TIMEZONE,
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
    }
    logger.info(
        "API request | city=%s | period=%s..%s | domain=%s",
        city["city"], start_date, end_date, API_DOMAIN,
    )
    response = session.get(API_URL, params=params, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    payload = response.json()
    hourly = payload.get("hourly")
    if not isinstance(hourly, dict):
        raise ValueError(f"{city['city']}: response tidak memiliki object hourly")

    missing_fields = [field for field in ("time", *PARAMETERS) if field not in hourly]
    if missing_fields:
        raise ValueError(
            f"{city['city']}: parameter API tidak ditemukan: {missing_fields}"
        )
    return hourly


def validate_hourly(
    city_name: str,
    hourly: dict[str, Any],
    start_date: date,
    end_date: date,
) -> list[datetime]:
    expected = expected_timestamps(start_date, end_date)
    expected_strings = [value.strftime("%Y-%m-%dT%H:%M") for value in expected]
    returned_strings = hourly["time"]

    if returned_strings != expected_strings:
        returned_set = set(returned_strings)
        expected_set = set(expected_strings)
        missing = sorted(expected_set - returned_set)
        extra = sorted(returned_set - expected_set)
        raise ValueError(
            f"{city_name}: timestamp API tidak lengkap/berurutan; "
            f"expected={len(expected_strings)}, returned={len(returned_strings)}, "
            f"missing={len(missing)}, extra={len(extra)}, "
            f"sample_missing={missing[:3]}, sample_extra={extra[:3]}"
        )

    for parameter in PARAMETERS:
        values = hourly[parameter]
        if len(values) != len(expected):
            raise ValueError(
                f"{city_name}: panjang {parameter}={len(values)}, "
                f"expected={len(expected)}"
            )

    return expected


def is_day_available(
    session: requests.Session,
    city: dict[str, Any],
    candidate: date,
) -> bool:
    """A date is usable only when the API returns all 24 timestamps for a city."""
    # Network/API failures are allowed to abort recovery instead of repeating
    # the same failing request for every earlier candidate date. Only an
    # incomplete/empty date response causes the probe to try an earlier date.
    hourly = request_hourly(session, city, candidate, candidate)
    try:
        validate_hourly(city["city"], hourly, candidate, candidate)
    except ValueError as exc:
        logger.warning(
            "Latest-date probe incomplete | city=%s | date=%s | error=%s",
            city["city"], candidate, exc,
        )
        return False

    non_null = sum(
        value is not None
        for parameter in PARAMETERS
        for value in hourly[parameter]
    )
    return non_null > 0


def resolve_latest_common_date(
    session: requests.Session,
    cities: list[dict[str, Any]],
    lookback_days: int,
) -> date:
    """Find the latest complete historical date common to all selected cities."""
    yesterday = datetime.now(LOCAL_TZ).date() - timedelta(days=1)
    for offset in range(lookback_days + 1):
        candidate = yesterday - timedelta(days=offset)
        logger.info("Checking latest complete historical date: %s", candidate)
        if all(is_day_available(session, city, candidate) for city in cities):
            logger.info("Latest common complete historical date: %s", candidate)
            return candidate
    raise RuntimeError(
        "Tidak menemukan tanggal historis lengkap untuk seluruh kota dalam "
        f"{lookback_days + 1} hari terakhir. Recovery ditunda."
    )


# ---------------------------------------------------------------------------
# PostgreSQL helpers
# ---------------------------------------------------------------------------

def get_db_connection():
    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=10,
        application_name="air_quality_gap_recovery",
    )


def verify_target_table(conn) -> None:
    with conn.cursor() as cur:
        cur.execute("SELECT to_regclass(%s)", (TARGET_TABLE,))
        if cur.fetchone()[0] is None:
            raise RuntimeError(
                f"Tabel {TARGET_TABLE} tidak ditemukan. Periksa inisialisasi warehouse."
            )


def acquire_advisory_lock(conn) -> bool:
    with conn.cursor() as cur:
        cur.execute("SELECT pg_try_advisory_lock(%s)", (ADVISORY_LOCK_ID,))
        acquired = bool(cur.fetchone()[0])
    conn.commit()
    return acquired


def fetch_existing_state(
    conn,
    city_name: str,
    start_date: date,
    end_date: date,
) -> tuple[set[datetime], set[datetime]]:
    """Return stored timestamps and timestamps missing one or more target pollutants."""
    start_at = datetime.combine(start_date, time.min)
    end_exclusive = datetime.combine(end_date + timedelta(days=1), time.min)
    missing_condition = " OR ".join(
        f"{parameter} IS NULL" for parameter in ENRICHMENT_PARAMETERS
    )

    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT
                valid_at,
                ({missing_condition}) AS needs_enrichment
            FROM {TARGET_TABLE}
            WHERE city = %s
              AND valid_at >= %s
              AND valid_at < %s
            """,
            (city_name, start_at, end_exclusive),
        )
        rows = cur.fetchall()

    existing_timestamps = {row[0] for row in rows}
    incomplete_timestamps = {
        row[0] for row in rows if bool(row[1])
    }
    return existing_timestamps, incomplete_timestamps


def build_repair_records(
    city: dict[str, Any],
    hourly: dict[str, Any],
    timestamps: list[datetime],
    timestamps_to_repair: set[datetime],
) -> list[tuple]:
    """Build API rows for missing timestamps and existing rows with NULL predictors."""
    records: list[tuple] = []
    for index, valid_at in enumerate(timestamps):
        if valid_at not in timestamps_to_repair:
            continue

        values: list[float | None] = []
        for parameter in PARAMETERS:
            raw_value = hourly[parameter][index]
            if raw_value is None:
                values.append(None)
                continue
            try:
                value = float(raw_value)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Nilai non-numerik | city={city['city']} | "
                    f"parameter={parameter} | timestamp={valid_at} | "
                    f"value={raw_value!r}"
                ) from exc
            if not math.isfinite(value):
                raise ValueError(
                    f"Nilai non-finite | city={city['city']} | "
                    f"parameter={parameter} | timestamp={valid_at} | value={value}"
                )
            values.append(value)

        records.append((
            city["city"],
            city["latitude"],
            city["longitude"],
            valid_at,
            *values,
            SOURCE_NAME,
        ))
    return records


def insert_missing_records(conn, records: list[tuple]) -> int:
    if not records:
        return 0

    sql = f"""
        INSERT INTO {TARGET_TABLE} AS current_row (
            city, latitude, longitude, valid_at,
            pm2_5, pm10, carbon_monoxide, nitrogen_dioxide,
            sulphur_dioxide, ozone, european_aqi, source_name
        )
        VALUES %s
        ON CONFLICT (city, valid_at) DO UPDATE SET
            -- Repair only NULL values for the three selected predictors.
            -- Existing PM2.5 and other populated columns remain untouched.
            pm10 = COALESCE(current_row.pm10, EXCLUDED.pm10),
            carbon_monoxide = COALESCE(
                current_row.carbon_monoxide, EXCLUDED.carbon_monoxide
            ),
            nitrogen_dioxide = COALESCE(
                current_row.nitrogen_dioxide, EXCLUDED.nitrogen_dioxide
            ),
            ingested_at = NOW()
        WHERE (current_row.pm10 IS NULL AND EXCLUDED.pm10 IS NOT NULL)
           OR (
                current_row.carbon_monoxide IS NULL
                AND EXCLUDED.carbon_monoxide IS NOT NULL
           )
           OR (
                current_row.nitrogen_dioxide IS NULL
                AND EXCLUDED.nitrogen_dioxide IS NOT NULL
           )
        RETURNING city, valid_at;
    """

    try:
        with conn.cursor() as cur:
            inserted = execute_values(
                cur,
                sql,
                records,
                page_size=DB_PAGE_SIZE,
                fetch=True,
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    return len(inserted or [])


def write_summary(path: str | None, summary: dict[str, Any]) -> None:
    serialized = json.dumps(summary, indent=2, ensure_ascii=False, default=str)
    print("[GAP_RECOVERY_SUMMARY] " + json.dumps(summary, ensure_ascii=False, default=str))
    if not path:
        return

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(serialized + "\n", encoding="utf-8")
    temporary.replace(destination)


# ---------------------------------------------------------------------------
# Recovery orchestration
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Pulihkan timestamp yang hilang dan isi NULL PM10/CO/NO2 pada "
            "staging.air_quality_raw dari Open-Meteo CAMS Global."
        )
    )
    parser.add_argument(
        "--start-date",
        type=parse_date,
        default=parse_date(os.getenv("GAP_RECOVERY_START_DATE", "2026-01-01")),
        help="Tanggal awal pemeriksaan (default: 2026-01-01).",
    )
    parser.add_argument(
        "--end-date",
        type=parse_date,
        default=None,
        help="Tanggal akhir eksplisit. Default: tanggal historis terbaru yang lengkap.",
    )
    parser.add_argument(
        "--city",
        action="append",
        choices=[city["city"] for city in CITIES],
        help="Batasi kota yang diperiksa. Bisa digunakan berulang kali.",
    )
    parser.add_argument(
        "--latest-lookback-days",
        type=int,
        default=int(os.getenv("GAP_RECOVERY_LATEST_LOOKBACK_DAYS", str(DEFAULT_LATEST_LOOKBACK_DAYS))),
        help="Jumlah hari ke belakang untuk mencari tanggal historis lengkap.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Deteksi dan validasi gap tanpa menulis ke PostgreSQL.",
    )
    parser.add_argument(
        "--summary-file",
        default=None,
        help="Simpan ringkasan JSON ke path ini (opsional).",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cities = CITIES
    if args.city:
        selected = set(args.city)
        cities = [city for city in CITIES if city["city"] in selected]

    summary: dict[str, Any] = {
        "status": "starting",
        "start_date": str(args.start_date),
        "end_date": str(args.end_date) if args.end_date else None,
        "cities": [city["city"] for city in cities],
        "parameters": list(PARAMETERS),
        "enrichment_parameters": list(ENRICHMENT_PARAMETERS),
        "domain": API_DOMAIN,
        "dry_run": bool(args.dry_run),
        "city_months_checked": 0,
        "city_months_with_gaps": 0,
        "missing_rows_detected": 0,
        "existing_rows_needing_enrichment": 0,
        "repair_rows_requested": 0,
        "rows_inserted_or_enriched": 0,
        "source_null_values": {parameter: 0 for parameter in ENRICHMENT_PARAMETERS},
        "rows_not_changed_on_conflict": 0,
        "errors": [],
    }

    session = create_api_session()
    conn = None
    lock_acquired = False

    try:
        # Enforce Batch OFF even when this script is invoked manually.
        # Startup and scheduled DAG gates provide the same protection upstream.
        if not is_enabled("batch"):
            summary["status"] = "skipped_batch_disabled"
            logger.info("Batch pipeline is OFF; historical gap recovery is skipped.")
            return 0

        if args.start_date > (args.end_date or date.max):
            raise ValueError("start-date tidak boleh lebih besar daripada end-date.")
        if args.latest_lookback_days < 0:
            raise ValueError("latest-lookback-days tidak boleh negatif.")

        conn = get_db_connection()
        verify_target_table(conn)
        lock_acquired = acquire_advisory_lock(conn)
        if not lock_acquired:
            summary["status"] = "skipped_lock_held"
            logger.warning(
                "Recovery lain sedang berjalan. Proses ini dilewati karena advisory lock aktif."
            )
            return 0

        end_date = args.end_date or resolve_latest_common_date(
            session, cities, args.latest_lookback_days
        )
        summary["end_date"] = str(end_date)
        if args.start_date > end_date:
            raise ValueError(
                f"start-date {args.start_date} lebih besar daripada end-date {end_date}."
            )

        logger.info("=" * 76)
        logger.info("AUTOMATIC HISTORICAL GAP + POLLUTANT ENRICHMENT RECOVERY")
        logger.info("Period     : %s to %s", args.start_date, end_date)
        logger.info("Cities     : %s", ", ".join(city["city"] for city in cities))
        logger.info("Parameters : %s", ", ".join(PARAMETERS))
        logger.info("Domain     : %s", API_DOMAIN)
        logger.info("Target     : %s", TARGET_TABLE)
        logger.info("Dry run    : %s", args.dry_run)
        logger.info("=" * 76)

        ranges = list(monthly_ranges(args.start_date, end_date))

        for city in cities:
            city_name = city["city"]
            logger.info("SCAN CITY: %s", city_name)
            try:
                existing, incomplete = fetch_existing_state(
                    conn, city_name, args.start_date, end_date
                )
            except Exception as exc:  # noqa: BLE001
                conn.rollback()
                summary["errors"].append(f"{city_name}: database scan failed: {exc}")
                logger.exception("Database scan failed for %s", city_name)
                continue

            for month_start, month_end in ranges:
                summary["city_months_checked"] += 1
                expected = set(expected_timestamps(month_start, month_end))
                missing = expected - existing
                incomplete_month = incomplete & expected
                timestamps_to_repair = missing | incomplete_month
                if not timestamps_to_repair:
                    continue

                summary["city_months_with_gaps"] += 1
                summary["missing_rows_detected"] += len(missing)
                summary["existing_rows_needing_enrichment"] += len(incomplete_month)
                summary["repair_rows_requested"] += len(timestamps_to_repair)
                logger.warning(
                    "DATA GAP/ENRICHMENT DETECTED | city=%s | period=%s..%s | "
                    "missing_timestamps=%s | existing_rows_with_null_predictors=%s",
                    city_name,
                    month_start,
                    month_end,
                    len(missing),
                    len(incomplete_month),
                )

                try:
                    hourly = request_hourly(session, city, month_start, month_end)
                    timestamps = validate_hourly(
                        city_name, hourly, month_start, month_end
                    )
                    records = build_repair_records(
                        city, hourly, timestamps, timestamps_to_repair
                    )
                    if len(records) != len(timestamps_to_repair):
                        raise RuntimeError(
                            f"Jumlah record hasil filter tidak cocok: "
                            f"records={len(records)}, "
                            f"repair_targets={len(timestamps_to_repair)}"
                        )

                    null_counts = {
                        parameter: sum(
                            hourly[parameter][index] is None
                            for index, timestamp in enumerate(timestamps)
                            if timestamp in timestamps_to_repair
                        )
                        for parameter in PARAMETERS
                    }
                    for parameter in ENRICHMENT_PARAMETERS:
                        summary["source_null_values"][parameter] += null_counts[parameter]

                    logger.info(
                        "REPAIR DATA VALIDATED | city=%s | rows=%s | "
                        "source_nulls=%s",
                        city_name, len(records), null_counts,
                    )

                    if args.dry_run:
                        logger.info(
                            "DRY RUN: write skipped | city=%s | rows=%s",
                            city_name, len(records),
                        )
                        continue

                    repaired = insert_missing_records(conn, records)
                    summary["rows_inserted_or_enriched"] += repaired
                    summary["rows_not_changed_on_conflict"] += (
                        len(records) - repaired
                    )

                    # Keep in-memory state aligned with the attempted repair.
                    existing.update(missing)
                    incomplete.difference_update(incomplete_month)
                    logger.info(
                        "RECOVERY COMMITTED | city=%s | period=%s..%s | "
                        "missing_timestamps=%s | existing_rows_enriched=%s | "
                        "rows_inserted_or_updated=%s",
                        city_name,
                        month_start,
                        month_end,
                        len(missing),
                        len(incomplete_month),
                        repaired,
                    )
                except Exception as exc:  # noqa: BLE001 - continue other city-months
                    message = (
                        f"{city_name} {month_start}..{month_end}: {type(exc).__name__}: {exc}"
                    )
                    summary["errors"].append(message)
                    logger.exception("Recovery failed for %s", message)

        if summary["errors"]:
            summary["status"] = "partial_failure"
            logger.error(
                "Recovery finished with %s error(s). Successful city-month transactions were committed.",
                len(summary["errors"]),
            )
            return 1

        summary["status"] = "dry_run_completed" if args.dry_run else "completed"
        logger.info("=" * 76)
        logger.info("GAP RECOVERY FINISHED")
        logger.info("City-month checked      : %s", summary["city_months_checked"])
        logger.info("City-month with gaps    : %s", summary["city_months_with_gaps"])
        logger.info("Missing timestamps      : %s", summary["missing_rows_detected"])
        logger.info(
            "Existing rows to enrich : %s",
            summary["existing_rows_needing_enrichment"],
        )
        logger.info("Repair rows requested   : %s", summary["repair_rows_requested"])
        logger.info(
            "Rows inserted/enriched  : %s",
            summary["rows_inserted_or_enriched"],
        )
        logger.info("Source NULL values      : %s", summary["source_null_values"])
        logger.info(
            "Rows not changed on conflict: %s",
            summary["rows_not_changed_on_conflict"],
        )
        logger.info("=" * 76)
        return 0

    except Exception as exc:  # noqa: BLE001
        summary["status"] = "failed"
        summary["errors"].append(f"{type(exc).__name__}: {exc}")
        logger.exception("Automatic gap recovery failed.")
        return 1

    finally:
        if conn is not None:
            if lock_acquired:
                try:
                    with conn.cursor() as cur:
                        cur.execute("SELECT pg_advisory_unlock(%s)", (ADVISORY_LOCK_ID,))
                    conn.commit()
                except Exception:
                    logger.exception("Could not explicitly release advisory lock.")
            conn.close()
        session.close()
        write_summary(args.summary_file, summary)


if __name__ == "__main__":
    sys.exit(main())
