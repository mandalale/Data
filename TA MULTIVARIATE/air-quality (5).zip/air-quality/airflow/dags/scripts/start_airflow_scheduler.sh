#!/usr/bin/env bash
# Startup sequence for the Airflow scheduler container.
# Batch recovery and the one-off startup batch run are controlled by
# control.pipeline_settings.batch_enabled. The scheduler itself always starts.

set -u

CONTROL_SCRIPT="/opt/airflow/dags/pipeline_control.py"
RECOVERY_SCRIPT="/opt/airflow/dags/scripts/recover_air_quality_gaps.py"
SUMMARY_FILE="/tmp/air_quality_startup_recovery_summary.json"
DAG_ID="air_quality_end_to_end"

log() {
    printf '%s | %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$1"
}

log "Airflow scheduler startup sequence started."
BATCH_ENABLED=0

if python "$CONTROL_SCRIPT" batch; then
    BATCH_ENABLED=1
    log "Batch pipeline is ON. Startup recovery is enabled."
else
    CONTROL_EXIT=$?
    if [ "$CONTROL_EXIT" -eq 1 ]; then
        log "Batch pipeline is OFF. Startup recovery and startup DAG trigger are skipped."
    else
        log "ERROR: Cannot read batch control state. Failing closed: startup recovery and startup DAG trigger are skipped."
    fi
fi

if [ "$BATCH_ENABLED" -eq 1 ]; then
    log "Running historical gap recovery before scheduler startup."
    rm -f "$SUMMARY_FILE"
    RECOVERY_EXIT=0
    python "$RECOVERY_SCRIPT" --summary-file "$SUMMARY_FILE" || RECOVERY_EXIT=$?

    if [ -f "$SUMMARY_FILE" ]; then
        log "Startup recovery summary:"
        cat "$SUMMARY_FILE"
    else
        log "WARNING: recovery summary file was not created."
    fi

    if [ "$RECOVERY_EXIT" -ne 0 ]; then
        log "WARNING: startup recovery exited with code ${RECOVERY_EXIT}. Scheduler will still start; the scheduled DAG recovery task can retry."
    else
        log "Startup recovery process completed."
    fi

    # Queue the one-off end-to-end batch run after the DAG processor registers.
    RUN_ID="startup_recovery__$(date -u '+%Y%m%dT%H%M%S')"
    TRIGGERED=0
    log "Triggering one startup batch run: ${DAG_ID} (${RUN_ID})."
    for attempt in $(seq 1 30); do
        if airflow dags trigger --run-id "$RUN_ID" --output plain "$DAG_ID"; then
            TRIGGERED=1
            log "Startup batch DAG run successfully queued."
            break
        fi
        log "DAG trigger attempt ${attempt}/30 failed; retrying in 5 seconds."
        sleep 5
    done

    if [ "$TRIGGERED" -ne 1 ]; then
        log "WARNING: startup batch DAG could not be triggered after 30 attempts. The scheduler will start and the next scheduled run remains available."
    fi
fi

log "Starting Airflow scheduler."
exec airflow scheduler
