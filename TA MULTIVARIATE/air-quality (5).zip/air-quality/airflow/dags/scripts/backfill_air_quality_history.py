"""
HISTORICAL AIR QUALITY BACKFILL — 7 PARAMETERS
Source : Open-Meteo Air Quality API (CAMS Global)
Target : PostgreSQL staging.air_quality_raw

Purpose
-------
Mengambil data historis per jam untuk lima kota di Indonesia, untuk tujuh
parameter kualitas udara, mulai 1 Januari 2026 sampai tanggal terbaru yang
tersedia pada API.

Desain penting
--------------
1. Script ini terpisah dari DAG incremental air_quality_end_to_end.
2. Request dilakukan per kota dan per bulan agar mudah ditelusuri.
3. Setiap kombinasi kota-bulan disimpan dalam satu transaksi PostgreSQL.
4. UNIQUE(city, valid_at) + UPSERT membuat proses aman untuk dijalankan ulang.
5. City-month hanya dilewati jika timestamp lengkap DAN PM10, CO, serta NO2
   sudah terisi. Jika salah satu nilai target NULL, bulan diambil ulang.
6. Pada timestamp yang sudah ada, UPSERT hanya mengisi PM10, CO, dan NO2 yang
   NULL; nilai PM2.5 dan kolom lain yang sudah tersimpan tidak ditimpa.
7. Raw staging mempertahankan nilai sumber. Nilai negatif dicatat di log dan
   nantinya dibersihkan oleh transform_air_quality.py pada clean layer.
8. --dry-run menguji API dan validasi tanpa membuka koneksi database.

Environment variables database mengikuti docker-compose.yml:
DW_HOST, DW_PORT, DW_DB, DW_USER, DW_PASSWORD

Contoh:
  # Uji Januari untuk semua kota tanpa menulis database
  python backfill_air_quality_history.py \
      --start-date 2026-01-01 --end-date 2026-01-31 --dry-run

  # Jalankan backfill dari 1 Januari sampai tanggal terbaru yang terdeteksi
  python backfill_air_quality_history.py

  # Paksa ambil ulang bulan yang sudah lengkap
  python backfill_air_quality_history.py --force
"""

from __future__ import annotations

import argparse
import logging
import math
import os
import sys
from calendar import monthrange
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import psycopg2
import requests
from psycopg2.extras import execute_values
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Keep the standalone historical backfill under the same Batch ON/OFF control.
DAGS_DIR = str(Path(__file__).resolve().parents[1])
if DAGS_DIR not in sys.path:
    sys.path.insert(0, DAGS_DIR)
from pipeline_control import is_enabled  # noqa: E402


# ---------------------------------------------------------------------------
# 1. KONFIGURASI SUMBER DATA
# ---------------------------------------------------------------------------

API_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"
API_DOMAIN = "cams_global"
LOCAL_TIMEZONE = "Asia/Jakarta"
JAKARTA_TZ = ZoneInfo(LOCAL_TIMEZONE)

DEFAULT_START_DATE = date(2026, 1, 1)

CITIES = [
    {"city": "Semarang", "latitude": -6.9667, "longitude": 110.4167},
    {"city": "Jakarta", "latitude": -6.2088, "longitude": 106.8456},
    {"city": "Bandung", "latitude": -6.9175, "longitude": 107.6191},
    {"city": "Surabaya", "latitude": -7.2575, "longitude": 112.7521},
    {"city": "Yogyakarta", "latitude": -7.7956, "longitude": 110.3695},
    {"city": "Samarinda", "latitude": -0.5022, "longitude": 117.1536},
    {"city": "Balikpapan", "latitude": -1.2675, "longitude": 116.8289},
    {"city": "Bontang", "latitude": 0.1324, "longitude": 117.4854},
]

# Nama parameter API sama dengan nama kolom pada staging.air_quality_raw.
PARAMETERS = (
    "pm2_5",
    "pm10",
    "carbon_monoxide",
    "nitrogen_dioxide",
    "sulphur_dioxide",
    "ozone",
    "european_aqi",
)

# Existing PM2.5 history is retained. This enrichment specifically repairs
# the three newly selected predictors when their values are NULL.
ENRICHMENT_PARAMETERS = (
    "pm10",
    "carbon_monoxide",
    "nitrogen_dioxide",
)

TARGET_TABLE = "staging.air_quality_raw"
SOURCE_NAME = "Open-Meteo"
DB_PAGE_SIZE = 500
REQUEST_TIMEOUT = (10, 60)
LATEST_DATE_LOOKBACK_DAYS = 7


# ---------------------------------------------------------------------------
# 2. LOGGING
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=os.getenv("BACKFILL_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("air_quality_historical_backfill")


# ---------------------------------------------------------------------------
# 3. DATABASE CONNECTION
# ---------------------------------------------------------------------------

def get_db_connection():
    """Membuka koneksi ke database warehouse menggunakan environment Docker."""
    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=10,
    )


def verify_target_table(conn) -> None:
    """Memastikan target staging tersedia sebelum proses menulis dimulai."""
    with conn.cursor() as cur:
        cur.execute("SELECT to_regclass(%s)", (TARGET_TABLE,))
        table_name = cur.fetchone()[0]

    if table_name is None:
        raise RuntimeError(
            f"Target table {TARGET_TABLE} tidak ditemukan. "
            "Periksa database dan jalankan SQL warehouse yang sesuai."
        )


# ---------------------------------------------------------------------------
# 4. HTTP SESSION DAN RETRY
# ---------------------------------------------------------------------------

def create_api_session() -> requests.Session:
    """Membuat HTTP session dengan retry untuk gangguan jaringan sementara."""
    session = requests.Session()

    retry_strategy = Retry(
        total=5,
        connect=5,
        read=5,
        status=5,
        backoff_factor=1.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        respect_retry_after_header=True,
        raise_on_status=False,
    )

    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update({"User-Agent": "AirQualityAnalytics/1.0"})
    return session


# ---------------------------------------------------------------------------
# 5. RENTANG TANGGAL BULANAN
# ---------------------------------------------------------------------------

def generate_monthly_ranges(start_date: date, end_date: date):
    """Menghasilkan rentang tanggal per bulan, termasuk bulan parsial."""
    current = date(start_date.year, start_date.month, 1)

    while current <= end_date:
        last_day = monthrange(current.year, current.month)[1]
        month_end = date(current.year, current.month, last_day)

        yield max(current, start_date), min(month_end, end_date)

        if current.month == 12:
            current = date(current.year + 1, 1, 1)
        else:
            current = date(current.year, current.month + 1, 1)


def expected_timestamps(start_date: date, end_date: date) -> list[str]:
    """Membangun daftar timestamp lokal yang diharapkan untuk setiap jam."""
    result: list[str] = []
    current = datetime.combine(start_date, datetime.min.time())
    final = datetime.combine(end_date, datetime.min.time()) + timedelta(hours=23)

    while current <= final:
        result.append(current.strftime("%Y-%m-%dT%H:%M"))
        current += timedelta(hours=1)

    return result


# ---------------------------------------------------------------------------
# 6. REQUEST DAN VALIDASI STRUKTUR RESPONSE API
# ---------------------------------------------------------------------------

def request_hourly_data(
    session: requests.Session,
    city: dict[str, Any],
    start_date: date,
    end_date: date,
) -> dict[str, Any]:
    """Meminta tujuh parameter hourly untuk satu kota dan satu rentang tanggal."""
    params = {
        "latitude": city["latitude"],
        "longitude": city["longitude"],
        "hourly": ",".join(PARAMETERS),
        "domains": API_DOMAIN,
        "timezone": LOCAL_TIMEZONE,
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
    }

    logger.info(
        "API request | city=%s | period=%s to %s",
        city["city"], start_date, end_date,
    )

    response = session.get(API_URL, params=params, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()

    payload = response.json()
    hourly = payload.get("hourly")

    if not isinstance(hourly, dict):
        raise ValueError(
            f"{city['city']}: response API tidak memiliki object 'hourly'."
        )

    required_fields = ("time", *PARAMETERS)
    missing_fields = [field for field in required_fields if field not in hourly]
    if missing_fields:
        raise ValueError(
            f"{city['city']}: parameter API tidak ditemukan: {missing_fields}"
        )

    return hourly


def validate_hourly_structure(
    city_name: str,
    hourly: dict[str, Any],
    start_date: date,
    end_date: date,
) -> list[datetime]:
    """Memastikan timestamp tepat, berurutan, dan semua array punya panjang sama."""
    timestamps = hourly["time"]
    expected = expected_timestamps(start_date, end_date)

    if timestamps != expected:
        returned = set(timestamps)
        expected_set = set(expected)
        missing = sorted(expected_set - returned)
        extra = sorted(returned - expected_set)
        raise ValueError(
            f"{city_name}: timestamp tidak lengkap/berurutan. "
            f"expected={len(expected)}, returned={len(timestamps)}, "
            f"missing={len(missing)}, extra={len(extra)}. "
            f"Contoh missing={missing[:3]}, extra={extra[:3]}"
        )

    for parameter in PARAMETERS:
        if len(hourly[parameter]) != len(expected):
            raise ValueError(
                f"{city_name}: panjang array {parameter} tidak cocok. "
                f"expected={len(expected)}, got={len(hourly[parameter])}"
            )

    return [datetime.fromisoformat(value) for value in timestamps]


# ---------------------------------------------------------------------------
# 7. MENENTUKAN TANGGAL TERBARU YANG TERSEDIA
# ---------------------------------------------------------------------------

def has_observation_for_day(
    session: requests.Session,
    city: dict[str, Any],
    candidate_date: date,
) -> bool:
    """Memeriksa apakah API menyediakan 24 timestamp untuk satu hari penuh."""
    hourly = request_hourly_data(session, city, candidate_date, candidate_date)

    try:
        validate_hourly_structure(
            city["city"], hourly, candidate_date, candidate_date
        )
    except ValueError as exc:
        logger.warning("Latest-date probe incomplete: %s", exc)
        return False

    # Hindari memilih hari yang seluruh tujuh parameternya kosong.
    non_null_count = sum(
        value is not None
        for parameter in PARAMETERS
        for value in hourly[parameter]
    )
    return non_null_count > 0


def resolve_latest_available_date(
    session: requests.Session,
    cities: list[dict[str, Any]],
) -> date:
    """Cari hari terbaru yang memiliki 24 timestamp untuk seluruh kota.

    Pemeriksaan dimulai dari kemarin (agar tidak mengambil hari berjalan yang
    belum lengkap), lalu mundur maksimal LATEST_DATE_LOOKBACK_DAYS.
    """
    yesterday = datetime.now(JAKARTA_TZ).date() - timedelta(days=1)

    for offset in range(LATEST_DATE_LOOKBACK_DAYS + 1):
        candidate = yesterday - timedelta(days=offset)
        logger.info("Checking latest available date: %s", candidate)

        all_cities_available = True
        for city in cities:
            if not has_observation_for_day(session, city, candidate):
                logger.info(
                    "Date %s is not complete for %s; checking an earlier date.",
                    candidate, city["city"],
                )
                all_cities_available = False
                break

        if all_cities_available:
            logger.info("Latest common complete date: %s", candidate)
            return candidate

    raise RuntimeError(
        "Tidak menemukan tanggal lengkap untuk seluruh kota dalam "
        f"{LATEST_DATE_LOOKBACK_DAYS + 1} hari terakhir. "
        "Periksa ketersediaan API atau gunakan --end-date secara eksplisit."
    )


# ---------------------------------------------------------------------------
# 8. MENYIAPKAN RECORD RAW
# ---------------------------------------------------------------------------

def prepare_records(
    city: dict[str, Any],
    hourly: dict[str, Any],
    timestamps: list[datetime],
) -> tuple[list[tuple], dict[str, int], dict[str, int]]:
    """Membentuk tuple sesuai kolom staging.air_quality_raw.

    Nilai NULL dipertahankan sebagai None. Nilai negatif tetap disimpan pada
    raw layer agar data sumber tidak dimodifikasi diam-diam; Spark clean layer
    existing akan mengubah nilai negatif menjadi NULL.
    """
    records: list[tuple] = []
    null_counts = {parameter: 0 for parameter in PARAMETERS}
    negative_counts = {parameter: 0 for parameter in PARAMETERS}

    for index, valid_at in enumerate(timestamps):
        values: list[float | None] = []

        for parameter in PARAMETERS:
            raw_value = hourly[parameter][index]

            if raw_value is None:
                null_counts[parameter] += 1
                values.append(None)
                continue

            try:
                numeric_value = float(raw_value)
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Nilai non-numerik: city={city['city']}, "
                    f"parameter={parameter}, timestamp={valid_at}, "
                    f"value={raw_value!r}"
                ) from exc

            if not math.isfinite(numeric_value):
                raise ValueError(
                    f"Nilai non-finite: city={city['city']}, "
                    f"parameter={parameter}, timestamp={valid_at}, "
                    f"value={raw_value!r}"
                )

            if numeric_value < 0:
                negative_counts[parameter] += 1

            values.append(numeric_value)

        records.append((
            city["city"],
            city["latitude"],
            city["longitude"],
            valid_at,
            *values,
            SOURCE_NAME,
        ))

    return records, null_counts, negative_counts


# ---------------------------------------------------------------------------
# 9. CHECKPOINT: APAKAH CITY-MONTH SUDAH LENGKAP?
# ---------------------------------------------------------------------------

def count_existing_rows(
    conn,
    city_name: str,
    start_date: date,
    end_date: date,
) -> int:
    """Menghitung jumlah timestamp yang sudah tersimpan untuk kota-bulan."""
    start_at = datetime.combine(start_date, datetime.min.time())
    end_exclusive = datetime.combine(end_date + timedelta(days=1), datetime.min.time())

    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT COUNT(*)
            FROM {TARGET_TABLE}
            WHERE city = %s
              AND valid_at >= %s
              AND valid_at < %s
            """,
            (city_name, start_at, end_exclusive),
        )
        return int(cur.fetchone()[0])


def count_rows_missing_enrichment_values(
    conn,
    city_name: str,
    start_date: date,
    end_date: date,
) -> int:
    """Count existing timestamps where at least one selected pollutant is NULL."""
    start_at = datetime.combine(start_date, datetime.min.time())
    end_exclusive = datetime.combine(end_date + timedelta(days=1), datetime.min.time())
    missing_condition = " OR ".join(
        f"{parameter} IS NULL" for parameter in ENRICHMENT_PARAMETERS
    )

    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT COUNT(*)
            FROM {TARGET_TABLE}
            WHERE city = %s
              AND valid_at >= %s
              AND valid_at < %s
              AND ({missing_condition})
            """,
            (city_name, start_at, end_exclusive),
        )
        return int(cur.fetchone()[0])


def is_month_complete(
    conn,
    city_name: str,
    start_date: date,
    end_date: date,
) -> bool:
    """A month is complete only when timestamps and selected pollutant values exist."""
    expected_count = len(expected_timestamps(start_date, end_date))
    actual_count = count_existing_rows(conn, city_name, start_date, end_date)

    if actual_count > expected_count:
        raise RuntimeError(
            f"Jumlah row melebihi ekspektasi untuk {city_name} "
            f"{start_date}–{end_date}: {actual_count}>{expected_count}."
        )

    if actual_count != expected_count:
        return False

    incomplete_rows = count_rows_missing_enrichment_values(
        conn, city_name, start_date, end_date
    )
    if incomplete_rows:
        logger.info(
            "CITY-MONTH NEEDS POLLUTANT ENRICHMENT | city=%s | period=%s..%s | "
            "rows_with_null_%s=%s",
            city_name,
            start_date,
            end_date,
            "_".join(ENRICHMENT_PARAMETERS),
            incomplete_rows,
        )
        return False

    return True


# ---------------------------------------------------------------------------
# 10. UPSERT KE RAW STAGING
# ---------------------------------------------------------------------------

def save_month_to_postgres(conn, records: list[tuple]) -> int:
    """Menyimpan satu city-month dalam satu transaksi yang dapat di-rollback."""
    upsert_sql = f"""
        INSERT INTO {TARGET_TABLE} AS current_row (
            city,
            latitude,
            longitude,
            valid_at,
            pm2_5,
            pm10,
            carbon_monoxide,
            nitrogen_dioxide,
            sulphur_dioxide,
            ozone,
            european_aqi,
            source_name
        )
        VALUES %s
        ON CONFLICT (city, valid_at) DO UPDATE SET
            -- Only fill the three requested predictors on existing rows.
            -- Never replace already-populated values or alter historical PM2.5.
            pm10 = COALESCE(current_row.pm10, EXCLUDED.pm10),
            carbon_monoxide = COALESCE(
                current_row.carbon_monoxide, EXCLUDED.carbon_monoxide
            ),
            nitrogen_dioxide = COALESCE(
                current_row.nitrogen_dioxide, EXCLUDED.nitrogen_dioxide
            ),
            ingested_at = NOW()
        WHERE (current_row.pm10 IS NULL AND EXCLUDED.pm10 IS NOT NULL)
           OR (
                current_row.carbon_monoxide IS NULL
                AND EXCLUDED.carbon_monoxide IS NOT NULL
           )
           OR (
                current_row.nitrogen_dioxide IS NULL
                AND EXCLUDED.nitrogen_dioxide IS NOT NULL
           );
    """

    try:
        with conn.cursor() as cur:
            execute_values(
                cur,
                upsert_sql,
                records,
                page_size=DB_PAGE_SIZE,
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    return len(records)


# ---------------------------------------------------------------------------
# 11. ARGUMENT COMMAND LINE
# ---------------------------------------------------------------------------

def parse_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"Tanggal harus berformat YYYY-MM-DD: {value}"
        ) from exc


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Historical backfill Open-Meteo untuk tujuh parameter kualitas udara."
    )
    parser.add_argument(
        "--start-date",
        type=parse_date,
        default=parse_date(os.getenv("BACKFILL_START_DATE", "2026-01-01")),
        help="Tanggal awal YYYY-MM-DD (default: 2026-01-01).",
    )
    parser.add_argument(
        "--end-date",
        type=parse_date,
        default=(
            parse_date(os.environ["BACKFILL_END_DATE"])
            if os.getenv("BACKFILL_END_DATE")
            else None
        ),
        help="Tanggal akhir YYYY-MM-DD. Jika tidak diisi, cari tanggal terbaru yang lengkap.",
    )
    parser.add_argument(
        "--city",
        action="append",
        choices=[city["city"] for city in CITIES],
        help="Batasi kota yang diproses. Bisa dipakai lebih dari sekali.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Ambil dan validasi API tanpa menulis ke PostgreSQL.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help=(
            "Request ulang semua city-month. Existing non-NULL values for "
            "PM2.5 and other pollutants remain preserved."
        ),
    )
    return parser.parse_args()


# ---------------------------------------------------------------------------
# 12. MAIN ORCHESTRATION
# ---------------------------------------------------------------------------

def main() -> int:
    args = parse_args()
    cities = CITIES

    if args.city:
        selected = set(args.city)
        cities = [city for city in CITIES if city["city"] in selected]

    session = create_api_session()
    conn = None

    try:
        # A dry-run is read-only and remains available for API validation.
        # Actual historical writes obey the project's Batch switch.
        if not args.dry_run and not is_enabled("batch"):
            logger.info("Batch pipeline is OFF; historical backfill is skipped.")
            return 0

        start_date = args.start_date
        end_date = args.end_date or resolve_latest_available_date(session, cities)

        if start_date > end_date:
            raise ValueError(
                f"start-date {start_date} lebih besar daripada end-date {end_date}."
            )

        logger.info("=" * 72)
        logger.info("OPEN-METEO HISTORICAL AIR QUALITY BACKFILL")
        logger.info("Period      : %s to %s", start_date, end_date)
        logger.info("Cities      : %s", ", ".join(city["city"] for city in cities))
        logger.info("Parameters  : %s", ", ".join(PARAMETERS))
        logger.info("Domain      : %s", API_DOMAIN)
        logger.info("Target      : %s", TARGET_TABLE)
        logger.info("Dry run     : %s", args.dry_run)
        logger.info("Force       : %s", args.force)
        logger.info("=" * 72)

        if not args.dry_run:
            conn = get_db_connection()
            verify_target_table(conn)
            logger.info("PostgreSQL target table is ready.")

        total_fetched = 0
        total_submitted = 0
        total_skipped = 0

        monthly_ranges = list(generate_monthly_ranges(start_date, end_date))

        for city in cities:
            city_name = city["city"]
            logger.info("START CITY: %s", city_name)

            for month_start, month_end in monthly_ranges:
                expected_count = len(expected_timestamps(month_start, month_end))

                if conn is not None and not args.force:
                    if is_month_complete(conn, city_name, month_start, month_end):
                        logger.info(
                            "SKIP complete city-month | %s | %s to %s | rows=%s",
                            city_name, month_start, month_end, expected_count,
                        )
                        total_skipped += expected_count
                        continue

                hourly = request_hourly_data(
                    session, city, month_start, month_end
                )
                timestamps = validate_hourly_structure(
                    city_name, hourly, month_start, month_end
                )
                records, null_counts, negative_counts = prepare_records(
                    city, hourly, timestamps
                )

                total_fetched += len(records)

                logger.info(
                    "VALIDATED | city=%s | period=%s..%s | rows=%s | expected=%s",
                    city_name, month_start, month_end, len(records), expected_count,
                )
                logger.info("NULL COUNTS | %s | %s", city_name, null_counts)

                negative_total = sum(negative_counts.values())
                if negative_total:
                    logger.warning(
                        "NEGATIVE VALUES retained in raw for Spark cleaning | "
                        "city=%s | counts=%s",
                        city_name, negative_counts,
                    )

                if args.dry_run:
                    logger.info(
                        "DRY RUN: PostgreSQL write skipped | city=%s | %s..%s",
                        city_name, month_start, month_end,
                    )
                    continue

                submitted = save_month_to_postgres(conn, records)
                total_submitted += submitted
                logger.info(
                    "UPSERT COMMITTED | city=%s | period=%s..%s | rows=%s",
                    city_name, month_start, month_end, submitted,
                )

        logger.info("=" * 72)
        logger.info("BACKFILL FINISHED")
        logger.info("Rows fetched/validated : %s", total_fetched)
        logger.info("Rows submitted/upserted: %s", total_submitted)
        logger.info("Rows skipped as complete: %s", total_skipped)
        logger.info("=" * 72)
        return 0

    except Exception:
        if conn is not None:
            conn.rollback()
        logger.exception("Historical backfill failed.")
        return 1

    finally:
        if conn is not None:
            conn.close()
        session.close()


if __name__ == "__main__":
    sys.exit(main())
