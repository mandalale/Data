from __future__ import annotations

import calendar
import os
import time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import psycopg2
import requests
from psycopg2.extras import execute_values

from airflow.sdk import dag, task
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator


# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------

API_URL = "https://historical-forecast-api.open-meteo.com/v1/forecast"
SOURCE_NAME = "Open-Meteo Historical Forecast API"
SOURCE_MODEL = "ecmwf_ifs"  # ECMWF IFS HRES, global 9 km, hourly

CITIES = [
    {"city": "Semarang", "latitude": -6.9667, "longitude": 110.4167},
    {"city": "Jakarta", "latitude": -6.2088, "longitude": 106.8456},
    {"city": "Bandung", "latitude": -6.9175, "longitude": 107.6191},
    {"city": "Surabaya", "latitude": -7.2575, "longitude": 112.7521},
    {"city": "Yogyakarta", "latitude": -7.7956, "longitude": 110.3695},
    {"city": "Samarinda", "latitude": -0.5022, "longitude": 117.1536},
    {"city": "Balikpapan", "latitude": -1.2675, "longitude": 116.8289},
    {"city": "Bontang", "latitude": 0.1324, "longitude": 117.4854},
]

HOURLY_VARIABLES = (
    "temperature_2m,"
    "relative_humidity_2m,"
    "wind_speed_10m,"
    "wind_direction_10m,"
    "precipitation,"
    "boundary_layer_height,"
    "shortwave_radiation"
)

WEATHER_COLUMNS = [
    "temperature_2m",
    "relative_humidity_2m",
    "wind_speed_10m",
    "wind_direction_10m",
    "precipitation",
    "boundary_layer_height",
    "shortwave_radiation",
]

LOCAL_TZ = ZoneInfo("Asia/Jakarta")


def dw_connection():
    return psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
    )


def month_ranges(start: date, end: date):
    """Yield inclusive date ranges split by calendar month."""
    cursor = date(start.year, start.month, 1)
    while cursor <= end:
        month_end = date(
            cursor.year,
            cursor.month,
            calendar.monthrange(cursor.year, cursor.month)[1],
        )
        yield max(start, cursor), min(end, month_end)
        if cursor.month == 12:
            cursor = date(cursor.year + 1, 1, 1)
        else:
            cursor = date(cursor.year, cursor.month + 1, 1)


def safe_hourly_value(hourly: dict, name: str, index: int):
    values = hourly.get(name)
    if values is None or index >= len(values):
        return None
    return values[index]


def resolve_backfill_window(conn):
    """Use the actual air-quality RAW date range as the meteorology target."""
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT MIN(valid_at)::date, MAX(valid_at)::date
            FROM staging.air_quality_raw
            """
        )
        row = cur.fetchone()

    if not row or row[0] is None or row[1] is None:
        raise RuntimeError(
            "staging.air_quality_raw is empty; load air-quality history first."
        )

    start_date, raw_end_date = row
    # Historical backfill stops at the latest complete local calendar day.
    # This avoids requesting today's still-evolving forecast archive by default.
    latest_complete_day = datetime.now(LOCAL_TZ).date() - timedelta(days=1)
    end_date = min(raw_end_date, latest_complete_day)

    # Optional overrides are useful for controlled reruns and partial backfills.
    configured_start = os.getenv("METEOROLOGY_START_DATE")
    configured_end = os.getenv("METEOROLOGY_END_DATE")
    if configured_start:
        start_date = date.fromisoformat(configured_start)
    if configured_end:
        end_date = date.fromisoformat(configured_end)

    if start_date > end_date:
        raise ValueError(
            f"Invalid meteorology backfill window: {start_date} > {end_date}. "
            "Check the air-quality raw date range and optional overrides."
        )
    return start_date, end_date


@dag(
    dag_id="meteorology_historical_backfill",
    description=(
        "One-time historical meteorology ingestion: Open-Meteo ECMWF IFS "
        "-> raw staging -> Spark clean -> PostgreSQL warehouse"
    ),
    schedule=None,
    start_date=datetime(2026, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["big-data", "meteorology", "open-meteo", "spark", "backfill"],
)
def meteorology_historical_backfill():

    @task(
        task_id="extract_meteorology_to_raw",
        retries=3,
        retry_delay=timedelta(minutes=5),
    )
    def extract_meteorology_to_raw() -> dict:
        """Backfill hourly meteorology for the actual air-quality date range."""
        with dw_connection() as conn:
            start_date, end_date = resolve_backfill_window(conn)

        print(
            f"[METEO] Backfill window: {start_date} through {end_date} "
            f"(Asia/Jakarta)"
        )
        print(
            f"[METEO] Source model: {SOURCE_MODEL}; "
            f"cities: {len(CITIES)}; variables: {HOURLY_VARIABLES}"
        )

        session = requests.Session()
        total_rows = 0
        request_count = 0
        city_totals = {}

        upsert_sql = """
            INSERT INTO staging.meteorology_raw (
                city, latitude, longitude, valid_at,
                temperature_2m, relative_humidity_2m,
                wind_speed_10m, wind_direction_10m,
                precipitation, boundary_layer_height,
                shortwave_radiation, source_name, source_model
            ) VALUES %s
            ON CONFLICT (city, valid_at) DO UPDATE SET
                latitude = EXCLUDED.latitude,
                longitude = EXCLUDED.longitude,
                temperature_2m = EXCLUDED.temperature_2m,
                relative_humidity_2m = EXCLUDED.relative_humidity_2m,
                wind_speed_10m = EXCLUDED.wind_speed_10m,
                wind_direction_10m = EXCLUDED.wind_direction_10m,
                precipitation = EXCLUDED.precipitation,
                boundary_layer_height = EXCLUDED.boundary_layer_height,
                shortwave_radiation = EXCLUDED.shortwave_radiation,
                source_name = EXCLUDED.source_name,
                source_model = EXCLUDED.source_model,
                ingested_at = NOW()
        """

        with dw_connection() as conn:
            for city in CITIES:
                city_rows = 0

                for chunk_start, chunk_end in month_ranges(start_date, end_date):
                    params = {
                        "latitude": city["latitude"],
                        "longitude": city["longitude"],
                        "hourly": HOURLY_VARIABLES,
                        "start_date": chunk_start.isoformat(),
                        "end_date": chunk_end.isoformat(),
                        "timezone": "Asia/Jakarta",
                        "temperature_unit": "celsius",
                        "wind_speed_unit": "kmh",
                        "precipitation_unit": "mm",
                        "models": SOURCE_MODEL,
                    }

                    response = session.get(API_URL, params=params, timeout=(15, 120))
                    response.raise_for_status()
                    payload = response.json()

                    hourly = payload.get("hourly") or {}
                    times = hourly.get("time") or []
                    if not times:
                        raise RuntimeError(
                            "Open-Meteo returned no hourly timestamps for "
                            f"{city['city']} {chunk_start}..{chunk_end}. "
                            f"Response keys: {list(payload.keys())}"
                        )

                    # Validate that each requested variable has the same number
                    # of hourly values as the timestamp array.
                    for variable in WEATHER_COLUMNS:
                        values = hourly.get(variable)
                        if values is None or len(values) != len(times):
                            raise RuntimeError(
                                f"Invalid API array for {variable} in "
                                f"{city['city']} {chunk_start}..{chunk_end}"
                            )

                    rows = []
                    for index, timestamp in enumerate(times):
                        # API timezone is Asia/Jakarta. The warehouse uses
                        # TIMESTAMP WITHOUT TIME ZONE for local wall-clock time,
                        # matching the existing air-quality fact timestamps.
                        valid_at = datetime.fromisoformat(timestamp)
                        rows.append(
                            (
                                city["city"],
                                city["latitude"],
                                city["longitude"],
                                valid_at,
                                safe_hourly_value(hourly, "temperature_2m", index),
                                safe_hourly_value(hourly, "relative_humidity_2m", index),
                                safe_hourly_value(hourly, "wind_speed_10m", index),
                                safe_hourly_value(hourly, "wind_direction_10m", index),
                                safe_hourly_value(hourly, "precipitation", index),
                                safe_hourly_value(hourly, "boundary_layer_height", index),
                                safe_hourly_value(hourly, "shortwave_radiation", index),
                                SOURCE_NAME,
                                SOURCE_MODEL,
                            )
                        )

                    with conn.cursor() as cur:
                        execute_values(cur, upsert_sql, rows, page_size=500)

                    request_count += 1
                    city_rows += len(rows)
                    total_rows += len(rows)

                    print(
                        f"[METEO] {city['city']} {chunk_start}..{chunk_end}: "
                        f"{len(rows)} hourly rows upserted"
                    )
                    # Be conservative with the free public API.
                    time.sleep(0.25)

                city_totals[city["city"]] = city_rows

        result = {
            "status": "SUCCESS",
            "source": SOURCE_NAME,
            "model": SOURCE_MODEL,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "requests": request_count,
            "rows_upserted": total_rows,
            "rows_by_city": city_totals,
        }
        print(f"[METEO] Extraction result: {result}")
        return result

    spark_clean_transform = SparkSubmitOperator(
        task_id="spark_clean_transform_meteorology",
        application="/opt/airflow/spark_jobs/transform_meteorology.py",
        conn_id="spark_default",
        jars="/usr/share/java/postgresql.jar",
        conf={
            "spark.driver.memory": "768m",
            "spark.executor.memory": "768m",
            "spark.driver.host": "airflow-scheduler",
            "spark.driver.bindAddress": "0.0.0.0",
        },
        env_vars={
            "DW_HOST": "postgres",
            "DW_PORT": "5432",
            "DW_DB": os.getenv("DW_DB", "air_quality_dw"),
            "DW_USER": os.getenv("DW_USER", "platform"),
            "DW_PASSWORD": os.getenv("DW_PASSWORD", "platform123"),
        },
        verbose=True,
    )

    @task(task_id="load_meteorology_warehouse")
    def load_meteorology_warehouse() -> dict:
        """Load clean meteorology into shared dimensions and its own fact table."""
        sql = """
        INSERT INTO warehouse.dim_location (city, latitude, longitude)
        SELECT DISTINCT city, latitude, longitude
        FROM staging.meteorology_clean
        ON CONFLICT (city) DO UPDATE SET
            latitude = EXCLUDED.latitude,
            longitude = EXCLUDED.longitude,
            updated_at = NOW();

        INSERT INTO warehouse.dim_time (
            time_key, valid_at, full_date, year, month, day, hour, day_of_week
        )
        SELECT DISTINCT
            TO_CHAR(valid_at, 'YYYYMMDDHH24')::BIGINT,
            valid_at,
            valid_at::DATE,
            EXTRACT(YEAR FROM valid_at)::SMALLINT,
            EXTRACT(MONTH FROM valid_at)::SMALLINT,
            EXTRACT(DAY FROM valid_at)::SMALLINT,
            EXTRACT(HOUR FROM valid_at)::SMALLINT,
            TRIM(TO_CHAR(valid_at, 'Day'))
        FROM staging.meteorology_clean
        ON CONFLICT (time_key) DO NOTHING;

        INSERT INTO warehouse.fact_meteorology (
            location_key, time_key,
            temperature_2m, relative_humidity_2m,
            wind_speed_10m, wind_direction_10m,
            precipitation, boundary_layer_height,
            shortwave_radiation, source_model
        )
        SELECT
            l.location_key,
            t.time_key,
            m.temperature_2m,
            m.relative_humidity_2m,
            m.wind_speed_10m,
            m.wind_direction_10m,
            m.precipitation,
            m.boundary_layer_height,
            m.shortwave_radiation,
            m.source_model
        FROM staging.meteorology_clean m
        JOIN warehouse.dim_location l
          ON l.city = m.city
        JOIN warehouse.dim_time t
          ON t.valid_at = m.valid_at
        ON CONFLICT (location_key, time_key) DO UPDATE SET
            temperature_2m = EXCLUDED.temperature_2m,
            relative_humidity_2m = EXCLUDED.relative_humidity_2m,
            wind_speed_10m = EXCLUDED.wind_speed_10m,
            wind_direction_10m = EXCLUDED.wind_direction_10m,
            precipitation = EXCLUDED.precipitation,
            boundary_layer_height = EXCLUDED.boundary_layer_height,
            shortwave_radiation = EXCLUDED.shortwave_radiation,
            source_model = EXCLUDED.source_model,
            loaded_at = NOW();
        """

        with dw_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                cur.execute(
                    """
                    SELECT
                        COUNT(*) AS total_rows,
                        COUNT(DISTINCT l.city) AS cities,
                        MIN(t.valid_at),
                        MAX(t.valid_at)
                    FROM warehouse.fact_meteorology f
                    JOIN warehouse.dim_location l USING (location_key)
                    JOIN warehouse.dim_time t USING (time_key)
                    """
                )
                total_rows, cities, first_data, last_data = cur.fetchone()

        result = {
            "total_rows": total_rows,
            "cities": cities,
            "first_data": str(first_data),
            "last_data": str(last_data),
        }
        print(f"[METEO] Warehouse load result: {result}")
        return result

    @task(task_id="meteorology_data_quality_check")
    def meteorology_data_quality_check() -> dict:
        """Check configured-city coverage and non-null values before analytics use."""
        with dw_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        COUNT(*) AS total_rows,
                        COUNT(DISTINCT l.city) AS cities,
                        MIN(t.valid_at),
                        MAX(t.valid_at),
                        COUNT(f.boundary_layer_height),
                        COUNT(f.wind_speed_10m),
                        COUNT(f.temperature_2m),
                        COUNT(f.relative_humidity_2m),
                        COUNT(f.precipitation),
                        COUNT(f.shortwave_radiation)
                    FROM warehouse.fact_meteorology f
                    JOIN warehouse.dim_location l USING (location_key)
                    JOIN warehouse.dim_time t USING (time_key)
                    """
                )
                row = cur.fetchone()

                cur.execute(
                    """
                    SELECT l.city, COUNT(*) AS rows,
                           COUNT(f.boundary_layer_height) AS blh_valid,
                           COUNT(f.wind_speed_10m) AS wind_valid,
                           COUNT(f.temperature_2m) AS temp_valid
                    FROM warehouse.fact_meteorology f
                    JOIN warehouse.dim_location l USING (location_key)
                    GROUP BY l.city
                    ORDER BY l.city
                    """
                )
                by_city = cur.fetchall()

        (
            total_rows, cities, first_data, last_data,
            blh_valid, wind_valid, temp_valid, humidity_valid,
            precipitation_valid, radiation_valid,
        ) = row

        if total_rows == 0:
            raise RuntimeError("Meteorology fact table is empty.")
        if cities != len(CITIES):
            raise RuntimeError(
                f"Expected {len(CITIES)} cities, found {cities}. "
                "Check API extraction and warehouse loading."
            )

        valid_counts = {
            "boundary_layer_height": blh_valid,
            "wind_speed_10m": wind_valid,
            "temperature_2m": temp_valid,
            "relative_humidity_2m": humidity_valid,
            "precipitation": precipitation_valid,
            "shortwave_radiation": radiation_valid,
        }
        missing = [name for name, count in valid_counts.items() if count == 0]
        if missing:
            raise RuntimeError(
                "No valid values found for required meteorology variables: "
                + ", ".join(missing)
            )

        result = {
            "status": "PASS",
            "total_rows": total_rows,
            "cities": cities,
            "first_data": str(first_data),
            "last_data": str(last_data),
            "valid_counts": valid_counts,
            "rows_by_city": [
                {
                    "city": city,
                    "rows": rows,
                    "blh_valid": blh,
                    "wind_valid": wind,
                    "temperature_valid": temp,
                }
                for city, rows, blh, wind, temp in by_city
            ],
        }
        print(f"[METEO] DQ result: {result}")
        return result

    extracted = extract_meteorology_to_raw()
    loaded = load_meteorology_warehouse()
    checked = meteorology_data_quality_check()

    extracted >> spark_clean_transform >> loaded >> checked


meteorology_historical_backfill()
