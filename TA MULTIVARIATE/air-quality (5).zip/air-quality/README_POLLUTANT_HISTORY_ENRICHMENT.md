# Historical Pollutant Enrichment: PM10, NO2, and CO

This update fills historical NULL values for the three additional air-quality
predictors selected for analytics and future multivariate machine learning:

- `pm10` — PM10 concentration
- `nitrogen_dioxide` — NO2 concentration
- `carbon_monoxide` — CO concentration

## Existing architecture retained

No new source or pipeline is introduced. The existing Open-Meteo CAMS Global
batch flow remains:

`Open-Meteo Air Quality API -> Airflow -> staging.air_quality_raw -> Spark -> staging.air_quality_clean -> warehouse.fact_air_quality`

The current warehouse schema already contains all three columns in raw and fact
tables. The current API extraction, Spark transformation, and warehouse load
already carry these columns. This update closes the historical-enrichment gap:
previous recovery detected missing timestamps but did not repair pollutant
columns that were NULL on timestamps already present.

## What changed

1. `backfill_air_quality_history.py`
   - A city-month is skipped only when timestamps are complete and PM10, CO,
     and NO2 are all populated.
   - If timestamps exist but one or more of the selected pollutant values are
     NULL, the month is fetched again from Open-Meteo.
   - Existing rows are updated only to fill NULL PM10, CO, and NO2 values.
     Existing PM2.5 and other stored pollutant values are not overwritten.
   - Missing timestamps are inserted with the full seven-parameter API payload.

2. `recover_air_quality_gaps.py`
   - Startup recovery and scheduled recovery now detect both missing timestamp
     rows and existing rows with NULL PM10, CO, or NO2.
   - The same idempotent repair runs automatically when Batch is ON.
   - A PostgreSQL advisory lock continues to prevent overlapping recovery runs.
   - The summary reports existing rows requiring enrichment, requested repair
     rows, rows inserted/enriched, and source NULL counts.

3. `air_quality_pipeline.py`
   - Data-quality validation now also checks that CO and NO2 are not negative,
     alongside PM2.5, PM10, and European AQI.

## Run the historical enrichment now

From PowerShell in the project folder:

```powershell
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/backfill_air_quality_history.py
```

This uses the default period beginning `2026-01-01` and discovers the latest
complete date available from Open-Meteo. It checks all five configured cities.
It does not require `--force`: city-months with complete timestamps but NULL
PM10/CO/NO2 are now detected as incomplete. The write operation respects the
dashboard's Batch switch; set Batch to ON before running it. A `--dry-run` is
read-only and can still be used while Batch is OFF.

Optional: validate the API and database-independent record preparation first:

```powershell
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/backfill_air_quality_history.py --start-date 2026-01-01 --end-date 2026-01-31 --dry-run
```

Optional: restrict to one city:

```powershell
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/backfill_air_quality_history.py --city Semarang
```

## Automatic behavior after the one-time historical enrichment

When Batch is ON:

- On Airflow scheduler startup, `recover_air_quality_gaps.py` checks the
  configured historical period and repairs missing timestamps plus NULL
  PM10/CO/NO2 values.
- Every scheduled batch run (every three hours) performs the same check before
  normal API extraction, Spark transformation, and warehouse loading.
- When Batch is OFF, startup and scheduled recovery remain disabled, following
  the project's existing Pipeline Control decision.

## Verify the result

Run this query to see row counts and NULL counts for each city:

```powershell
docker compose exec postgres psql -U platform -d air_quality_dw -P pager=off -c "SELECT city, COUNT(*) AS total_rows, COUNT(*) FILTER (WHERE pm10 IS NULL) AS pm10_null, COUNT(*) FILTER (WHERE nitrogen_dioxide IS NULL) AS no2_null, COUNT(*) FILTER (WHERE carbon_monoxide IS NULL) AS co_null, MIN(valid_at) AS first_timestamp, MAX(valid_at) AS last_timestamp FROM staging.air_quality_raw GROUP BY city ORDER BY city;"
```

The three NULL counts should decrease after enrichment. A remaining NULL is not
fabricated: it means Open-Meteo returned no value for that pollutant/timestamp,
or the API could not provide the observation.

After the historical backfill completes, trigger or wait for the regular
`air_quality_end_to_end` batch run so Spark and `warehouse.fact_air_quality`
are refreshed from the updated raw staging table.

## Scope

This change prepares the data layer for subsequent analytics and multivariate
ML feature engineering. It does not yet change the current ML model, which
continues to forecast PM2.5 using its existing PM2.5-only feature set.
