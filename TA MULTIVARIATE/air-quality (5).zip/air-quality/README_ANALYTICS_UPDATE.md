# Dashboard Analytics — Blueprint Implementasi

Dashboard Analitik pada Streamlit dibagi menjadi enam bagian:

1. **Overview** — ringkasan European AQI, kategori dominan, perbandingan AQI antarkota, dan tren.
2. **City Comparison & Temporal Analysis** — pemilihan satu polutan, perbandingan rata-rata antarkota, tren waktu, heatmap jam-kota, dan distribusi.
3. **Bivariate Analysis** — satu polutan pilihan dibandingkan dengan European AQI menggunakan scatter plot dan Pearson correlation.
4. **Multivariate Analysis** — Pearson atau Spearman correlation matrix untuk enam polutan dan enam variabel meteorologi.
5. **Meteorological Analysis** — satu polutan pilihan dibandingkan dengan enam variabel meteorologi, termasuk lagged correlation.
6. **Conclusion** — rangkuman temuan aktual dan rekomendasi tindak lanjut.

## Variabel

### Polutan
- PM2.5 (`pm2_5`)
- PM10 (`pm10`)
- CO (`carbon_monoxide`)
- NO2 (`nitrogen_dioxide`)
- SO2 (`sulphur_dioxide`)
- O3 (`ozone`)

### Meteorologi
- Temperature 2 m (`temperature_2m`)
- Relative humidity 2 m (`relative_humidity_2m`)
- Wind speed 10 m (`wind_speed_10m`)
- Precipitation (`precipitation`)
- Boundary layer height (`boundary_layer_height`)
- Shortwave radiation (`shortwave_radiation`)

Wind direction tidak dimasukkan ke korelasi biasa karena sifatnya sirkular (0° dan 360° mewakili arah yang sama).

## Lagged correlation

Lag 0 membandingkan meteorologi dan polutan pada timestamp yang sama. Lag 1, 3, 6, dan 12 jam memasangkan meteorologi pada waktu `t` dengan polutan pada waktu `t + lag`.

Pencocokan dilakukan dengan **city + timestamp aktual**, bukan dengan menggeser nomor baris. Karena itu, jam yang hilang tidak dianggap sebagai satu jam berikutnya. Korelasi lagged menggunakan Pearson dan menampilkan jumlah pasangan observasi (`n_pairs`) untuk setiap pasangan variabel dan lag.

## Catatan metodologi

- Pearson mengukur hubungan linear; Spearman mengukur hubungan monotonik.
- Correlation matrix adalah analisis hubungan berpasangan untuk banyak variabel, bukan model prediktif atau bukti kausal.
- European AQI tidak dimasukkan ke correlation matrix karena indeks tersebut dibentuk dari subindeks polutan tertentu. AQI dibahas terpisah pada Bivariate Analysis.
- CO bukan komponen European AQI.
- Data meteorologi digabungkan dengan data kualitas udara menggunakan `LEFT JOIN` berdasarkan `location_key` dan `time_key`. Baris kualitas udara tetap dipertahankan ketika data meteorologi tidak tersedia.
- Korelasi gabungan antarkota dapat dipengaruhi perbedaan karakteristik kota. Gunakan filter kota untuk memeriksa konsistensi pola per kota.
- Lagged correlation menunjukkan urutan waktu statistik, bukan bukti bahwa meteorologi menyebabkan perubahan polutan.
- Sumber Open-Meteo/CAMS merupakan data berbasis model, bukan pengukuran langsung stasiun. Validasi dengan data pemantauan resmi diperlukan sebelum menyusun rekomendasi kebijakan.

## Menjalankan pembaruan

Dari direktori project yang berisi `docker-compose.yml`:

```powershell
docker compose build dashboard
docker compose up -d dashboard
```

Buka `http://localhost:8501`, lalu pilih tab **Analitik**. Gunakan tombol **Muat ulang analitik** setelah pipeline memperbarui data.

## Pengujian helper analitik

Dari folder `dashboard` pada lingkungan Python yang memiliki `pandas`:

```powershell
python -m unittest -v test_analytics_utils.py
```

Pengujian mencakup konfigurasi variabel, perhitungan korelasi, dan validasi bahwa lagged correlation memasangkan timestamp aktual serta tidak melompati jam yang hilang.
