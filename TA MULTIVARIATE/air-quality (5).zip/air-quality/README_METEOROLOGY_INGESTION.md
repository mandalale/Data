# Meteorology Data Integration

This update adds a separate meteorology ingestion path without changing the
existing air-quality extraction, Spark transformation, or warehouse fact table.

## Data source

- API: Open-Meteo Historical Forecast API
- Endpoint: `https://historical-forecast-api.open-meteo.com/v1/forecast`
- Model: `ecmwf_ifs` (ECMWF IFS HRES, global 9 km, hourly)
- Time zone: `Asia/Jakarta`
- Wind speed: km/h
- Temperature: °C
- Precipitation: mm
- Radiation: W/m²
- Backfill range: inferred from `MIN(valid_at)` and `MAX(valid_at)` in
  `staging.air_quality_raw`; by default, the end date is capped at the latest
  complete local calendar day. Optional environment overrides are supported.

The values are model-derived weather data, not direct BMKG station observations.
The selected model is stored in `source_model` so later analysis can retain
source provenance. Attribute the weather data to Open-Meteo and ECMWF IFS when
presenting results.

## Variables

| API field | Warehouse field | Unit |
|---|---|---|
| `temperature_2m` | `temperature_2m` | °C |
| `relative_humidity_2m` | `relative_humidity_2m` | % |
| `wind_speed_10m` | `wind_speed_10m` | km/h |
| `wind_direction_10m` | `wind_direction_10m` | degrees |
| `precipitation` | `precipitation` | mm |
| `boundary_layer_height` | `boundary_layer_height` | m |
| `shortwave_radiation` | `shortwave_radiation` | W/m² |

Wind direction is included as an additional driver because wind speed alone
cannot describe the direction of pollutant transport.

## Data flow

```text
Open-Meteo Historical Forecast API
              |
              v
Airflow DAG: meteorology_historical_backfill
              |
              v
staging.meteorology_raw
              |
              v
Spark: transform_meteorology.py
              |
              v
staging.meteorology_clean
              |
              v
warehouse.fact_meteorology
              |
              +---- shared warehouse.dim_location
              +---- shared warehouse.dim_time
              |
              v
warehouse.vw_air_quality_meteorology
```

## Database objects

- `staging.meteorology_raw`: idempotent API landing table.
- `staging.meteorology_clean`: Spark-cleaned table.
- `warehouse.fact_meteorology`: hourly meteorology fact table.
- `warehouse.vw_air_quality_meteorology`: timestamp-aligned inner join with
  air-quality facts, intended for later scatter plots and correlation analysis.

The migration is idempotent and is executed by the existing
`pipeline-control-init` service on every `docker compose up`. It does not
require deleting or recreating the PostgreSQL volume.

## Run the initial backfill

From the project directory in PowerShell:

```powershell
docker compose up -d pipeline-control-init

docker compose up -d airflow-dag-processor airflow-scheduler

docker compose logs -f airflow-scheduler
```

Open Airflow at `http://localhost:8080`, locate
`meteorology_historical_backfill`, and trigger it manually.

The default date range is read from the existing air-quality raw table. For the
current project baseline this should cover the available 2026 air-quality
history. Optional overrides can be placed in `.env`:

```dotenv
METEOROLOGY_START_DATE=2026-01-01
METEOROLOGY_END_DATE=2026-11-12
```

After changing `.env`, recreate the Airflow services so the environment is
refreshed:

```powershell
docker compose up -d --force-recreate airflow-dag-processor airflow-scheduler
```

The backfill is safe to rerun: raw and fact tables use `(city, valid_at)` and
`(location_key, time_key)` upserts respectively.

## Verify the result

Raw staging:

```powershell
docker compose exec -T postgres psql -U platform -d air_quality_dw -c "SELECT 'RAW' AS layer, COUNT(*) AS total_rows, COUNT(DISTINCT city) AS cities, MIN(valid_at) AS first_data, MAX(valid_at) AS last_data, COUNT(boundary_layer_height) AS blh, COUNT(wind_speed_10m) AS wind, COUNT(temperature_2m) AS temperature, COUNT(relative_humidity_2m) AS humidity, COUNT(precipitation) AS precipitation, COUNT(shortwave_radiation) AS radiation FROM staging.meteorology_raw;"
```

Warehouse fact:

```powershell
docker compose exec -T postgres psql -U platform -d air_quality_dw -c "SELECT COUNT(*) AS total_rows, COUNT(DISTINCT l.city) AS cities, MIN(t.valid_at) AS first_data, MAX(t.valid_at) AS last_data, COUNT(f.boundary_layer_height) AS blh, COUNT(f.wind_speed_10m) AS wind, COUNT(f.temperature_2m) AS temperature FROM warehouse.fact_meteorology f JOIN warehouse.dim_location l USING (location_key) JOIN warehouse.dim_time t USING (time_key);"
```

Aligned records available for later analytics:

```powershell
docker compose exec -T postgres psql -U platform -d air_quality_dw -c "SELECT COUNT(*) AS aligned_rows, COUNT(DISTINCT city) AS cities, MIN(valid_at) AS first_data, MAX(valid_at) AS last_data FROM warehouse.vw_air_quality_meteorology;"
```

Per-city coverage:

```powershell
docker compose exec -T postgres psql -U platform -d air_quality_dw -c "SELECT l.city, COUNT(*) AS rows, COUNT(f.boundary_layer_height) AS blh_valid, COUNT(f.wind_speed_10m) AS wind_valid, COUNT(f.temperature_2m) AS temperature_valid FROM warehouse.fact_meteorology f JOIN warehouse.dim_location l USING (location_key) GROUP BY l.city ORDER BY l.city;"
```

## Important interpretation notes

1. Air-quality and meteorology data are both model-derived products. They are
   not equivalent to co-located ground-station observations.
2. The meteorology source model and units are retained in the warehouse.
3. Do not interpret correlation as causation.
4. Align pollutant and meteorology observations by the same city and local
   timestamp before computing scatter plots or Pearson correlations.
5. Check the actual temporal resolution and missingness before interpreting
   hourly relationships. Do not assume every returned hourly timestamp is an
   independent model observation.
6. Historical forecast model versions may change over time. The explicit model
   selection prevents mixing different providers/models, but does not guarantee
   that the underlying model version is unchanged for the entire period.
