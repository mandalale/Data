
import json
import math
import urllib.parse
import urllib.request

# Kandidat lokasi observasi
locations = [
    {
        "name": "Samarinda",
        "latitude": -0.5022,
        "longitude": 117.1536
    },
    {
        "name": "Balikpapan",
        "latitude": -1.2675,
        "longitude": 116.8289
    },
    {
        "name": "Bontang",
        "latitude": 0.1324,
        "longitude": 117.4854
    }
]

# Menguji domain CAMS Global secara eksplisit
params = {
    "latitude": ",".join(str(x["latitude"]) for x in locations),
    "longitude": ",".join(str(x["longitude"]) for x in locations),
    "hourly": "pm2_5",
    "domains": "cams_global",
    "timezone": "Asia/Jakarta",
    "forecast_days": 1
}

url = (
    "https://air-quality-api.open-meteo.com/v1/air-quality?"
    + urllib.parse.urlencode(params, safe=",")
)

print("Requesting CAMS Global API...")

try:
    with urllib.request.urlopen(url, timeout=30) as response:
        results = json.loads(response.read().decode())

    if isinstance(results, dict):
        results = [results]

    if len(results) != len(locations):
        raise ValueError(
            f"Expected {len(locations)} responses, "
            f"received {len(results)}"
        )

    grid_results = []

    print("\n=== CAMS GLOBAL GRID VALIDATION ===")

    for location, result in zip(locations, results):
        grid_lat = result["latitude"]
        grid_lon = result["longitude"]
        elevation = result.get("elevation")

        grid_results.append({
            "name": location["name"],
            "latitude": grid_lat,
            "longitude": grid_lon,
            "elevation": elevation
        })

        print(f"\nCity: {location['name']}")
        print(
            f"Requested coordinate: "
            f"{location['latitude']}, {location['longitude']}"
        )
        print(
            f"Returned grid center: "
            f"{grid_lat}, {grid_lon}"
        )
        print(f"Elevation: {elevation}")

    # Identifikasi grid yang sama
    print("\n=== GRID UNIQUENESS ===")

    unique_grids = {}

    for item in grid_results:
        key = (
            round(item["latitude"], 5),
            round(item["longitude"], 5)
        )

        unique_grids.setdefault(key, []).append(item["name"])

    for grid, cities in unique_grids.items():
        print(f"Grid {grid}: {', '.join(cities)}")

    print(
        f"\nTotal cities: {len(locations)}"
    )
    print(
        f"Unique CAMS grids: {len(unique_grids)}"
    )

    if len(unique_grids) == 3:
        print("RESULT: All three cities use distinct grids.")
    elif len(unique_grids) == 2:
        print("RESULT: Only two distinct grids were returned.")
    else:
        print("RESULT: Grid overlap detected. Further inspection required.")

    # Jarak antarpusat grid
    def haversine(lat1, lon1, lat2, lon2):
        R = 6371.0

        p1 = math.radians(lat1)
        p2 = math.radians(lat2)

        dp = math.radians(lat2 - lat1)
        dl = math.radians(lon2 - lon1)

        a = (
            math.sin(dp / 2) ** 2
            + math.cos(p1) * math.cos(p2)
            * math.sin(dl / 2) ** 2
        )

        return 2 * R * math.asin(math.sqrt(a))

    print("\n=== GRID CENTER DISTANCES ===")

    for i in range(len(grid_results)):
        for j in range(i + 1, len(grid_results)):
            a = grid_results[i]
            b = grid_results[j]

            distance = haversine(
                a["latitude"], a["longitude"],
                b["latitude"], b["longitude"]
            )

            print(
                f"{a['name']} - {b['name']}: "
                f"{distance:.2f} km"
            )

except Exception as error:
    print(f"\nAPI TEST FAILED: {error}")
