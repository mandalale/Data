# Integrasi Machine Learning — Air Quality Dashboard

Perubahan ini menambahkan tab **Forecast & Rekomendasi** pada dashboard Streamlit serta task ML setelah `quality_check` pada DAG `air_quality_end_to_end`.

## Perubahan utama

- `dashboard/app.py`: tab ketiga menampilkan forecast 6 jam, grafik aktual vs prediksi, perbandingan model, metrik MAE/RMSE, dan rekomendasi berbasis European AQI.
- `spark/jobs/air_quality_ml.py`: mengambil data historis dari `staging.air_quality_raw`, membandingkan Persistence, Seasonal Naive 24 jam, dan Random Forest, lalu menyimpan hasil ke PostgreSQL.
- `airflow/dags/air_quality_pipeline.py`: task `ml_forecast_6h` berjalan setelah `quality_check` berhasil.
- `Dockerfile.airflow`: menambahkan `pandas` dan `scikit-learn` ke image Airflow.

## Cara menerapkan

1. Ekstrak bundle dan buka terminal di folder `air-quality` yang berisi `docker-compose.yml`.
2. Build ulang image Airflow dan dashboard karena kode dashboard disalin ke image saat build:
   ```powershell
   docker compose build airflow-init airflow-api-server airflow-scheduler airflow-dag-processor dashboard
   ```
3. Recreate service yang menggunakan image baru:
   ```powershell
   docker compose up -d --force-recreate airflow-init airflow-api-server airflow-scheduler airflow-dag-processor dashboard
   ```
4. Trigger DAG:
   ```powershell
   docker compose exec airflow-scheduler airflow dags trigger air_quality_end_to_end
   ```
5. Periksa status run/task di Airflow UI atau jalankan:
   ```powershell
   docker compose exec airflow-scheduler airflow dags list-runs air_quality_end_to_end --output table
   ```
6. Setelah task `ml_forecast_6h` sukses, buka dashboard Streamlit dan klik **Muat ulang forecast** pada tab ketiga.

## Verifikasi tabel ML

Tabel dibuat otomatis oleh script pada eksekusi ML pertama. Verifikasi jumlah prediksi dari forecast origin terbaru per kota:

```sql
SELECT city, forecast_origin, COUNT(*) AS forecast_rows
FROM ml.air_quality_forecast f
WHERE forecast_origin = (
    SELECT MAX(f2.forecast_origin)
    FROM ml.air_quality_forecast f2
    WHERE f2.city = f.city
)
GROUP BY city, forecast_origin
ORDER BY city;
```

Jika kelima kota sukses diproses, targetnya adalah 42 baris per kota (6 horizon × 7 parameter), total 210 baris untuk origin terbaru.

## Catatan data dan interpretasi

- `staging.air_quality_raw.valid_at` adalah `TIMESTAMP WITHOUT TIME ZONE` yang menyimpan label jam lokal Asia/Jakarta dari API. Script ML mempertahankan interpretasi tersebut dan tidak mengubahnya menjadi UTC.
- Baris forecast API yang berada di masa depan dikecualikan dari data training.
- Jam yang hilang dipertahankan sebagai gap; script tidak mengisi nilai observasi palsu. Sampel yang membutuhkan lag/target hilang dikeluarkan dari training/evaluasi.
- Model dipilih per kota, parameter, dan horizon berdasarkan MAE pada holdout kronologis. RMSE disimpan sebagai metrik tambahan.
- Data historis saat ini relatif pendek sehingga hasil adalah proof-of-concept akademik, bukan sistem peringatan kualitas udara operasional.
- Rekomendasi dashboard menggunakan kategori European AQI sebagai panduan edukatif dan bukan peringatan resmi.
- Bundle ini sudah diperiksa sintaks Python-nya, tetapi belum dijalankan di Docker milik pengguna. Verifikasi akhir tetap perlu dilakukan setelah rebuild.
