# Pipeline Control Center

The dashboard's **Pengaturan** tab controls three independent runtime switches.
The source of truth is `air_quality_dw.control.pipeline_settings`.

## Switches

| Switch | Controlled components | Behavior when OFF |
|---|---|---|
| `batch_enabled` | Startup gap recovery, scheduled gap recovery, Open-Meteo batch extraction, Spark batch transform, warehouse load, DQ, and CAMS task | Startup recovery and startup batch trigger are skipped; scheduled batch DAG runs short-circuit |
| `streaming_enabled` | Sensor simulator and Spark Structured Streaming query | Simulator stops writing; Spark query stops gracefully and preserves checkpoint/incoming files |
| `ml_enabled` | Independent `air_quality_ml` DAG | Hourly ML training/scoring/evaluation/forecast task is skipped |

All three settings default to `TRUE` for a new database.

## Runtime behavior

- Dashboard updates the singleton row in PostgreSQL immediately.
- Airflow checks batch/ML switches at the beginning of each DAG run.
- The startup scheduler script checks `batch_enabled` before startup recovery and before queuing the one-off startup batch run.
- The gap recovery script also checks `batch_enabled`, protecting direct/manual invocation.
- Simulator and Spark streaming poll `streaming_enabled` every `PIPELINE_CONTROL_POLL_SECONDS` (default 5 seconds).
- Spark uses the existing `/opt/stream/checkpoint` location. OFF stops the active query gracefully; ON starts a new query against the same checkpoint. Unprocessed incoming files are retained.
- A batch or ML task already in progress is not force-killed when its switch changes. The new state is enforced at the next DAG gate. This avoids leaving a partially committed batch/model run.

## Database migration

`sql/04-pipeline-control.sql` is idempotent. The `pipeline-control-init` one-shot Compose service runs it after PostgreSQL is healthy. This is important for existing persistent volumes because Docker's `/docker-entrypoint-initdb.d` scripts are not re-run once a PostgreSQL data directory has already been initialized.

## Schedules

- Batch: `0 */3 * * *` (every three hours).
- ML: `0 * * * *` (every hour).
- Streaming: continuous Structured Streaming with a five-second processing trigger, subject to runtime control.

## Important interpretation

`ON` means a pipeline is allowed to execute; it does not guarantee that the container, API, scheduler, or Spark query is healthy. The dashboard separately displays the latest persisted data timestamp for each path.
