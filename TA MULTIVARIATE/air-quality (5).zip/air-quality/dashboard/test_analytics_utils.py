import unittest

import pandas as pd

from analytics_utils import (
    METEOROLOGY_CONFIG,
    POLLUTANT_CONFIG,
    VARIABLE_CONFIG,
    build_hourly_heatmap,
    build_temporal_series,
    calculate_lagged_correlations,
    classify_european_aqi,
    correlation_analysis,
    resolve_period_window,
    summarize_by_city,
)


class AnalyticsUtilsTests(unittest.TestCase):
    def test_european_aqi_boundaries(self):
        self.assertEqual(classify_european_aqi(20), "Good")
        self.assertEqual(classify_european_aqi(20.1), "Fair")
        self.assertEqual(classify_european_aqi(40), "Fair")
        self.assertEqual(classify_european_aqi(60), "Moderate")
        self.assertEqual(classify_european_aqi(80), "Poor")
        self.assertEqual(classify_european_aqi(100), "Very Poor")
        self.assertEqual(classify_european_aqi(254), "Extremely Poor")
        self.assertEqual(classify_european_aqi(None), "Data tidak tersedia")

    def test_rolling_period_windows(self):
        latest = pd.Timestamp("2026-11-12 22:00:00")
        for mode, expected in [("7 Hari", 168), ("3 Hari", 72), ("24 Jam", 24)]:
            start, end, count = resolve_period_window(mode, latest)
            self.assertEqual(count, expected)
            self.assertEqual((end - start).total_seconds() / 3600, expected)
            self.assertEqual(end, latest + pd.Timedelta(hours=1))

    def test_month_and_custom_period_are_inclusive_calendar_dates(self):
        latest = pd.Timestamp("2026-11-12 22:00:00")
        start, end, count = resolve_period_window("Bulanan", latest, month_key="2026-02")
        self.assertEqual(start, pd.Timestamp("2026-02-01 00:00:00"))
        self.assertEqual(end, pd.Timestamp("2026-03-01 00:00:00"))
        self.assertEqual(count, 28 * 24)

        start, end, count = resolve_period_window(
            "Custom", latest, custom_range=(pd.Timestamp("2026-11-01").date(), pd.Timestamp("2026-11-03").date())
        )
        self.assertEqual(start, pd.Timestamp("2026-11-01 00:00:00"))
        self.assertEqual(end, pd.Timestamp("2026-11-04 00:00:00"))
        self.assertEqual(count, 72)

    def test_summary_preserves_all_cities_and_calculates_coverage(self):
        metadata = pd.DataFrame({
            "city": ["Bandung", "Jakarta", "Semarang"],
            "latitude": [-6.9, -6.2, -7.0],
            "longitude": [107.6, 106.8, 110.4],
        })
        data = pd.DataFrame({
            "city": ["Bandung", "Bandung", "Jakarta"],
            "european_aqi": [30.0, 50.0, 70.0],
        })
        result = summarize_by_city(data, metadata, "European AQI", 4).set_index("city")
        self.assertEqual(len(result), 3)
        self.assertEqual(result.loc["Bandung", "mean"], 40.0)
        self.assertAlmostEqual(result.loc["Bandung", "coverage_pct"], 50.0)
        self.assertEqual(result.loc["Semarang", "valid_count"], 0)
        self.assertEqual(result.loc["Semarang", "coverage_pct"], 0.0)

    def test_temporal_series_and_heatmap(self):
        frame = pd.DataFrame({
            "city": ["Bandung", "Bandung", "Jakarta"],
            "valid_at": pd.to_datetime([
                "2026-11-12 01:00:00", "2026-11-12 02:00:00", "2026-11-12 01:00:00"
            ]),
            "pm2_5": [10.0, 20.0, 30.0],
        })
        trend = build_temporal_series(frame, "PM2.5", "hour")
        self.assertEqual(trend.shape, (2, 2))
        heatmap = build_hourly_heatmap(frame, "PM2.5")
        self.assertEqual(len(heatmap), 3)
        self.assertEqual(set(heatmap["hour"]), {1, 2})

    def test_variable_configuration_contains_six_pollutants_and_six_meteorology_fields(self):
        self.assertEqual(
            list(POLLUTANT_CONFIG.keys()),
            ["PM2.5", "PM10", "CO", "NO₂", "SO₂", "O₃"],
        )
        self.assertEqual(len(METEOROLOGY_CONFIG), 6)
        self.assertIn("European AQI", VARIABLE_CONFIG)

    def test_correlation_analysis_returns_ranked_pairs_and_pair_counts(self):
        frame = pd.DataFrame({
            "pm2_5": [1, 2, 3, 4],
            "pm10": [2, 4, 6, 8],
            "temperature_2m": [4, 3, 2, 1],
        })
        matrix, ranked, counts = correlation_analysis(
            frame, ["pm2_5", "pm10", "temperature_2m"], "pearson"
        )
        self.assertAlmostEqual(matrix.loc["pm2_5", "pm10"], 1.0)
        self.assertAlmostEqual(matrix.loc["pm2_5", "temperature_2m"], -1.0)
        self.assertEqual(int(counts.loc["pm2_5", "pm10"]), 4)
        self.assertEqual(ranked.iloc[0]["n_pairs"], 4)

    def test_lagged_correlation_uses_exact_timestamps_not_row_offsets(self):
        frame = pd.DataFrame({
            "city": ["Bandung"] * 6,
            "valid_at": pd.to_datetime([
                "2026-11-12 00:00", "2026-11-12 01:00", "2026-11-12 02:00",
                "2026-11-12 04:00", "2026-11-12 05:00", "2026-11-12 06:00",
            ]),
            "temperature_2m": [10, 20, 30, 40, 50, 60],
            "pm2_5": [100, 200, 300, 400, 500, 600],
        })
        result = calculate_lagged_correlations(
            frame, "pm2_5", ["temperature_2m"], lags=(0, 1)
        )
        lag_zero = result.loc[result["lag_hours"] == 0].iloc[0]
        lag_one = result.loc[result["lag_hours"] == 1].iloc[0]
        self.assertEqual(lag_zero["n_pairs"], 6)
        # Exact 1-hour pairs exist on 00->01, 01->02, 04->05, and 05->06.
        # The missing 03:00 timestamp must not create a row-offset pair across the gap.
        self.assertEqual(lag_one["n_pairs"], 4)
        self.assertAlmostEqual(lag_one["correlation"], 1.0)


if __name__ == "__main__":
    unittest.main()
