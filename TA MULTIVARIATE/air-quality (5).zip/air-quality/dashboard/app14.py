"""Dashboard kualitas udara lima kota.

Empat tab:
- Live (streaming): data sensor simulasi, diperbarui otomatis tiap 5 detik.
- Per jam (batch): data Open-Meteo yang dimuat DAG Airflow.
- Analitik: eksplorasi data historis batch dari Data Warehouse.
- Prediksi (ML): forecast PM2.5 Random Forest dibandingkan dengan CAMS Global.
"""

import os
from contextlib import closing

import pandas as pd
import psycopg2
import streamlit as st


def query(sql: str, params: tuple | None = None) -> pd.DataFrame:
    """Run a read query against PostgreSQL, optionally with bound parameters."""
    with closing(psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=5,
    )) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
            columns = [column[0] for column in cur.description]
    return pd.DataFrame(rows, columns=columns)


def read_fact() -> pd.DataFrame:
    return query("""
        SELECT l.city, t.valid_at, f.pm2_5, f.pm10, f.european_aqi
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_location AS l ON l.location_key = f.location_key
        JOIN warehouse.dim_time AS t ON t.time_key = f.time_key
        ORDER BY t.valid_at DESC, l.city
    """)


# ---------------------------------------------------------------- jalur streaming

RULE_LABELS = {
    "normalized_city": "Nama kota dibakukan",
    "fixed_format": "Koma diganti titik",
    "nulled_unparseable": "Teks bukan angka → NULL",
    "nulled_negative": "Nilai negatif → NULL",
    "nulled_outlier": "Nilai tidak wajar → NULL",
    "rejected_city": "Ditolak: kota tak dikenal",
    "rejected_time": "Ditolak: waktu tidak wajar",
    "rejected_empty": "Ditolak: semua nilai kosong",
    "duplicates": "Dibuang: duplikat",
}


@st.fragment(run_every="5s")
def render_live() -> None:
    try:
        summary = query("""
            SELECT
                COALESCE(SUM(rows_in), 0) AS rows_in,
                COALESCE(SUM(rows_loaded), 0) AS rows_loaded,
                COALESCE(SUM(normalized_city), 0) AS normalized_city,
                COALESCE(SUM(fixed_format), 0) AS fixed_format,
                COALESCE(SUM(nulled_unparseable), 0) AS nulled_unparseable,
                COALESCE(SUM(nulled_negative), 0) AS nulled_negative,
                COALESCE(SUM(nulled_outlier), 0) AS nulled_outlier,
                COALESCE(SUM(rejected_city), 0) AS rejected_city,
                COALESCE(SUM(rejected_time), 0) AS rejected_time,
                COALESCE(SUM(rejected_empty), 0) AS rejected_empty,
                COALESCE(SUM(duplicates), 0) AS duplicates
            FROM staging.stream_quality_log
            WHERE processed_at >= NOW() - INTERVAL '5 minutes'
        """).iloc[0]
        lag = query("""
            SELECT EXTRACT(EPOCH FROM (NOW() AT TIME ZONE 'Asia/Jakarta') - MAX(reading_at)) AS seconds
            FROM warehouse.fact_sensor_live
        """).iloc[0]["seconds"]
        live = query("""
            SELECT f.reading_at, l.city, f.pm2_5
            FROM warehouse.fact_sensor_live f
            JOIN warehouse.dim_location l USING (location_key)
            WHERE f.reading_at >= (NOW() AT TIME ZONE 'Asia/Jakarta') - INTERVAL '10 minutes'
            ORDER BY f.reading_at
        """)
        raw = query("""
            SELECT received_at AT TIME ZONE 'Asia/Jakarta' AS diterima, dirty_type AS jenis,
                   city AS kota, reading_at AS jam, pm2_5, pm10, ozone
            FROM staging.sensor_raw
            ORDER BY raw_id DESC
            LIMIT 15
        """)
    except (psycopg2.Error, OSError) as exc:
        st.warning("Jalur streaming belum siap. Pastikan service sensor-simulator dan spark-streaming menyala.")
        st.code(str(exc))
        return

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Pesan masuk (5 menit)", f"{int(summary['rows_in']):,}")
    k2.metric("Masuk ke warehouse", f"{int(summary['rows_loaded']):,}")
    k3.metric("Ditolak / duplikat", f"{int(summary['rows_in'] - summary['rows_loaded']):,}")
    k4.metric("Jeda data terakhir", f"{lag:.0f} detik" if pd.notna(lag) else "—")

    left, right = st.columns([3, 2])
    with left:
        st.subheader("PM2.5 live, 10 menit terakhir")
        if live.empty:
            st.info("Belum ada data live. Tunggu beberapa detik setelah simulator menyala.")
        else:
            live["reading_at"] = pd.to_datetime(live["reading_at"])
            trend = live.pivot_table(index="reading_at", columns="city", values="pm2_5", aggfunc="mean")
            st.line_chart(trend, x_label="Waktu (WIB)", y_label="PM2.5 (µg/m³)")
    with right:
        st.subheader("Yang dibersihkan Spark (5 menit)")
        rules = pd.DataFrame(
            {"Jumlah": [int(summary[key]) for key in RULE_LABELS]},
            index=list(RULE_LABELS.values()),
        )
        st.bar_chart(rules, horizontal=True, x_label="Jumlah", y_label="")

    st.subheader("15 pesan mentah terbaru dari sensor")
    st.caption("Baris merah = pesan yang sengaja dibuat kotor oleh simulator. Kolom 'jenis' hanya ada untuk keperluan pembelajaran; sensor sungguhan tidak memberikan label seperti ini.")
    styled = raw.style.apply(
        lambda row: ["background-color: rgba(220, 60, 50, 0.15)" if row["jenis"] != "bersih" else "" for _ in row],
        axis=1,
    )
    st.dataframe(styled, width="stretch", hide_index=True)


# ---------------------------------------------------------------- jalur batch

def render_batch() -> None:
    if st.button("Muat ulang data"):
        st.rerun()

    try:
        data = read_fact()
    except (psycopg2.Error, OSError) as exc:
        st.error("Database belum siap. Periksa status PostgreSQL dan jalankan pipeline Airflow.")
        st.code(str(exc))
        return

    if data.empty:
        st.info("Belum ada baris di fact table. Jalankan DAG air_quality_end_to_end di Airflow, tunggu empat task berhasil, lalu klik Muat ulang data.")
        return

    data["valid_at"] = pd.to_datetime(data["valid_at"])
    cities = sorted(data["city"].unique().tolist())
    selected = st.multiselect("Pilih kota", cities, default=cities)
    if not selected:
        st.info("Pilih sedikitnya satu kota untuk menampilkan grafik.")
        return

    view = data.loc[data["city"].isin(selected)].copy()
    recent = view.loc[view["valid_at"] >= view["valid_at"].max() - pd.Timedelta(days=7)]

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Kota terpilih", len(selected))
    k2.metric("Baris fakta", f"{len(view):,}")
    k3.metric("PM2.5 rerata (µg/m³)", f"{view['pm2_5'].mean():.1f}" if view["pm2_5"].notna().any() else "—")
    k4.metric("Jam data terakhir (WIB)", view["valid_at"].max().strftime("%d/%m/%Y %H:%M"))

    st.subheader("PM2.5 per jam dalam tujuh hari terakhir")
    trend = recent.pivot_table(index="valid_at", columns="city", values="pm2_5", aggfunc="mean")
    if trend.empty:
        st.info("Tidak ada nilai PM2.5 pada rentang ini.")
    else:
        st.line_chart(trend, x_label="Waktu (WIB)", y_label="PM2.5 (µg/m³)")

    st.subheader("Rerata polutan per kota dalam tujuh hari terakhir")
    means = recent.groupby("city", as_index=True)[["pm2_5", "pm10"]].mean()
    st.bar_chart(means, x_label="Kota", y_label="Konsentrasi (µg/m³)")

    st.subheader("50 catatan terbaru")
    st.dataframe(view.head(50), width="stretch", hide_index=True)
    st.caption("Ini data model kualitas udara dari Open-Meteo/CAMS, bukan pembacaan sensor lapangan. Nilai kosong tetap kosong; jangan ditafsirkan sebagai nol. Indeks AQI Eropa hanya ditampilkan jika tersedia.")



# ---------------------------------------------------------------- historical analytics


def read_analytics_bounds() -> pd.DataFrame:
    """Return the available date range and row count in the batch warehouse."""
    return query("""
        SELECT
            MIN(t.full_date) AS min_date,
            MAX(t.full_date) AS max_date,
            COUNT(*) AS total_rows
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_time AS t ON t.time_key = f.time_key
        WHERE t.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
    """)


def read_analytics_cities() -> list[str]:
    """Return cities that currently have batch facts in the warehouse."""
    frame = query("""
        SELECT DISTINCT l.city
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_location AS l ON l.location_key = f.location_key
        ORDER BY l.city
    """)
    return frame["city"].tolist()


def read_analytics_history(
    start_date,
    end_date,
    selected_cities: list[str],
) -> pd.DataFrame:
    """Read hourly batch observations for the selected period and cities."""
    return query(
        """
        SELECT
            l.city,
            l.latitude,
            l.longitude,
            t.valid_at,
            f.pm2_5,
            f.pm10,
            f.european_aqi
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_location AS l
          ON l.location_key = f.location_key
        JOIN warehouse.dim_time AS t
          ON t.time_key = f.time_key
        WHERE t.full_date >= %s
          AND t.full_date <= %s
          AND t.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
          AND l.city = ANY(%s::varchar[])
        ORDER BY t.valid_at, l.city
        """,
        (start_date, end_date, selected_cities),
    )


def _format_measure(value, suffix: str = "") -> str:
    if pd.isna(value):
        return "—"
    return f"{float(value):.1f}{suffix}"


def render_analytics() -> None:
    """Render historical analytics sourced from warehouse.fact_air_quality."""
    if st.button("Muat ulang analitik", key="analytics_reload"):
        st.rerun()

    try:
        bounds = read_analytics_bounds()
        cities = read_analytics_cities()
    except (psycopg2.Error, OSError) as exc:
        st.error("Data warehouse belum dapat dibaca. Periksa PostgreSQL dan pipeline Airflow.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if bounds.empty or pd.isna(bounds.iloc[0]["min_date"]) or not cities:
        st.info(
            "Belum ada data batch di warehouse. Historical backfill yang berada di "
            "`staging.air_quality_raw` perlu diproses melalui DAG "
            "`air_quality_end_to_end` agar masuk ke `warehouse.fact_air_quality`."
        )
        return

    min_date = pd.Timestamp(bounds.iloc[0]["min_date"]).date()
    max_date = pd.Timestamp(bounds.iloc[0]["max_date"]).date()

    st.subheader("Filter periode dan kota")
    filter_left, filter_right = st.columns([2, 3])
    with filter_left:
        selected_period = st.date_input(
            "Rentang tanggal analisis",
            value=(min_date, max_date),
            min_value=min_date,
            max_value=max_date,
            format="DD/MM/YYYY",
            key="analytics_period",
        )
    with filter_right:
        selected_cities = st.multiselect(
            "Pilih kota",
            options=cities,
            default=cities,
            key="analytics_cities",
        )

    if isinstance(selected_period, (tuple, list)):
        if len(selected_period) == 0:
            st.info("Pilih rentang tanggal untuk melanjutkan.")
            return
        start_date = selected_period[0]
        end_date = selected_period[-1]
    else:
        start_date = selected_period
        end_date = selected_period

    if not selected_cities:
        st.info("Pilih minimal satu kota untuk menampilkan analitik.")
        return

    try:
        data = read_analytics_history(start_date, end_date, selected_cities)
    except (psycopg2.Error, OSError) as exc:
        st.error("Data historis gagal dimuat dari warehouse.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if data.empty:
        st.warning("Tidak ada data pada periode dan kota yang dipilih.")
        return

    data["valid_at"] = pd.to_datetime(data["valid_at"])
    for column in ["pm2_5", "pm10", "european_aqi"]:
        data[column] = pd.to_numeric(data[column], errors="coerce")

    city_summary = (
        data.groupby("city", as_index=False)
        .agg(
            avg_pm2_5=("pm2_5", "mean"),
            avg_pm10=("pm10", "mean"),
            avg_european_aqi=("european_aqi", "mean"),
            max_pm2_5=("pm2_5", "max"),
            readings=("pm2_5", "count"),
            latitude=("latitude", "first"),
            longitude=("longitude", "first"),
        )
        .sort_values("avg_pm2_5", ascending=False, na_position="last")
    )

    st.caption(
        f"Periode: **{start_date:%d %B %Y} – {end_date:%d %B %Y}** · "
        f"{len(selected_cities)} kota dipilih · "
        f"{len(data):,} baris observasi dari Data Warehouse"
    )

    # KPI ringkas untuk periode terpilih.
    overall_avg = data["pm2_5"].mean()
    highest_cities = city_summary.dropna(subset=["avg_pm2_5"])
    peak_rows = data.dropna(subset=["pm2_5"])

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Rata-rata PM2.5", _format_measure(overall_avg, " µg/m³"))
    if not highest_cities.empty:
        highest = highest_cities.iloc[0]
        k2.metric("Rata-rata tertinggi", str(highest["city"]))
        k2.caption(f"{float(highest['avg_pm2_5']):.1f} µg/m³")
    else:
        k2.metric("Rata-rata tertinggi", "—")
    if not peak_rows.empty:
        peak = peak_rows.loc[peak_rows["pm2_5"].idxmax()]
        k3.metric("Puncak PM2.5", _format_measure(peak["pm2_5"], " µg/m³"))
        k3.caption(f"{peak['city']} · {peak['valid_at']:%d/%m/%Y %H:%M}")
    else:
        k3.metric("Puncak PM2.5", "—")
    k4.metric("Jumlah observasi", f"{len(data):,}")

    # Peta lokasi kota. Ukuran marker mengikuti rerata PM2.5 relatif pada periode.
    st.divider()
    st.subheader("Peta persebaran kualitas udara")
    st.caption(
        "Marker menunjukkan lokasi kota. Ukurannya merepresentasikan rerata PM2.5 "
        "pada periode terpilih; peta ini bukan pemantauan sensor secara real-time."
    )
    map_points = city_summary.dropna(subset=["latitude", "longitude"]).copy()
    if map_points.empty:
        st.info("Koordinat lokasi belum tersedia di dimensi lokasi.")
    else:
        values = map_points["avg_pm2_5"].fillna(0).clip(lower=0)
        if values.max() == values.min():
            map_points["marker_size"] = 60
        else:
            map_points["marker_size"] = 35 + (
                (values - values.min()) / (values.max() - values.min())
            ) * 85
        st.map(
            map_points,
            latitude="latitude",
            longitude="longitude",
            color="#E4572E",
            size="marker_size",
            zoom=5,
        )

    st.subheader("Ringkasan per kota")
    city_columns = st.columns(max(1, len(city_summary)))
    for column, (_, row) in zip(city_columns, city_summary.iterrows()):
        with column:
            st.metric(
                str(row["city"]),
                _format_measure(row["avg_pm2_5"], " µg/m³"),
                help="Rata-rata PM2.5 selama periode yang dipilih.",
            )
            st.caption(
                f"PM10: {_format_measure(row['avg_pm10'])} µg/m³ · "
                f"{int(row['readings']):,} jam"
            )

    st.divider()
    st.subheader("Perbandingan rata-rata polutan antarkota")
    comparison = (
        city_summary.set_index("city")[["avg_pm2_5", "avg_pm10"]]
        .rename(columns={"avg_pm2_5": "PM2.5", "avg_pm10": "PM10"})
    )
    st.bar_chart(comparison, x_label="Kota", y_label="Konsentrasi (µg/m³)")

    st.subheader("Tren historis PM2.5 harian")
    daily = (
        data.assign(tanggal=data["valid_at"].dt.floor("D"))
        .pivot_table(
            index="tanggal",
            columns="city",
            values="pm2_5",
            aggfunc="mean",
        )
        .sort_index()
    )
    if daily.empty:
        st.info("Belum ada nilai PM2.5 untuk membentuk tren harian.")
    else:
        st.line_chart(daily, x_label="Tanggal", y_label="Rata-rata PM2.5 (µg/m³)")

    st.subheader("Tren mingguan PM2.5")
    weekly_source = data.dropna(subset=["valid_at", "pm2_5"]).copy()
    weekly_source["minggu_mulai"] = (
        weekly_source["valid_at"].dt.normalize()
        - pd.to_timedelta(weekly_source["valid_at"].dt.weekday, unit="D")
    )
    weekly = (
        weekly_source.pivot_table(
            index="minggu_mulai",
            columns="city",
            values="pm2_5",
            aggfunc="mean",
        )
        .sort_index()
    )
    if weekly.empty:
        st.info("Belum ada data PM2.5 untuk membentuk tren mingguan.")
    else:
        st.line_chart(
            weekly,
            x_label="Minggu dimulai (Senin)",
            y_label="Rata-rata PM2.5 (µg/m³)",
        )
        st.caption(
            "Setiap titik menunjukkan rata-rata seluruh observasi PM2.5 per jam "
            "dalam satu minggu (Senin–Minggu). Minggu pertama atau terakhir "
            "dapat berupa minggu parsial jika filter tanggal memotong minggu tersebut."
        )

    st.subheader("Pola PM2.5 berdasarkan jam")

    hourly = (
        data.dropna(subset=["valid_at", "pm2_5"])
        .assign(jam=lambda df: df["valid_at"].dt.hour)
        .groupby("jam", as_index=False)
        .agg(avg_pm25=("pm2_5", "mean"))
        .sort_values("jam")
    )

    if hourly.empty:
        st.info("Belum ada data PM2.5 untuk membentuk pola per jam.")
    else:
        st.bar_chart(
            hourly,
            x="jam",
            y="avg_pm25",
            x_label="Jam dalam sehari (WIB)",
            y_label="Rata-rata PM2.5 (µg/m³)",
        )

    st.subheader("Tren bulanan PM2.5")
    monthly = (
        data.assign(bulan=data["valid_at"].dt.strftime("%Y-%m"))
        .pivot_table(
            index="bulan",
            columns="city",
            values="pm2_5",
            aggfunc="mean",
        )
        .sort_index()
    )
    if not monthly.empty:
        st.line_chart(monthly, x_label="Bulan", y_label="Rata-rata PM2.5 (µg/m³)")

    st.subheader("10 pengamatan PM2.5 tertinggi")
    top_rows = (
        data.dropna(subset=["pm2_5"])
        .nlargest(10, "pm2_5")[
            ["city", "valid_at", "pm2_5", "pm10", "european_aqi"]
        ]
        .rename(
            columns={
                "city": "Kota",
                "valid_at": "Waktu (WIB)",
                "pm2_5": "PM2.5 (µg/m³)",
                "pm10": "PM10 (µg/m³)",
                "european_aqi": "European AQI",
            }
        )
    )
    st.dataframe(top_rows, width="stretch", hide_index=True)

    st.caption(
        "Sumber: Open-Meteo Air Quality API / CAMS Global melalui jalur batch. "
        "Nilai merupakan estimasi/model atmosfer, bukan pengukuran langsung "
        "dari stasiun sensor lapangan. Nilai kosong tidak dianggap nol."
    )




# ---------------------------------------------------------------- machine learning

def read_forecast_evaluation(city: str) -> pd.DataFrame:
    """Return paired, matured forecasts where RF, persistence, CAMS and reference align."""
    return query(
        """
        WITH latest_ml AS (
            SELECT DISTINCT ON (city, forecast_at, horizon_hours)
                city,
                forecast_at,
                horizon_hours,
                random_forest_value,
                persistence_value,
                forecast_origin
            FROM ml.air_quality_forecast
            WHERE parameter_name = 'pm2_5'
              AND random_forest_value IS NOT NULL
              AND persistence_value IS NOT NULL
            ORDER BY city, forecast_at, horizon_hours, forecast_origin DESC
        ),
        latest_cams AS (
            SELECT DISTINCT ON (city, forecast_at, horizon_hours)
                city,
                forecast_at,
                horizon_hours,
                pm2_5 AS cams_value,
                forecast_origin
            FROM ml.cams_air_quality_forecast
            ORDER BY city, forecast_at, horizon_hours,
                     forecast_origin DESC, retrieved_at DESC
        )
        SELECT
            m.city,
            m.forecast_at,
            m.horizon_hours,
            m.random_forest_value,
            m.persistence_value,
            c.cams_value,
            a.pm2_5 AS reference_value
        FROM latest_ml AS m
        INNER JOIN latest_cams AS c
            ON c.city = m.city
           AND c.forecast_at = m.forecast_at
           AND c.horizon_hours = m.horizon_hours
        INNER JOIN staging.air_quality_raw AS a
            ON a.city = m.city
           AND a.valid_at = m.forecast_at
        WHERE m.city = %s
          AND a.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
          AND a.pm2_5 IS NOT NULL
          AND m.random_forest_value IS NOT NULL
          AND m.persistence_value IS NOT NULL
          AND c.cams_value IS NOT NULL
        ORDER BY m.forecast_at DESC
        """,
        (city,),
    )


def _forecast_error_summary(frame: pd.DataFrame, prediction_column: str) -> tuple[int, float, float]:
    """Calculate MAE/RMSE against the later batch reference values."""
    valid = frame[[prediction_column, "reference_value"]].dropna()
    if valid.empty:
        return 0, float("nan"), float("nan")

    errors = (
        pd.to_numeric(valid[prediction_column], errors="coerce")
        - pd.to_numeric(valid["reference_value"], errors="coerce")
    ).dropna()
    if errors.empty:
        return 0, float("nan"), float("nan")

    mae = float(errors.abs().mean())
    rmse = float((errors.pow(2).mean()) ** 0.5)
    return len(errors), mae, rmse


def render_ml_forecast() -> None:
    """Compare the PM2.5 Random Forest forecast with CAMS Global."""
    if st.button("Muat ulang prediksi", key="ml_reload"):
        st.rerun()

    try:
        city_frame = query(
            """
            SELECT DISTINCT city
            FROM ml.air_quality_forecast
            WHERE parameter_name = 'pm2_5'
              AND random_forest_value IS NOT NULL
            ORDER BY city
            """
        )
    except (psycopg2.Error, OSError) as exc:
        st.info(
            "Struktur ML PM2.5 belum tersedia. Terapkan pembaruan Phase 4, "
            "kemudian jalankan DAG `air_quality_end_to_end`."
        )
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if city_frame.empty:
        st.info(
            "Belum ada forecast PM2.5. Jalankan DAG `air_quality_end_to_end` "
            "dan pastikan task `ml_forecast_6h` berhasil."
        )
        return

    city = st.selectbox("Pilih kota", city_frame["city"].tolist(), key="ml_city")

    try:
        origin_frame = query(
            """
            SELECT MAX(forecast_origin) AS forecast_origin
            FROM ml.air_quality_forecast
            WHERE city = %s AND parameter_name = 'pm2_5'
            """,
            (city,),
        )
        if origin_frame.empty or pd.isna(origin_frame.iloc[0]["forecast_origin"]):
            st.info("Belum ada origin forecast PM2.5 untuk kota ini.")
            return

        origin = pd.Timestamp(origin_frame.iloc[0]["forecast_origin"])

        forecast = query(
            """
            SELECT
                forecast_origin,
                forecast_at,
                horizon_hours,
                predicted_value,
                selected_model,
                holdout_mae,
                holdout_rmse,
                random_forest_value,
                persistence_value,
                seasonal_naive_value
            FROM ml.air_quality_forecast
            WHERE city = %s
              AND parameter_name = 'pm2_5'
              AND forecast_origin = %s
            ORDER BY forecast_at
            """,
            (city, origin.to_pydatetime()),
        )

        holdout_metrics = query(
            """
            SELECT parameter_name, horizon_hours, model_name, mae, rmse,
                   train_rows, test_rows, is_selected
            FROM ml.model_metrics
            WHERE city = %s
              AND parameter_name = 'pm2_5'
              AND evaluated_at = (
                  SELECT MAX(evaluated_at)
                  FROM ml.model_metrics
                  WHERE city = %s AND parameter_name = 'pm2_5'
              )
            ORDER BY horizon_hours, is_selected DESC, mae
            """,
            (city, city),
        )

        history = query(
            """
            SELECT valid_at, pm2_5
            FROM staging.air_quality_raw
            WHERE city = %s
              AND valid_at <= %s
              AND pm2_5 IS NOT NULL
            ORDER BY valid_at DESC
            LIMIT 24
            """,
            (city, origin.to_pydatetime()),
        )

    except (psycopg2.Error, OSError) as exc:
        st.error("Data prediksi ML belum dapat dibaca dari PostgreSQL.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    cams_error = None
    try:
        cams = query(
            """
            SELECT forecast_origin, forecast_at, horizon_hours,
                   pm2_5, domain, retrieved_at
            FROM ml.cams_air_quality_forecast
            WHERE city = %s
              AND forecast_origin = %s
            ORDER BY forecast_at
            """,
            (city, origin.to_pydatetime()),
        )
        evaluation = read_forecast_evaluation(city)
    except (psycopg2.Error, OSError) as exc:
        cams = pd.DataFrame(
            columns=[
                "forecast_origin", "forecast_at", "horizon_hours",
                "pm2_5", "domain", "retrieved_at",
            ]
        )
        evaluation = pd.DataFrame()
        cams_error = str(exc)

    if forecast.empty:
        st.info("Belum ada forecast ML untuk kota yang dipilih.")
        return

    forecast["forecast_origin"] = pd.to_datetime(forecast["forecast_origin"])
    forecast["forecast_at"] = pd.to_datetime(forecast["forecast_at"])
    forecast["horizon_hours"] = pd.to_numeric(forecast["horizon_hours"], errors="coerce")
    for column in [
        "predicted_value",
        "random_forest_value",
        "persistence_value",
        "seasonal_naive_value",
        "holdout_mae",
        "holdout_rmse",
    ]:
        forecast[column] = pd.to_numeric(forecast[column], errors="coerce")

    if not cams.empty:
        cams["forecast_origin"] = pd.to_datetime(cams["forecast_origin"])
        cams["forecast_at"] = pd.to_datetime(cams["forecast_at"])
        cams["horizon_hours"] = pd.to_numeric(cams["horizon_hours"], errors="coerce")
        cams["pm2_5"] = pd.to_numeric(cams["pm2_5"], errors="coerce")

    if not history.empty:
        history["valid_at"] = pd.to_datetime(history["valid_at"])
        history["pm2_5"] = pd.to_numeric(history["pm2_5"], errors="coerce")

    st.caption(
        f"Kota: **{city}** · Origin observasi: "
        f"**{origin:%d/%m/%Y %H:%M} WIB** · Horizon model: +1 sampai +6 jam"
    )

    if cams_error:
        st.info(
            "Tabel forecast CAMS belum tersedia atau task CAMS belum pernah sukses. "
            "Forecast Random Forest tetap dapat ditampilkan. Jalankan task "
            "`cams_forecast_pm25` melalui DAG."
        )
        with st.expander("Detail teknis CAMS"):
            st.code(cams_error)

    next_ml = forecast.sort_values("horizon_hours").iloc[0]
    next_cams = cams.sort_values("horizon_hours").iloc[0] if not cams.empty else None

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Prediksi Random Forest · +1 jam", f"{next_ml['random_forest_value']:.1f} µg/m³")
    k1.caption("Model ML PM2.5")
    if next_cams is not None:
        k2.metric(
            f"CAMS Global · +{int(next_cams['horizon_hours'])} jam",
            f"{next_cams['pm2_5']:.1f} µg/m³",
        )
        k2.caption("Titik forecast terdekat yang tersedia")
    else:
        k2.metric("Forecast CAMS Global", "Belum tersedia")
    k3.metric("Titik forecast CAMS", f"{len(cams):,}")
    k3.caption("Timestamp API dalam horizon enam jam")
    k4.metric("Titik evaluasi matang", f"{len(evaluation):,}")
    k4.caption("Target yang sudah memiliki referensi historis")

    st.subheader("PM2.5: historis dan forecast enam jam ke depan")
    chart_series = []

    if not history.empty:
        history_series = (
            history.sort_values("valid_at")
            .set_index("valid_at")["pm2_5"]
            .rename("Referensi historis")
        )
        chart_series.append(history_series)

    rf_series = (
        forecast.set_index("forecast_at")["random_forest_value"]
        .dropna()
        .rename("Random Forest")
    )
    persistence_series = (
        forecast.set_index("forecast_at")["persistence_value"]
        .dropna()
        .rename("Persistence")
    )
    chart_series.extend([rf_series, persistence_series])

    if not cams.empty:
        cams_series = (
            cams.set_index("forecast_at")["pm2_5"]
            .dropna()
            .rename("Open-Meteo / CAMS Global")
        )
        chart_series.append(cams_series)

    chart_data = pd.concat(chart_series, axis=1).sort_index()
    if chart_data.empty:
        st.info("Belum ada titik data yang dapat digambarkan.")
    else:
        st.line_chart(
            chart_data,
            x_label="Waktu (WIB)",
            y_label="Konsentrasi PM2.5 (µg/m³)",
        )

    st.caption(
        "CAMS Global memiliki resolusi waktu sumber tiga jam. Grafik memakai "
        "timestamp yang dikembalikan API apa adanya; sistem tidak membuat "
        "interpolasi atau nilai forecast buatan untuk mengisi jam yang tidak tersedia."
    )

    st.subheader("Tabel perbandingan forecast")
    forecast_table = forecast[
        [
            "forecast_at",
            "horizon_hours",
            "random_forest_value",
            "persistence_value",
            "predicted_value",
            "selected_model",
        ]
    ].copy()

    if not cams.empty:
        forecast_table = forecast_table.merge(
            cams[["forecast_at", "horizon_hours", "pm2_5"]].rename(
                columns={"pm2_5": "cams_pm2_5"}
            ),
            on=["forecast_at", "horizon_hours"],
            how="left",
        )
    else:
        forecast_table["cams_pm2_5"] = float("nan")

    forecast_table = forecast_table.rename(
        columns={
            "forecast_at": "Waktu target (WIB)",
            "horizon_hours": "Horizon (jam)",
            "random_forest_value": "Random Forest (µg/m³)",
            "persistence_value": "Persistence (µg/m³)",
            "predicted_value": "Model terpilih (µg/m³)",
            "selected_model": "Kandidat terpilih",
            "cams_pm2_5": "CAMS Global (µg/m³)",
        }
    )
    st.dataframe(forecast_table, width="stretch", hide_index=True)

    st.divider()
    st.subheader("Evaluasi aktual: Random Forest vs Persistence vs CAMS")

    if evaluation.empty:
        st.info(
            "Belum ada pasangan forecast yang dapat dinilai. Metrik akan muncul "
            "setelah timestamp target forecast terlewati dan data referensi batch "
            "untuk timestamp yang sama tersedia di staging."
        )
    else:
        count_rf, mae_rf, rmse_rf = _forecast_error_summary(
            evaluation, "random_forest_value"
        )
        count_persistence, mae_persistence, rmse_persistence = _forecast_error_summary(
            evaluation, "persistence_value"
        )
        count_cams, mae_cams, rmse_cams = _forecast_error_summary(
            evaluation, "cams_value"
        )

        e1, e2, e3, e4 = st.columns(4)
        e1.metric("Forecast sudah dinilai", f"{len(evaluation):,}")
        e2.metric("MAE Random Forest", f"{mae_rf:.2f} µg/m³" if pd.notna(mae_rf) else "—")
        e3.metric("MAE Persistence", f"{mae_persistence:.2f} µg/m³" if pd.notna(mae_persistence) else "—")
        e4.metric("MAE CAMS", f"{mae_cams:.2f} µg/m³" if pd.notna(mae_cams) else "—")

        evaluation_summary = pd.DataFrame(
            [
                {
                    "Metode": "Random Forest",
                    "Jumlah target": count_rf,
                    "MAE (µg/m³)": mae_rf,
                    "RMSE (µg/m³)": rmse_rf,
                },
                {
                    "Metode": "Persistence",
                    "Jumlah target": count_persistence,
                    "MAE (µg/m³)": mae_persistence,
                    "RMSE (µg/m³)": rmse_persistence,
                },
                {
                    "Metode": "Open-Meteo / CAMS Global",
                    "Jumlah target": count_cams,
                    "MAE (µg/m³)": mae_cams,
                    "RMSE (µg/m³)": rmse_cams,
                },
            ]
        )
        st.dataframe(evaluation_summary, width="stretch", hide_index=True)

        st.caption(
            "Evaluasi rolling hanya memakai target waktu yang sama dan memiliki "
            "prediksi dari ketiga metode serta nilai referensi batch. Nilai referensi "
            "berasal dari Open-Meteo/CAMS yang masuk kemudian, bukan sensor lapangan."
        )

        with st.expander("Detail titik evaluasi"):
            detail = evaluation.sort_values("forecast_at", ascending=False).rename(
                columns={
                    "forecast_at": "Waktu target (WIB)",
                    "horizon_hours": "Horizon (jam)",
                    "random_forest_value": "Random Forest",
                    "persistence_value": "Persistence",
                    "cams_value": "CAMS Global",
                    "reference_value": "Referensi batch",
                }
            )
            st.dataframe(detail, width="stretch", hide_index=True)

    with st.expander("Evaluasi holdout model ML"):
        if holdout_metrics.empty:
            st.info("Metrik holdout belum tersedia.")
        else:
            metrics_view = holdout_metrics.rename(
                columns={
                    "horizon_hours": "Horizon (jam)",
                    "model_name": "Kandidat",
                    "mae": "MAE (µg/m³)",
                    "rmse": "RMSE (µg/m³)",
                    "train_rows": "Baris training",
                    "test_rows": "Baris pengujian",
                    "is_selected": "Terpilih berdasarkan MAE",
                }
            )
            st.caption(
                "Holdout kronologis membandingkan Random Forest, Persistence, dan "
                "Seasonal Naive 24 jam. Kandidat terpilih ditentukan berdasarkan MAE "
                "pada data pengujian historis."
            )
            st.dataframe(metrics_view, width="stretch", hide_index=True)

    st.caption(
        "Seluruh prediksi menggunakan PM2.5 saja. Forecast merupakan keluaran model "
        "atmosfer, bukan pengukuran langsung sensor. Perbandingan terhadap referensi "
        "batch tidak dapat menggantikan validasi menggunakan stasiun pemantauan independen."
    )



st.set_page_config(page_title="Kualitas Udara | Praktikum", layout="wide")
st.title("Kualitas Udara Lima Kota")
st.caption("Praktikum Big Data · waktu Asia/Jakarta")

tab_live, tab_batch, tab_analytics, tab_ml = st.tabs(
    ["Live (streaming)", "Per jam (batch)", "Analitik", "Prediksi (ML)"]
)
with tab_live:
    st.caption("Jalur streaming: sensor simulasi → Spark Structured Streaming → warehouse. Diperbarui otomatis tiap 5 detik.")
    render_live()
with tab_batch:
    st.caption("Jalur batch: Open-Meteo → Airflow → Spark → warehouse. Diperbarui tiap run DAG (tiap 3 jam).")
    render_batch()
with tab_analytics:
    st.caption("Analitik historis: data batch Open-Meteo dari Data Warehouse, dengan filter tanggal dan kota.")
    render_analytics()
with tab_ml:
    st.caption("Jalur prediksi: Random Forest PM2.5 dibandingkan dengan Persistence dan Open-Meteo/CAMS Global.")
    render_ml_forecast()
