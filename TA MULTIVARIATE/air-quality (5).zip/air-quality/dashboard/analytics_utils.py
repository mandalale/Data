"""Pure helper functions for the air-quality exploratory analytics dashboard."""

from __future__ import annotations

import math
import pandas as pd

VARIABLE_CONFIG = {
    "European AQI": {"column": "european_aqi", "unit": "Index", "short": "AQI"},
    "PM2.5": {"column": "pm2_5", "unit": "µg/m³", "short": "PM2.5"},
    "PM10": {"column": "pm10", "unit": "µg/m³", "short": "PM10"},
    "CO": {"column": "carbon_monoxide", "unit": "µg/m³", "short": "CO"},
    "NO₂": {"column": "nitrogen_dioxide", "unit": "µg/m³", "short": "NO₂"},
    "SO₂": {"column": "sulphur_dioxide", "unit": "µg/m³", "short": "SO₂"},
    "O₃": {"column": "ozone", "unit": "µg/m³", "short": "O₃"},
}

POLLUTANT_CONFIG = {
    key: value for key, value in VARIABLE_CONFIG.items() if key != "European AQI"
}

METEOROLOGY_CONFIG = {
    "Temperature": {"column": "temperature_2m", "unit": "°C", "short": "Temperature"},
    "Relative Humidity": {"column": "relative_humidity_2m", "unit": "%", "short": "RH"},
    "Wind Speed": {"column": "wind_speed_10m", "unit": "km/h", "short": "Wind"},
    "Precipitation": {"column": "precipitation", "unit": "mm", "short": "Rain"},
    "Boundary Layer Height": {"column": "boundary_layer_height", "unit": "m", "short": "BLH"},
    "Shortwave Radiation": {"column": "shortwave_radiation", "unit": "W/m²", "short": "Radiation"},
}

AQI_CATEGORIES = ["Good", "Fair", "Moderate", "Poor", "Very Poor", "Extremely Poor"]

AQI_COLORS = {
    "Good": "#16A34A",
    "Fair": "#84CC16",
    "Moderate": "#EAB308",
    "Poor": "#F97316",
    "Very Poor": "#DC2626",
    "Extremely Poor": "#7F1D1D",
}


def classify_european_aqi(value) -> str:
    """Classify the European AQI index into the six EEA communication bands."""
    if pd.isna(value):
        return "Data tidak tersedia"
    value = float(value)
    if value < 0:
        return "Data tidak valid"
    if value <= 20:
        return "Good"
    if value <= 40:
        return "Fair"
    if value <= 60:
        return "Moderate"
    if value <= 80:
        return "Poor"
    if value <= 100:
        return "Very Poor"
    return "Extremely Poor"


def resolve_period_window(
    mode: str,
    latest_at,
    month_key: str | None = None,
    custom_range=None,
) -> tuple[pd.Timestamp, pd.Timestamp, int]:
    """Return [start, end) and expected hourly slots, anchored to available data."""
    latest = pd.Timestamp(latest_at)
    available_end = latest + pd.Timedelta(hours=1)

    if mode == "7 Hari":
        end = available_end
        start = end - pd.Timedelta(hours=168)
    elif mode == "3 Hari":
        end = available_end
        start = end - pd.Timedelta(hours=72)
    elif mode == "24 Jam":
        end = available_end
        start = end - pd.Timedelta(hours=24)
    elif mode == "Bulanan":
        if not month_key:
            raise ValueError("Pilih bulan kalender untuk analisis bulanan.")
        start = pd.Timestamp(f"{month_key}-01")
        requested_end = start + pd.offsets.MonthBegin(1)
        end = min(pd.Timestamp(requested_end), available_end)
    elif mode == "Custom":
        if not custom_range or len(custom_range) == 0:
            raise ValueError("Pilih tanggal awal dan akhir untuk periode custom.")
        start_date = pd.Timestamp(custom_range[0]).normalize()
        end_date = pd.Timestamp(custom_range[-1]).normalize()
        if end_date < start_date:
            raise ValueError("Tanggal akhir tidak boleh lebih awal dari tanggal mulai.")
        start = start_date
        requested_end = end_date + pd.Timedelta(days=1)
        end = min(requested_end, available_end)
    else:
        raise ValueError(f"Mode periode tidak dikenal: {mode}")

    if end <= start:
        raise ValueError("Rentang periode tidak memiliki waktu observasi yang valid.")

    expected_hours = max(1, int(math.ceil((end - start).total_seconds() / 3600)))
    return pd.Timestamp(start), pd.Timestamp(end), expected_hours


def summarize_by_city(
    data: pd.DataFrame,
    city_metadata: pd.DataFrame,
    variable: str,
    expected_hours: int,
) -> pd.DataFrame:
    """Return city summary while preserving cities with no observations."""
    column = VARIABLE_CONFIG[variable]["column"]
    metadata_columns = [c for c in ["city", "latitude", "longitude"] if c in city_metadata.columns]
    result = city_metadata[metadata_columns].drop_duplicates("city").copy()

    if data.empty:
        result["mean"] = float("nan")
        result["median"] = float("nan")
        result["min"] = float("nan")
        result["max"] = float("nan")
        result["std"] = float("nan")
        result["valid_count"] = 0
    else:
        grouped = data.groupby("city")[column].agg(
            mean="mean", median="median", min="min", max="max", std="std", valid_count="count"
        ).reset_index()
        result = result.merge(grouped, on="city", how="left")
        result["valid_count"] = result["valid_count"].fillna(0).astype(int)

    result["expected_count"] = int(expected_hours)
    result["coverage_pct"] = (
        result["valid_count"] / result["expected_count"].replace(0, pd.NA) * 100
        if isinstance(result["expected_count"], pd.Series) else 0
    )
    result["coverage_pct"] = pd.to_numeric(result["coverage_pct"], errors="coerce").clip(upper=100).fillna(0)
    return result


def build_temporal_series(data: pd.DataFrame, variable: str, granularity: str) -> pd.DataFrame:
    """Aggregate a variable by city and hourly/daily/weekly time bucket."""
    column = VARIABLE_CONFIG[variable]["column"]
    source = data.dropna(subset=["valid_at", column]).copy()
    if source.empty:
        return pd.DataFrame()
    timestamps = pd.to_datetime(source["valid_at"])
    if granularity == "hour":
        source["time_bucket"] = timestamps.dt.floor("h")
    elif granularity == "week":
        source["time_bucket"] = timestamps.dt.to_period("W-SUN").dt.start_time
    else:
        source["time_bucket"] = timestamps.dt.floor("D")
    grouped = source.groupby(["time_bucket", "city"], as_index=False)[column].mean()
    return grouped.pivot(index="time_bucket", columns="city", values=column).sort_index()


def build_hourly_heatmap(data: pd.DataFrame, variable: str) -> pd.DataFrame:
    """Return city x clock-hour mean values for a heatmap."""
    column = VARIABLE_CONFIG[variable]["column"]
    source = data.dropna(subset=["valid_at", column]).copy()
    if source.empty:
        return pd.DataFrame(columns=["city", "hour", "mean"])
    source["hour"] = pd.to_datetime(source["valid_at"]).dt.hour
    return (
        source.groupby(["city", "hour"], as_index=False)[column]
        .mean()
        .rename(columns={column: "mean"})
    )


def correlation_analysis(
    data: pd.DataFrame,
    columns: list[str],
    method: str = "pearson",
    min_periods: int = 3,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Return correlation matrix, ranked pairs, and pairwise sample-count matrix."""
    if method not in {"pearson", "spearman"}:
        raise ValueError("Metode korelasi harus pearson atau spearman.")
    available = [column for column in columns if column in data.columns]
    numeric = data[available].apply(pd.to_numeric, errors="coerce")
    matrix = numeric.corr(method=method, min_periods=min_periods)
    counts = pd.DataFrame(index=available, columns=available, dtype="int64")
    pairs = []
    for i, left in enumerate(available):
        counts.loc[left, left] = int(numeric[left].notna().sum())
        for right in available[i + 1:]:
            n_pairs = int(numeric[[left, right]].dropna().shape[0])
            counts.loc[left, right] = n_pairs
            counts.loc[right, left] = n_pairs
            value = matrix.loc[left, right]
            if pd.notna(value):
                pairs.append({
                    "variable_a": left,
                    "variable_b": right,
                    "correlation": float(value),
                    "n_pairs": n_pairs,
                })
    for column in available:
        counts.loc[column, column] = int(numeric[column].notna().sum())
    ranked = pd.DataFrame(pairs, columns=["variable_a", "variable_b", "correlation", "n_pairs"])
    if not ranked.empty:
        ranked["abs_correlation"] = ranked["correlation"].abs()
        ranked = ranked.sort_values("abs_correlation", ascending=False).drop(columns="abs_correlation").reset_index(drop=True)
    return matrix, ranked, counts.fillna(0).astype(int)


def strongest_correlation(
    data: pd.DataFrame,
    method: str = "pearson",
) -> tuple[pd.DataFrame, tuple[str, str, float] | None]:
    """Backward-compatible correlation helper for the currently configured variables."""
    columns = [config["column"] for config in VARIABLE_CONFIG.values()]
    matrix, ranked, _ = correlation_analysis(data, columns, method)
    if ranked.empty:
        return matrix, None
    first = ranked.iloc[0]
    return matrix, (first["variable_a"], first["variable_b"], float(first["correlation"]))


def calculate_lagged_correlations(
    data: pd.DataFrame,
    pollutant_column: str,
    meteorology_columns: list[str],
    lags: tuple[int, ...] = (0, 1, 3, 6, 12),
    min_periods: int = 3,
) -> pd.DataFrame:
    """Correlate meteorology at t with pollutant at t + lag using exact city/timestamp joins.

    Missing hours are not treated as adjacent observations: pairs are created only
    when the exact target timestamp exists for the same city.
    """
    required = ["city", "valid_at", pollutant_column, *meteorology_columns]
    available = [column for column in required if column in data.columns]
    if not {"city", "valid_at", pollutant_column}.issubset(available):
        return pd.DataFrame(columns=["meteorology", "lag_hours", "correlation", "n_pairs"])

    source = data[available].copy()
    source["valid_at"] = pd.to_datetime(source["valid_at"])
    targets = (
        source[["city", "valid_at", pollutant_column]]
        .rename(columns={"valid_at": "target_at"})
        .dropna(subset=[pollutant_column])
    )
    weather_columns = [column for column in meteorology_columns if column in source.columns]
    weather = source[["city", "valid_at", *weather_columns]].rename(columns={"valid_at": "weather_at"})

    results = []
    for lag in lags:
        shifted_weather = weather.copy()
        shifted_weather["target_at"] = shifted_weather["weather_at"] + pd.Timedelta(hours=int(lag))
        paired = shifted_weather.merge(targets, on=["city", "target_at"], how="inner")
        for column in weather_columns:
            valid = paired[[column, pollutant_column]].apply(pd.to_numeric, errors="coerce").dropna()
            coefficient = (
                float(valid[column].corr(valid[pollutant_column], method="pearson"))
                if len(valid) >= min_periods and valid[column].nunique() > 1 and valid[pollutant_column].nunique() > 1
                else float("nan")
            )
            results.append({
                "meteorology": column,
                "lag_hours": int(lag),
                "correlation": coefficient,
                "n_pairs": int(len(valid)),
            })
    return pd.DataFrame(results, columns=["meteorology", "lag_hours", "correlation", "n_pairs"])


def expected_observation_coverage(valid_count: int, expected_count: int) -> float:
    if expected_count <= 0:
        return 0.0
    return min(100.0, max(0.0, float(valid_count) / float(expected_count) * 100.0))
