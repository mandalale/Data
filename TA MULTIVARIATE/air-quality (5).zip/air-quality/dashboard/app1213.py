"""Dashboard kelas: seluruh angka berasal dari fact dan dimension warehouse.

Dua tab, satu per jalur:
- Live (streaming): data sensor simulasi, diperbarui otomatis tiap 5 detik.
- Per jam (batch): data Open-Meteo yang dimuat DAG Airflow.
"""

import os
from contextlib import closing

import pandas as pd
import psycopg2
import streamlit as st


def query(sql: str, params: tuple | None = None) -> pd.DataFrame:
    """Run a read query against PostgreSQL, optionally with bound parameters."""
    with closing(psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=5,
    )) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
            columns = [column[0] for column in cur.description]
    return pd.DataFrame(rows, columns=columns)


def read_fact() -> pd.DataFrame:
    return query("""
        SELECT l.city, t.valid_at, f.pm2_5, f.pm10, f.european_aqi
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_location AS l ON l.location_key = f.location_key
        JOIN warehouse.dim_time AS t ON t.time_key = f.time_key
        ORDER BY t.valid_at DESC, l.city
    """)


# ---------------------------------------------------------------- jalur streaming

RULE_LABELS = {
    "normalized_city": "Nama kota dibakukan",
    "fixed_format": "Koma diganti titik",
    "nulled_unparseable": "Teks bukan angka → NULL",
    "nulled_negative": "Nilai negatif → NULL",
    "nulled_outlier": "Nilai tidak wajar → NULL",
    "rejected_city": "Ditolak: kota tak dikenal",
    "rejected_time": "Ditolak: waktu tidak wajar",
    "rejected_empty": "Ditolak: semua nilai kosong",
    "duplicates": "Dibuang: duplikat",
}


@st.fragment(run_every="5s")
def render_live() -> None:
    try:
        summary = query("""
            SELECT
                COALESCE(SUM(rows_in), 0) AS rows_in,
                COALESCE(SUM(rows_loaded), 0) AS rows_loaded,
                COALESCE(SUM(normalized_city), 0) AS normalized_city,
                COALESCE(SUM(fixed_format), 0) AS fixed_format,
                COALESCE(SUM(nulled_unparseable), 0) AS nulled_unparseable,
                COALESCE(SUM(nulled_negative), 0) AS nulled_negative,
                COALESCE(SUM(nulled_outlier), 0) AS nulled_outlier,
                COALESCE(SUM(rejected_city), 0) AS rejected_city,
                COALESCE(SUM(rejected_time), 0) AS rejected_time,
                COALESCE(SUM(rejected_empty), 0) AS rejected_empty,
                COALESCE(SUM(duplicates), 0) AS duplicates
            FROM staging.stream_quality_log
            WHERE processed_at >= NOW() - INTERVAL '5 minutes'
        """).iloc[0]
        lag = query("""
            SELECT EXTRACT(EPOCH FROM (NOW() AT TIME ZONE 'Asia/Jakarta') - MAX(reading_at)) AS seconds
            FROM warehouse.fact_sensor_live
        """).iloc[0]["seconds"]
        live = query("""
            SELECT f.reading_at, l.city, f.pm2_5
            FROM warehouse.fact_sensor_live f
            JOIN warehouse.dim_location l USING (location_key)
            WHERE f.reading_at >= (NOW() AT TIME ZONE 'Asia/Jakarta') - INTERVAL '10 minutes'
            ORDER BY f.reading_at
        """)
        raw = query("""
            SELECT received_at AT TIME ZONE 'Asia/Jakarta' AS diterima, dirty_type AS jenis,
                   city AS kota, reading_at AS jam, pm2_5, pm10, ozone
            FROM staging.sensor_raw
            ORDER BY raw_id DESC
            LIMIT 15
        """)
    except (psycopg2.Error, OSError) as exc:
        st.warning("Jalur streaming belum siap. Pastikan service sensor-simulator dan spark-streaming menyala.")
        st.code(str(exc))
        return

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Pesan masuk (5 menit)", f"{int(summary['rows_in']):,}")
    k2.metric("Masuk ke warehouse", f"{int(summary['rows_loaded']):,}")
    k3.metric("Ditolak / duplikat", f"{int(summary['rows_in'] - summary['rows_loaded']):,}")
    k4.metric("Jeda data terakhir", f"{lag:.0f} detik" if pd.notna(lag) else "—")

    left, right = st.columns([3, 2])
    with left:
        st.subheader("PM2.5 live, 10 menit terakhir")
        if live.empty:
            st.info("Belum ada data live. Tunggu beberapa detik setelah simulator menyala.")
        else:
            live["reading_at"] = pd.to_datetime(live["reading_at"])
            trend = live.pivot_table(index="reading_at", columns="city", values="pm2_5", aggfunc="mean")
            st.line_chart(trend, x_label="Waktu (WIB)", y_label="PM2.5 (µg/m³)")
    with right:
        st.subheader("Yang dibersihkan Spark (5 menit)")
        rules = pd.DataFrame(
            {"Jumlah": [int(summary[key]) for key in RULE_LABELS]},
            index=list(RULE_LABELS.values()),
        )
        st.bar_chart(rules, horizontal=True, x_label="Jumlah", y_label="")

    st.subheader("15 pesan mentah terbaru dari sensor")
    st.caption("Baris merah = pesan yang sengaja dibuat kotor oleh simulator. Kolom 'jenis' hanya ada untuk keperluan pembelajaran; sensor sungguhan tidak memberikan label seperti ini.")
    styled = raw.style.apply(
        lambda row: ["background-color: rgba(220, 60, 50, 0.15)" if row["jenis"] != "bersih" else "" for _ in row],
        axis=1,
    )
    st.dataframe(styled, width="stretch", hide_index=True)


# ---------------------------------------------------------------- jalur batch

def render_batch() -> None:
    if st.button("Muat ulang data"):
        st.rerun()

    try:
        data = read_fact()
    except (psycopg2.Error, OSError) as exc:
        st.error("Database belum siap. Periksa status PostgreSQL dan jalankan pipeline Airflow.")
        st.code(str(exc))
        return

    if data.empty:
        st.info("Belum ada baris di fact table. Jalankan DAG air_quality_end_to_end di Airflow, tunggu empat task berhasil, lalu klik Muat ulang data.")
        return

    data["valid_at"] = pd.to_datetime(data["valid_at"])
    cities = sorted(data["city"].unique().tolist())
    selected = st.multiselect("Pilih kota", cities, default=cities)
    if not selected:
        st.info("Pilih sedikitnya satu kota untuk menampilkan grafik.")
        return

    view = data.loc[data["city"].isin(selected)].copy()
    recent = view.loc[view["valid_at"] >= view["valid_at"].max() - pd.Timedelta(days=7)]

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Kota terpilih", len(selected))
    k2.metric("Baris fakta", f"{len(view):,}")
    k3.metric("PM2.5 rerata (µg/m³)", f"{view['pm2_5'].mean():.1f}" if view["pm2_5"].notna().any() else "—")
    k4.metric("Jam data terakhir (WIB)", view["valid_at"].max().strftime("%d/%m/%Y %H:%M"))

    st.subheader("PM2.5 per jam dalam tujuh hari terakhir")
    trend = recent.pivot_table(index="valid_at", columns="city", values="pm2_5", aggfunc="mean")
    if trend.empty:
        st.info("Tidak ada nilai PM2.5 pada rentang ini.")
    else:
        st.line_chart(trend, x_label="Waktu (WIB)", y_label="PM2.5 (µg/m³)")

    st.subheader("Rerata polutan per kota dalam tujuh hari terakhir")
    means = recent.groupby("city", as_index=True)[["pm2_5", "pm10"]].mean()
    st.bar_chart(means, x_label="Kota", y_label="Konsentrasi (µg/m³)")

    st.subheader("50 catatan terbaru")
    st.dataframe(view.head(50), width="stretch", hide_index=True)
    st.caption("Ini data model kualitas udara dari Open-Meteo/CAMS, bukan pembacaan sensor lapangan. Nilai kosong tetap kosong; jangan ditafsirkan sebagai nol. Indeks AQI Eropa hanya ditampilkan jika tersedia.")




# ---------------------------------------------------------------- machine learning

ML_PARAMETER_LABELS = {
    "pm2_5": "PM2.5 (µg/m³)",
    "pm10": "PM10 (µg/m³)",
    "carbon_monoxide": "Karbon monoksida / CO (µg/m³)",
    "nitrogen_dioxide": "Nitrogen dioksida / NO₂ (µg/m³)",
    "sulphur_dioxide": "Sulfur dioksida / SO₂ (µg/m³)",
    "ozone": "Ozon / O₃ (µg/m³)",
    "european_aqi": "European AQI (indeks)",
}


def european_aqi_category(value: float) -> str:
    """Translate the European AQI bands into concise Indonesian labels."""
    if pd.isna(value):
        return "Belum tersedia"
    if value <= 20:
        return "Baik"
    if value <= 40:
        return "Cukup"
    if value <= 60:
        return "Sedang"
    if value <= 80:
        return "Buruk"
    if value <= 100:
        return "Sangat buruk"
    return "Ekstrem"


def render_aqi_recommendation(aqi_rows: pd.DataFrame) -> None:
    st.subheader("Rekomendasi berdasarkan forecast")
    st.caption(
        "Kategori menggunakan European AQI. Rekomendasi ini merupakan panduan "
        "edukatif berbasis hasil model, bukan peringatan resmi atau pengganti "
        "informasi dari otoritas kualitas udara."
    )

    if aqi_rows.empty or aqi_rows["predicted_value"].isna().all():
        st.info("Forecast European AQI belum tersedia untuk kota ini.")
        return

    aqi_rows = aqi_rows.sort_values("horizon_hours")
    first = float(aqi_rows.iloc[0]["predicted_value"])
    peak_row = aqi_rows.loc[aqi_rows["predicted_value"].idxmax()]
    peak = float(peak_row["predicted_value"])
    peak_time = pd.to_datetime(peak_row["forecast_at"])
    category = european_aqi_category(peak)

    st.markdown(f"**Perkiraan kondisi terburuk dalam enam jam: {category}**")
    st.write(
        f"Nilai European AQI diprediksi mencapai **{peak:.1f}** pada "
        f"**{peak_time:%d/%m/%Y %H:%M} WIB**."
    )

    if peak <= 20:
        st.success(
            "Kualitas udara diperkirakan baik. Aktivitas luar ruang umumnya "
            "dapat dilakukan seperti biasa; tetap pantau perubahan prediksi."
        )
    elif peak <= 40:
        st.success(
            "Kualitas udara diperkirakan cukup. Kebanyakan orang dapat "
            "beraktivitas seperti biasa; kelompok sensitif sebaiknya tetap "
            "memperhatikan kondisi dan gejala yang dirasakan."
        )
    elif peak <= 60:
        st.info(
            "Kualitas udara diperkirakan sedang. Kelompok sensitif dapat "
            "mempertimbangkan mengurangi aktivitas fisik berat di luar ruang."
        )
    elif peak <= 80:
        st.warning(
            "Kualitas udara diperkirakan buruk. Pertimbangkan mengurangi "
            "aktivitas fisik luar ruang yang lama atau berat, terutama bagi "
            "kelompok sensitif."
        )
    elif peak <= 100:
        st.warning(
            "Kualitas udara diperkirakan sangat buruk. Kurangi aktivitas fisik "
            "di luar ruang dan pertimbangkan memindahkan aktivitas ke dalam "
            "ruangan."
        )
    else:
        st.error(
            "Kualitas udara diperkirakan ekstrem. Minimalkan paparan di luar "
            "ruang dan ikuti informasi dari otoritas kualitas udara setempat."
        )

    delta = float(aqi_rows.iloc[-1]["predicted_value"]) - first
    if delta >= 10:
        st.warning(
            f"Tren model menunjukkan kenaikan sekitar {delta:.1f} poin AQI "
            "dari jam pertama ke jam keenam. Pertimbangkan memantau pembaruan "
            "forecast berikutnya."
        )
    elif delta <= -10:
        st.info(
            f"Tren model menunjukkan penurunan sekitar {abs(delta):.1f} poin "
            "AQI dari jam pertama ke jam keenam."
        )


def render_ml_forecast() -> None:
    """Show stored forecasts, model evaluation, and data-driven guidance."""
    if st.button("Muat ulang forecast", key="ml_reload"):
        st.rerun()

    try:
        city_frame = query(
            """
            SELECT DISTINCT city
            FROM ml.air_quality_forecast
            ORDER BY city
            """
        )
    except (psycopg2.Error, OSError) as exc:
        st.info(
            "Tabel Machine Learning belum tersedia. Setelah kode ML dipasang, "
            "build ulang image Airflow dan jalankan DAG "
            "`air_quality_end_to_end`."
        )
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if city_frame.empty:
        st.info(
            "Belum ada forecast yang tersimpan. Jalankan DAG "
            "`air_quality_end_to_end` dan pastikan task `ml_forecast_6h` "
            "berhasil, lalu klik **Muat ulang forecast**."
        )
        return

    cities = city_frame["city"].tolist()
    city = st.selectbox("Pilih kota", cities, key="ml_city")

    try:
        forecast = query(
            """
            SELECT forecast_origin, forecast_at, horizon_hours, parameter_name,
                   predicted_value, selected_model, holdout_mae, holdout_rmse
            FROM ml.air_quality_forecast
            WHERE city = %s
              AND forecast_origin = (
                  SELECT MAX(forecast_origin)
                  FROM ml.air_quality_forecast
                  WHERE city = %s
              )
            ORDER BY forecast_at, parameter_name
            """,
            (city, city),
        )
        metrics = query(
            """
            SELECT parameter_name, horizon_hours, model_name, mae, rmse,
                   train_rows, test_rows, is_selected
            FROM ml.model_metrics
            WHERE city = %s
              AND evaluated_at = (
                  SELECT MAX(evaluated_at)
                  FROM ml.model_metrics
                  WHERE city = %s
              )
            ORDER BY parameter_name, horizon_hours, is_selected DESC, mae
            """,
            (city, city),
        )
    except (psycopg2.Error, OSError) as exc:
        st.error("Data forecast atau metrik model belum dapat dibaca dari PostgreSQL.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if forecast.empty:
        st.info("Belum ada hasil forecast untuk kota yang dipilih.")
        return

    forecast["forecast_origin"] = pd.to_datetime(forecast["forecast_origin"])
    forecast["forecast_at"] = pd.to_datetime(forecast["forecast_at"])
    forecast["horizon_hours"] = pd.to_numeric(forecast["horizon_hours"], errors="coerce")
    forecast["predicted_value"] = pd.to_numeric(forecast["predicted_value"], errors="coerce")

    origin = forecast["forecast_origin"].max()
    st.caption(
        f"Asal forecast: **{origin:%d/%m/%Y %H:%M} WIB** · "
        "hasil disimpan oleh task ML pada pipeline Airflow."
    )

    aqi_rows = forecast.loc[forecast["parameter_name"] == "european_aqi"].copy()
    pm25_rows = forecast.loc[forecast["parameter_name"] == "pm2_5"].copy()
    next_aqi = aqi_rows.loc[aqi_rows["horizon_hours"] == 1]
    next_pm25 = pm25_rows.loc[pm25_rows["horizon_hours"] == 1]

    k1, k2, k3, k4 = st.columns(4)
    if not next_aqi.empty:
        aqi_value = float(next_aqi.iloc[0]["predicted_value"])
        k1.metric("European AQI · +1 jam", f"{aqi_value:.1f}")
        k1.caption(f"Kategori: {european_aqi_category(aqi_value)}")
    else:
        k1.metric("European AQI · +1 jam", "—")

    if not aqi_rows.empty:
        peak_row = aqi_rows.loc[aqi_rows["predicted_value"].idxmax()]
        peak_value = float(peak_row["predicted_value"])
        k2.metric("Puncak AQI · 6 jam", f"{peak_value:.1f}")
        k2.caption(
            f"{european_aqi_category(peak_value)} · "
            f"{pd.to_datetime(peak_row['forecast_at']):%H:%M WIB}"
        )
    else:
        k2.metric("Puncak AQI · 6 jam", "—")

    if not next_pm25.empty:
        k3.metric("PM2.5 · +1 jam", f"{float(next_pm25.iloc[0]['predicted_value']):.1f} µg/m³")
    else:
        k3.metric("PM2.5 · +1 jam", "—")

    if not next_aqi.empty:
        k4.metric("Model AQI · +1 jam", str(next_aqi.iloc[0]["selected_model"]).replace("_", " ").title())
    else:
        k4.metric("Model AQI · +1 jam", "—")

    render_aqi_recommendation(aqi_rows)

    st.subheader("Grafik forecast enam jam ke depan")
    parameter = st.selectbox(
        "Pilih parameter",
        list(ML_PARAMETER_LABELS.keys()),
        format_func=lambda value: ML_PARAMETER_LABELS[value],
        key="ml_parameter",
    )

    forecast_parameter = (
        forecast.loc[forecast["parameter_name"] == parameter, ["forecast_at", "predicted_value"]]
        .dropna()
        .sort_values("forecast_at")
        .set_index("forecast_at")["predicted_value"]
        .rename("Forecast")
    )

    chart_series = [forecast_parameter]
    try:
        # Raw timestamps are intentionally treated as Asia/Jakarta wall-clock
        # labels by this project; no UTC conversion is applied here.
        history = query(
            f"""
            SELECT valid_at, {parameter} AS actual
            FROM staging.air_quality_raw
            WHERE city = %s
              AND valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
            ORDER BY valid_at DESC
            LIMIT 24
            """,
            (city,),
        )
        if not history.empty:
            history["valid_at"] = pd.to_datetime(history["valid_at"])
            actual_series = (
                history.sort_values("valid_at")
                .set_index("valid_at")["actual"]
                .rename("Aktual")
            )
            chart_series.insert(0, actual_series)
    except (psycopg2.Error, OSError):
        # The stored forecast remains useful even if the optional history query
        # is unavailable.
        pass

    chart_data = pd.concat(chart_series, axis=1).sort_index()
    if chart_data.empty:
        st.info("Belum ada titik data untuk grafik parameter ini.")
    else:
        st.line_chart(
            chart_data,
            x_label="Waktu (WIB)",
            y_label=ML_PARAMETER_LABELS[parameter],
        )

    st.subheader("Tabel forecast")
    wide = forecast.pivot_table(
        index=["forecast_at", "horizon_hours"],
        columns="parameter_name",
        values="predicted_value",
        aggfunc="first",
    ).reset_index()
    wide = wide.rename(
        columns={
            "forecast_at": "Waktu prediksi (WIB)",
            "horizon_hours": "Horizon (jam)",
            **ML_PARAMETER_LABELS,
        }
    )
    st.dataframe(wide, width="stretch", hide_index=True)

    with st.expander("Evaluasi dan perbandingan model"):
        if metrics.empty:
            st.info("Metrik evaluasi belum tersedia untuk kota ini.")
        else:
            metrics_view = metrics.loc[metrics["parameter_name"] == parameter].copy()
            metrics_view = metrics_view.rename(
                columns={
                    "parameter_name": "Parameter",
                    "horizon_hours": "Horizon (jam)",
                    "model_name": "Model",
                    "mae": "MAE",
                    "rmse": "RMSE",
                    "train_rows": "Baris training",
                    "test_rows": "Baris pengujian",
                    "is_selected": "Model terpilih",
                }
            )
            st.caption(
                "Model dipilih per kota, parameter, dan horizon berdasarkan MAE "
                "pada holdout kronologis. MAE/RMSE memiliki satuan parameter "
                "yang sedang dipilih."
            )
            st.dataframe(metrics_view, width="stretch", hide_index=True)

    st.caption(
        "Model kandidat: Persistence, Seasonal Naive 24 jam, dan Random Forest. "
        "Forecast adalah estimasi, bukan pengukuran sensor aktual. Akurasi masa "
        "depan dapat berubah ketika data baru masuk."
    )


st.set_page_config(page_title="Kualitas Udara | Praktikum", layout="wide")
st.title("Kualitas Udara Lima Kota")
st.caption("Praktikum Big Data · waktu Asia/Jakarta")

tab_live, tab_batch, tab_ml = st.tabs(
    ["Live (streaming)", "Per jam (batch)", "Forecast & Rekomendasi"]
)
with tab_live:
    st.caption("Jalur streaming: sensor simulasi → Spark Structured Streaming → warehouse. Diperbarui otomatis tiap 5 detik.")
    render_live()
with tab_batch:
    st.caption("Jalur batch: Open-Meteo → Airflow → Spark → warehouse. Diperbarui tiap run DAG (tiap 3 jam).")
    render_batch()
with tab_ml:
    st.caption("Jalur ML: data historis → evaluasi model → forecast 6 jam → rekomendasi berbasis European AQI.")
    render_ml_forecast()
