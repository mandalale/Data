"""Dashboard kualitas udara lima kota.

Lima tab:
- Live (streaming): data sensor simulasi, diperbarui otomatis tiap 5 detik.
- Per jam (batch): data Open-Meteo yang dimuat DAG Airflow.
- Analitik: eksplorasi data historis batch dari Data Warehouse.
- Prediksi (ML): forecast PM2.5 Random Forest dibandingkan dengan CAMS Global.
- Pengaturan: kontrol runtime independen untuk streaming, batch, dan ML.
"""

import os
from contextlib import closing

import pandas as pd
import psycopg2
import pydeck as pdk
import streamlit as st

from analytics_utils import (
    AQI_CATEGORIES,
    METEOROLOGY_CONFIG,
    POLLUTANT_CONFIG,
    VARIABLE_CONFIG,
    build_hourly_heatmap,
    build_temporal_series,
    calculate_lagged_correlations,
    classify_european_aqi,
    correlation_analysis,
    resolve_period_window,
)


def query(sql: str, params: tuple | None = None) -> pd.DataFrame:
    """Run a read query against PostgreSQL, optionally with bound parameters."""
    with closing(psycopg2.connect(
        host=os.getenv("DW_HOST", "postgres"),
        port=os.getenv("DW_PORT", "5432"),
        dbname=os.getenv("DW_DB", "air_quality_dw"),
        user=os.getenv("DW_USER", "platform"),
        password=os.getenv("DW_PASSWORD", "platform123"),
        connect_timeout=5,
    )) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
            columns = [column[0] for column in cur.description]
    return pd.DataFrame(rows, columns=columns)


PIPELINE_SETTING_COLUMNS = {
    "streaming": "streaming_enabled",
    "batch": "batch_enabled",
    "ml": "ml_enabled",
}


def read_pipeline_settings() -> dict:
    """Read the persisted switches used by all pipeline containers."""
    frame = query("""
        SELECT streaming_enabled, batch_enabled, ml_enabled, updated_at, updated_by
        FROM control.pipeline_settings
        WHERE id = 1
    """)
    if frame.empty:
        raise RuntimeError("control.pipeline_settings tidak memiliki baris konfigurasi.")
    return frame.iloc[0].to_dict()


def update_pipeline_setting(setting: str) -> None:
    """Persist a toggle change; only allow known setting column names."""
    if setting not in PIPELINE_SETTING_COLUMNS:
        raise ValueError(f"Pengaturan pipeline tidak dikenal: {setting}")
    column = PIPELINE_SETTING_COLUMNS[setting]
    widget_key = f"pipeline_toggle_{setting}"
    enabled = bool(st.session_state[widget_key])

    try:
        with closing(psycopg2.connect(
            host=os.getenv("DW_HOST", "postgres"),
            port=os.getenv("DW_PORT", "5432"),
            dbname=os.getenv("DW_DB", "air_quality_dw"),
            user=os.getenv("DW_USER", "platform"),
            password=os.getenv("DW_PASSWORD", "platform123"),
            connect_timeout=5,
        )) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    UPDATE control.pipeline_settings
                    SET {column} = %s,
                        updated_at = NOW(),
                        updated_by = 'streamlit_dashboard'
                    WHERE id = 1
                    """,
                    (enabled,),
                )
                if cur.rowcount != 1:
                    raise RuntimeError("Baris konfigurasi pipeline tidak ditemukan.")
            conn.commit()
        st.session_state["pipeline_settings_notice"] = (
            f"Jalur {setting.upper()} berhasil diubah menjadi "
            f"{'ON' if enabled else 'OFF'}."
        )
        st.session_state.pop("pipeline_settings_error", None)
    except Exception as exc:  # noqa: BLE001
        st.session_state["pipeline_settings_error"] = (
            f"Gagal menyimpan pengaturan {setting.upper()}: {exc}"
        )


def latest_pipeline_timestamp(sql: str) -> str:
    """Return a display-safe latest timestamp; missing/not-yet-created tables are OK."""
    try:
        frame = query(sql)
        if frame.empty or pd.isna(frame.iloc[0, 0]):
            return "Belum tersedia"
        return pd.Timestamp(frame.iloc[0, 0]).strftime("%d/%m/%Y %H:%M:%S")
    except Exception:
        return "Belum tersedia"


def format_control_timestamp(value) -> str:
    if value is None or pd.isna(value):
        return "Belum tersedia"
    return pd.Timestamp(value).strftime("%d/%m/%Y %H:%M:%S")


def read_fact() -> pd.DataFrame:
    return query("""
        SELECT l.city, t.valid_at, f.pm2_5, f.pm10, f.european_aqi
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_location AS l ON l.location_key = f.location_key
        JOIN warehouse.dim_time AS t ON t.time_key = f.time_key
        ORDER BY t.valid_at DESC, l.city
    """)


# ---------------------------------------------------------------- jalur streaming

RULE_LABELS = {
    "normalized_city": "Nama kota dibakukan",
    "fixed_format": "Koma diganti titik",
    "nulled_unparseable": "Teks bukan angka → NULL",
    "nulled_negative": "Nilai negatif → NULL",
    "nulled_outlier": "Nilai tidak wajar → NULL",
    "rejected_city": "Ditolak: kota tak dikenal",
    "rejected_time": "Ditolak: waktu tidak wajar",
    "rejected_empty": "Ditolak: semua nilai kosong",
    "duplicates": "Dibuang: duplikat",
}


@st.fragment(run_every="5s")
def render_live() -> None:
    try:
        summary = query("""
            SELECT
                COALESCE(SUM(rows_in), 0) AS rows_in,
                COALESCE(SUM(rows_loaded), 0) AS rows_loaded,
                COALESCE(SUM(normalized_city), 0) AS normalized_city,
                COALESCE(SUM(fixed_format), 0) AS fixed_format,
                COALESCE(SUM(nulled_unparseable), 0) AS nulled_unparseable,
                COALESCE(SUM(nulled_negative), 0) AS nulled_negative,
                COALESCE(SUM(nulled_outlier), 0) AS nulled_outlier,
                COALESCE(SUM(rejected_city), 0) AS rejected_city,
                COALESCE(SUM(rejected_time), 0) AS rejected_time,
                COALESCE(SUM(rejected_empty), 0) AS rejected_empty,
                COALESCE(SUM(duplicates), 0) AS duplicates
            FROM staging.stream_quality_log
            WHERE processed_at >= NOW() - INTERVAL '5 minutes'
        """).iloc[0]
        lag = query("""
            SELECT EXTRACT(EPOCH FROM (NOW() AT TIME ZONE 'Asia/Jakarta') - MAX(reading_at)) AS seconds
            FROM warehouse.fact_sensor_live
        """).iloc[0]["seconds"]
        live = query("""
            SELECT f.reading_at, l.city, f.pm2_5
            FROM warehouse.fact_sensor_live f
            JOIN warehouse.dim_location l USING (location_key)
            WHERE f.reading_at >= (NOW() AT TIME ZONE 'Asia/Jakarta') - INTERVAL '10 minutes'
            ORDER BY f.reading_at
        """)
        raw = query("""
            SELECT received_at AT TIME ZONE 'Asia/Jakarta' AS diterima, dirty_type AS jenis,
                   city AS kota, reading_at AS jam, pm2_5, pm10, ozone
            FROM staging.sensor_raw
            ORDER BY raw_id DESC
            LIMIT 15
        """)
    except (psycopg2.Error, OSError) as exc:
        st.warning("Jalur streaming belum siap. Pastikan service sensor-simulator dan spark-streaming menyala.")
        st.code(str(exc))
        return

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Pesan masuk (5 menit)", f"{int(summary['rows_in']):,}")
    k2.metric("Masuk ke warehouse", f"{int(summary['rows_loaded']):,}")
    k3.metric("Ditolak / duplikat", f"{int(summary['rows_in'] - summary['rows_loaded']):,}")
    k4.metric("Jeda data terakhir", f"{lag:.0f} detik" if pd.notna(lag) else "—")

    left, right = st.columns([3, 2])
    with left:
        st.subheader("PM2.5 live, 10 menit terakhir")
        if live.empty:
            st.info("Belum ada data live. Tunggu beberapa detik setelah simulator menyala.")
        else:
            live["reading_at"] = pd.to_datetime(live["reading_at"])
            trend = live.pivot_table(index="reading_at", columns="city", values="pm2_5", aggfunc="mean")
            st.line_chart(trend, x_label="Waktu (WIB)", y_label="PM2.5 (µg/m³)")
    with right:
        st.subheader("Yang dibersihkan Spark (5 menit)")
        rules = pd.DataFrame(
            {"Jumlah": [int(summary[key]) for key in RULE_LABELS]},
            index=list(RULE_LABELS.values()),
        )
        st.bar_chart(rules, horizontal=True, x_label="Jumlah", y_label="")

    st.subheader("15 pesan mentah terbaru dari sensor")
    st.caption("Baris merah = pesan yang sengaja dibuat kotor oleh simulator. Kolom 'jenis' hanya ada untuk keperluan pembelajaran; sensor sungguhan tidak memberikan label seperti ini.")
    styled = raw.style.apply(
        lambda row: ["background-color: rgba(220, 60, 50, 0.15)" if row["jenis"] != "bersih" else "" for _ in row],
        axis=1,
    )
    st.dataframe(styled, width="stretch", hide_index=True)


# ---------------------------------------------------------------- jalur batch

def render_batch() -> None:
    if st.button("Muat ulang data"):
        st.rerun()

    try:
        data = read_fact()
    except (psycopg2.Error, OSError) as exc:
        st.error("Database belum siap. Periksa status PostgreSQL dan jalankan pipeline Airflow.")
        st.code(str(exc))
        return

    if data.empty:
        st.info("Belum ada baris di fact table. Jalankan DAG air_quality_end_to_end di Airflow, tunggu empat task berhasil, lalu klik Muat ulang data.")
        return

    data["valid_at"] = pd.to_datetime(data["valid_at"])
    cities = sorted(data["city"].unique().tolist())
    selected = st.multiselect("Pilih kota", cities, default=cities)
    if not selected:
        st.info("Pilih sedikitnya satu kota untuk menampilkan grafik.")
        return

    view = data.loc[data["city"].isin(selected)].copy()
    recent = view.loc[view["valid_at"] >= view["valid_at"].max() - pd.Timedelta(days=7)]

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Kota terpilih", len(selected))
    k2.metric("Baris fakta", f"{len(view):,}")
    k3.metric("PM2.5 rerata (µg/m³)", f"{view['pm2_5'].mean():.1f}" if view["pm2_5"].notna().any() else "—")
    k4.metric("Jam data terakhir (WIB)", view["valid_at"].max().strftime("%d/%m/%Y %H:%M"))

    st.subheader("PM2.5 per jam dalam tujuh hari terakhir")
    trend = recent.pivot_table(index="valid_at", columns="city", values="pm2_5", aggfunc="mean")
    if trend.empty:
        st.info("Tidak ada nilai PM2.5 pada rentang ini.")
    else:
        st.line_chart(trend, x_label="Waktu (WIB)", y_label="PM2.5 (µg/m³)")

    st.subheader("Rerata polutan per kota dalam tujuh hari terakhir")
    means = recent.groupby("city", as_index=True)[["pm2_5", "pm10"]].mean()
    st.bar_chart(means, x_label="Kota", y_label="Konsentrasi (µg/m³)")

    st.subheader("50 catatan terbaru")
    st.dataframe(view.head(50), width="stretch", hide_index=True)
    st.caption("Ini data model kualitas udara dari Open-Meteo/CAMS, bukan pembacaan sensor lapangan. Nilai kosong tetap kosong; jangan ditafsirkan sebagai nol. Indeks AQI Eropa hanya ditampilkan jika tersedia.")



# ---------------------------------------------------------------- historical analytics


@st.cache_data(ttl=300, show_spinner=False)
def read_analytics_bounds() -> pd.DataFrame:
    """Return available historical bounds, excluding future timestamps."""
    return query("""
        SELECT
            MIN(t.valid_at) FILTER (
                WHERE t.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
            ) AS min_at,
            MAX(t.valid_at) FILTER (
                WHERE t.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
            ) AS max_at,
            COUNT(*) FILTER (
                WHERE t.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
            ) AS total_rows
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_time AS t ON t.time_key = f.time_key
    """)


@st.cache_data(ttl=300, show_spinner=False)
def read_analytics_cities() -> pd.DataFrame:
    """Return all configured cities and their coordinates."""
    return query("""
        SELECT city, latitude, longitude
        FROM warehouse.dim_location
        ORDER BY city
    """)


@st.cache_data(ttl=300, show_spinner=False)
def read_analytics_history(start_at, end_at) -> pd.DataFrame:
    """Read all city observations for a half-open timestamp interval [start, end)."""
    return query(
        """
        SELECT
            l.city,
            l.latitude,
            l.longitude,
            t.valid_at,
            f.pm2_5,
            f.pm10,
            f.carbon_monoxide,
            f.nitrogen_dioxide,
            f.sulphur_dioxide,
            f.ozone,
            f.european_aqi,
            met.temperature_2m,
            met.relative_humidity_2m,
            met.wind_speed_10m,
            met.precipitation,
            met.boundary_layer_height,
            met.shortwave_radiation
        FROM warehouse.fact_air_quality AS f
        JOIN warehouse.dim_location AS l
          ON l.location_key = f.location_key
        JOIN warehouse.dim_time AS t
          ON t.time_key = f.time_key
        LEFT JOIN warehouse.fact_meteorology AS met
          ON met.location_key = f.location_key
         AND met.time_key = f.time_key
        WHERE t.valid_at >= %s
          AND t.valid_at < %s
          AND t.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
        ORDER BY t.valid_at, l.city
        """,
        (start_at, end_at),
    )


def _format_measure(value, suffix: str = "", digits: int = 1) -> str:
    if value is None or pd.isna(value):
        return "—"
    return f"{float(value):,.{digits}f}{suffix}"


def _render_interpretation(title: str, body: str, caveat: str | None = None) -> None:
    """Render a data-driven interpretation immediately below its visualization."""
    with st.container(border=True):
        st.markdown(f"**Interpretasi data — {title}**")
        st.write(body)
        if caveat:
            st.caption(caveat)


def _format_period_label(mode: str, start_at: pd.Timestamp, end_at: pd.Timestamp) -> str:
    last_included = end_at - pd.Timedelta(hours=1)
    if mode == "Bulanan":
        return start_at.strftime("%B %Y")
    return f"{start_at:%d %b %Y %H:%M} – {last_included:%d %b %Y %H:%M} WIB"


def _select_trend_granularity(mode: str, start_at: pd.Timestamp, end_at: pd.Timestamp) -> str:
    duration_hours = (end_at - start_at).total_seconds() / 3600
    if mode in {"24 Jam", "3 Hari", "7 Hari"} or duration_hours <= 72:
        return "hour"
    if duration_hours <= 45 * 24:
        return "day"
    return "week"


def _trend_interpretation(trend: pd.DataFrame, variable: str) -> str:
    if trend.empty or trend.shape[0] < 2:
        return "Jumlah titik waktu valid belum cukup untuk mengidentifikasi perubahan dari awal ke akhir periode."
    config = VARIABLE_CONFIG[variable]
    candidates = []
    for city in trend.columns:
        series = trend[city].dropna()
        if len(series) < 2:
            continue
        first, last = float(series.iloc[0]), float(series.iloc[-1])
        delta = last - first
        candidates.append((city, first, last, delta))
    if not candidates:
        return "Tidak ada seri waktu dengan minimal dua titik observasi valid."
    city, first, last, delta = max(candidates, key=lambda item: abs(item[3]))
    direction = "meningkat" if delta > 0 else "menurun" if delta < 0 else "relatif tetap"
    percent_text = (
        f" atau sekitar {abs(delta / first) * 100:.1f}%"
        if first != 0 and delta != 0 else ""
    )
    return (
        f"Perubahan absolut terbesar dari titik waktu pertama ke terakhir terlihat di {city}: "
        f"{variable} {direction} dari {_format_measure(first, ' ' + config['unit'])} "
        f"menjadi {_format_measure(last, ' ' + config['unit'])} "
        f"(perubahan {_format_measure(abs(delta), ' ' + config['unit'])}{percent_text}). "
        "Perbandingan ini menggambarkan dua titik agregasi, bukan bukti tren kausal."
    )


def _boxplot_interpretation(data: pd.DataFrame, variable: str) -> str:
    column = VARIABLE_CONFIG[variable]["column"]
    rows = []
    total_outliers = 0
    for city, group in data.groupby("city"):
        values = pd.to_numeric(group[column], errors="coerce").dropna()
        if values.empty:
            continue
        q1, median, q3 = values.quantile([0.25, 0.5, 0.75])
        iqr = q3 - q1
        outliers = int(((values < q1 - 1.5 * iqr) | (values > q3 + 1.5 * iqr)).sum())
        total_outliers += outliers
        rows.append((city, float(median), outliers, len(values)))
    if not rows:
        return "Tidak ada nilai valid untuk menghitung distribusi."
    highest_median = max(rows, key=lambda item: item[1])
    return (
        f"Median tertinggi terdapat di {highest_median[0]} sebesar "
        f"{_format_measure(highest_median[1], ' ' + VARIABLE_CONFIG[variable]['unit'])}. "
        f"Dengan aturan 1,5 × IQR, teridentifikasi {total_outliers:,} titik outlier "
        "pada seluruh kota terpilih. Outlier statistik tidak otomatis berarti kesalahan data."
    )


def _heatmap_interpretation(heatmap: pd.DataFrame, variable: str) -> str:
    if heatmap.empty:
        return "Tidak ada observasi valid untuk membentuk pola jam."
    peak = heatmap.loc[heatmap["mean"].idxmax()]
    return (
        f"Rata-rata {variable} tertinggi pada agregasi kota-jam ditemukan di "
        f"{peak['city']} sekitar pukul {int(peak['hour']):02d}.00 WIB, "
        f"sebesar {_format_measure(peak['mean'], ' ' + VARIABLE_CONFIG[variable]['unit'])}. "
        "Pola waktu ini menunjukkan kapan nilai relatif tinggi teramati, bukan penyebabnya."
    )


def _correlation_strength(value: float) -> str:
    """Describe absolute correlation strength using a simple rule of thumb."""
    magnitude = abs(float(value))
    if magnitude < 0.20:
        return "sangat lemah"
    if magnitude < 0.40:
        return "lemah"
    if magnitude < 0.60:
        return "sedang"
    if magnitude < 0.80:
        return "kuat"
    return "sangat kuat"


def _correlation_sentence(left: str, right: str, value, n: int, method: str) -> str:
    if pd.isna(value):
        return f"Hubungan {left} dan {right} belum dapat dihitung karena variasi atau jumlah pasangan observasi tidak mencukupi."
    direction = "positif" if value > 0 else "negatif" if value < 0 else "mendekati nol"
    return (
        f"{left} dan {right} menunjukkan korelasi {direction} {_correlation_strength(value)} "
        f"({method.title()} r = {value:.3f}; n = {n:,} pasangan). "
        "Koefisien ini menggambarkan keterkaitan statistik, bukan hubungan sebab-akibat."
    )


def render_analytics() -> None:
    """Render the six-section, EDA-oriented air-quality analytics dashboard."""
    reload_col, info_col = st.columns([1, 5])
    with reload_col:
        if st.button("Muat ulang analitik", key="analytics_reload"):
            st.cache_data.clear()
            st.rerun()
    with info_col:
        st.caption(
            "Sumber: Data Warehouse · Open-Meteo Air Quality / CAMS Global dan Open-Meteo Meteorology · Waktu Asia/Jakarta"
        )

    try:
        bounds = read_analytics_bounds()
        city_metadata = read_analytics_cities()
    except (psycopg2.Error, OSError) as exc:
        st.error("Data warehouse belum dapat dibaca. Periksa PostgreSQL dan pipeline Airflow.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if bounds.empty or pd.isna(bounds.iloc[0]["min_at"]) or pd.isna(bounds.iloc[0]["max_at"]) or city_metadata.empty:
        st.info("Belum ada observasi batch yang tersedia di Data Warehouse.")
        return

    min_at = pd.Timestamp(bounds.iloc[0]["min_at"])
    max_at = pd.Timestamp(bounds.iloc[0]["max_at"])
    min_date, max_date = min_at.date(), max_at.date()
    cities = city_metadata["city"].tolist()
    months = pd.period_range(min_at.to_period("M"), max_at.to_period("M"), freq="M")
    month_options = [str(month) for month in months]
    latest_month = month_options[-1]

    st.session_state.setdefault("analytics_period_mode", "7 Hari")
    st.session_state.setdefault("analytics_month", latest_month)
    st.session_state.setdefault("analytics_custom_range", (min_date, max_date))
    st.session_state.setdefault("analytics_cities", cities)
    if st.session_state["analytics_month"] not in month_options:
        st.session_state["analytics_month"] = latest_month
    st.session_state["analytics_cities"] = [
        city for city in st.session_state["analytics_cities"] if city in cities
    ] or cities

    st.subheader("Filter Pengamatan")
    with st.form("analytics_filter_form", border=True):
        period_mode = st.radio(
            "Periode",
            ["Bulanan", "7 Hari", "3 Hari", "24 Jam", "Custom"],
            horizontal=True,
            key="analytics_period_mode",
        )
        filter_col1, filter_col2 = st.columns(2)
        with filter_col1:
            month_key = st.selectbox(
                "Bulan kalender",
                options=month_options,
                format_func=lambda value: pd.Period(value, freq="M").strftime("%B %Y"),
                key="analytics_month",
            )
        with filter_col2:
            custom_range = st.date_input(
                "Rentang tanggal custom",
                min_value=min_date,
                max_value=max_date,
                format="DD/MM/YYYY",
                key="analytics_custom_range",
            )
        selected_cities = st.multiselect(
            "Kota (semua kota dipilih secara default)",
            options=cities,
            key="analytics_cities",
        )
        submitted = st.form_submit_button("Terapkan Filter", type="primary", use_container_width=True)

    if submitted or "analytics_applied_filters" not in st.session_state:
        st.session_state["analytics_applied_filters"] = {
            "mode": period_mode,
            "month_key": month_key,
            "custom_range": custom_range,
            "cities": list(selected_cities),
        }
    applied = st.session_state["analytics_applied_filters"]
    mode = applied["mode"]
    selected_cities = applied["cities"]

    if not selected_cities:
        st.warning("Pilih minimal satu kota untuk menjalankan analisis.")
        return

    try:
        start_at, end_at, expected_hours = resolve_period_window(
            mode,
            max_at,
            month_key=applied["month_key"],
            custom_range=applied["custom_range"],
        )
    except ValueError as exc:
        st.warning(str(exc))
        return

    try:
        with st.spinner("Memuat data kualitas udara dan meteorologi..."):
            data_all = read_analytics_history(start_at.to_pydatetime(), end_at.to_pydatetime())
    except (psycopg2.Error, OSError) as exc:
        st.error("Data historis gagal dimuat dari warehouse.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if data_all.empty:
        st.warning("Tidak ada data pada periode yang dipilih.")
        return

    data_all["valid_at"] = pd.to_datetime(data_all["valid_at"])
    numeric_columns = (
        [config["column"] for config in VARIABLE_CONFIG.values()]
        + [config["column"] for config in METEOROLOGY_CONFIG.values()]
    )
    for column in numeric_columns:
        if column in data_all.columns:
            data_all[column] = pd.to_numeric(data_all[column], errors="coerce")

    detail_data = data_all.loc[data_all["city"].isin(selected_cities)].copy()
    if detail_data.empty:
        st.warning("Tidak ada observasi untuk kota yang dipilih pada periode ini.")
        return

    actual_last = pd.Timestamp(detail_data["valid_at"].max())
    period_label = _format_period_label(mode, start_at, end_at)
    met_coverage = (
        detail_data[[config["column"] for config in METEOROLOGY_CONFIG.values()]]
        .notna().any(axis=1).mean() * 100
    )
    st.caption(
        f"Periode aktif: **{period_label}** · {len(selected_cities)} dari {len(cities)} kota · "
        f"{len(detail_data):,} observasi kualitas udara · Data terakhir: {actual_last:%d/%m/%Y %H:%M} WIB · "
        f"Baris dengan minimal satu variabel meteorologi: {met_coverage:.1f}%"
    )

    overview_tab, city_tab, bivariate_tab, multivariate_tab, meteo_tab, conclusion_tab = st.tabs([
        "01 · Overview",
        "02 · City & Temporal",
        "03 · Bivariate",
        "04 · Multivariate",
        "05 · Meteorological",
        "06 · Conclusion",
    ])

    # ---------------------------------------------------------------- overview
    with overview_tab:
        st.subheader("Gambaran Keseluruhan Kualitas Udara")
        aqi = pd.to_numeric(detail_data["european_aqi"], errors="coerce").dropna()
        valid_aqi = aqi.loc[aqi >= 0]
        avg_aqi = float(valid_aqi.mean()) if not valid_aqi.empty else float("nan")
        max_aqi = float(valid_aqi.max()) if not valid_aqi.empty else float("nan")
        category_counts = (
            valid_aqi.map(classify_european_aqi).value_counts()
            .reindex(AQI_CATEGORIES, fill_value=0)
        )
        city_aqi = detail_data.groupby("city")["european_aqi"].mean().dropna().sort_values(ascending=False)

        k1, k2, k3, k4 = st.columns(4)
        k1.metric("Rata-rata European AQI", _format_measure(avg_aqi, " Index", 1))
        k2.metric("AQI maksimum", _format_measure(max_aqi, " Index", 1))
        k3.metric("Kota dianalisis", f"{len(selected_cities)}")
        k4.metric("Observasi AQI valid", f"{len(valid_aqi):,}")
        _render_interpretation(
            "Ringkasan KPI AQI",
            (
                f"Ringkasan mencakup {len(valid_aqi):,} observasi AQI valid dari {len(selected_cities)} kota. "
                f"Rata-rata periode adalah {_format_measure(avg_aqi, ' Index', 1)} dan nilai maksimum "
                f"{_format_measure(max_aqi, ' Index', 1)}."
                if not valid_aqi.empty else
                "Belum tersedia observasi AQI valid untuk menghitung rata-rata dan nilai maksimum."
            ),
            "Nilai rata-rata dan maksimum adalah ringkasan periode, bukan status kualitas udara saat ini.",
        )

        if not city_aqi.empty:
            st.markdown("**Rata-rata European AQI per kota**")
            st.bar_chart(city_aqi.rename("Rata-rata AQI"), y_label="Index")
            _render_interpretation(
                "Perbandingan rata-rata AQI",
                f"Rata-rata AQI tertinggi selama periode terpilih terdapat di {city_aqi.index[0]} "
                f"({_format_measure(city_aqi.iloc[0], ' Index', 1)}); terendah di {city_aqi.index[-1]} "
                f"({_format_measure(city_aqi.iloc[-1], ' Index', 1)}).",
                "Rata-rata periode merangkum observasi yang tersedia; perbedaan coverage antarkota dapat memengaruhi perbandingan.",
            )
        else:
            st.info("European AQI belum memiliki observasi valid pada periode ini.")

        st.markdown("**Distribusi kategori European AQI**")
        if int(category_counts.sum()) > 0:
            category_frame = category_counts.rename("Observasi").to_frame()
            category_frame["Persentase"] = category_frame["Observasi"] / category_frame["Observasi"].sum() * 100
            st.bar_chart(category_frame[["Observasi"]], y_label="Jumlah observasi")
            dominant = category_frame["Observasi"].idxmax()
            _render_interpretation(
                "Distribusi kategori AQI",
                f"Kategori yang paling sering muncul adalah {dominant}: {int(category_frame.loc[dominant, 'Observasi']):,} "
                f"observasi ({category_frame.loc[dominant, 'Persentase']:.1f}% dari observasi AQI valid).",
                "Kategori dihitung per observasi per jam, bukan dari kategori rata-rata kota.",
            )
        else:
            st.info("Distribusi kategori belum dapat dihitung.")

        st.markdown("**Rentang kategori European AQI**")
        aqi_category_ranges = pd.DataFrame(
            [
                {"Kategori": "Good", "Rentang indeks": "0–20"},
                {"Kategori": "Fair", "Rentang indeks": ">20–40"},
                {"Kategori": "Moderate", "Rentang indeks": ">40–60"},
                {"Kategori": "Poor", "Rentang indeks": ">60–80"},
                {"Kategori": "Very Poor", "Rentang indeks": ">80–100"},
                {"Kategori": "Extremely Poor", "Rentang indeks": ">100"},
            ]
        )
        st.table(aqi_category_ranges)
        st.caption(
            "Batas atas setiap rentang termasuk dalam kategori tersebut. "
            "Contoh: AQI 20 masuk Good, sedangkan AQI 20,1 masuk Fair. "
            "Klasifikasi mengikuti enam kategori European AQI yang digunakan project."
        )

        st.markdown("**Tren European AQI seluruh kota terpilih**")
        overview_trend = build_temporal_series(detail_data, "European AQI", _select_trend_granularity(mode, start_at, end_at))
        if not overview_trend.empty:
            st.line_chart(overview_trend, x_label="Waktu (WIB)", y_label="European AQI")
            _render_interpretation(
                "Tren keseluruhan AQI",
                _trend_interpretation(overview_trend, "European AQI"),
                "Setiap garis mewakili rata-rata kota pada interval waktu yang sama.",
            )
        else:
            st.info("Belum cukup data untuk menampilkan tren AQI.")

    # ---------------------------------------------------------------- city comparison and temporal
    with city_tab:
        st.subheader("Perbandingan Kota dan Pola Temporal")
        pollutant_label = st.selectbox(
            "Pilih polutan",
            list(POLLUTANT_CONFIG.keys()),
            key="city_pollutant",
        )
        pollutant = POLLUTANT_CONFIG[pollutant_label]
        pollutant_column = pollutant["column"]
        pollutant_data = detail_data.dropna(subset=[pollutant_column]).copy()
        city_means = (
            pollutant_data.groupby("city")[pollutant_column].mean()
            .sort_values(ascending=False)
        )

        st.markdown(f"**Rata-rata {pollutant_label} antarkota**")
        if not city_means.empty:
            st.bar_chart(city_means.rename(f"{pollutant_label} ({pollutant['unit']})"), y_label=pollutant["unit"])
            _render_interpretation(
                f"Perbandingan {pollutant_label}",
                f"Rata-rata tertinggi ditemukan di {city_means.index[0]} "
                f"({_format_measure(city_means.iloc[0], ' ' + pollutant['unit'])}) dan terendah di "
                f"{city_means.index[-1]} ({_format_measure(city_means.iloc[-1], ' ' + pollutant['unit'])}).",
                "Perbandingan bersifat deskriptif; konsentrasi polutan tidak dibandingkan lintas jenis karena satuan dan karakteristiknya berbeda.",
            )
        else:
            st.info(f"Tidak ada data valid untuk {pollutant_label}.")

        granularity = _select_trend_granularity(mode, start_at, end_at)
        trend = build_temporal_series(detail_data, pollutant_label, granularity)
        st.markdown(f"**Tren {pollutant_label} menurut waktu dan kota**")
        if not trend.empty:
            st.line_chart(trend, x_label="Waktu (WIB)", y_label=f"{pollutant_label} ({pollutant['unit']})")
            _render_interpretation(
                f"Tren temporal {pollutant_label}",
                _trend_interpretation(trend, pollutant_label),
                "Agregasi per jam, hari, atau minggu menyesuaikan panjang periode yang dipilih.",
            )
        else:
            st.info("Belum cukup observasi untuk membentuk tren temporal.")

        st.markdown(f"**Pola rata-rata {pollutant_label} berdasarkan jam dan kota**")
        heatmap = build_hourly_heatmap(detail_data, pollutant_label)
        if not heatmap.empty:
            heat_spec = {
                "mark": {"type": "rect", "cornerRadius": 2},
                "encoding": {
                    "x": {"field": "hour", "type": "ordinal", "title": "Jam (WIB)", "sort": list(range(24))},
                    "y": {"field": "city", "type": "nominal", "title": "Kota", "sort": selected_cities},
                    "color": {"field": "mean", "type": "quantitative", "title": pollutant["unit"], "scale": {"scheme": "yelloworangered"}},
                    "tooltip": [
                        {"field": "city", "type": "nominal", "title": "Kota"},
                        {"field": "hour", "type": "ordinal", "title": "Jam"},
                        {"field": "mean", "type": "quantitative", "title": pollutant_label, "format": ".2f"},
                    ],
                },
            }
            st.vega_lite_chart(heatmap, heat_spec, use_container_width=True)
            _render_interpretation(
                f"Heatmap jam-kota {pollutant_label}",
                _heatmap_interpretation(heatmap, pollutant_label),
                "Heatmap menunjukkan rata-rata pada jam yang sama; jumlah observasi per jam dapat berbeda.",
            )
        else:
            st.info("Data belum cukup untuk heatmap jam-kota.")

        st.markdown(f"**Distribusi {pollutant_label} per kota**")
        box_data = pollutant_data[["city", pollutant_column]].copy()
        if not box_data.empty:
            box_spec = {
                "mark": {"type": "boxplot", "extent": 1.5},
                "encoding": {
                    "x": {"field": "city", "type": "nominal", "title": "Kota", "sort": selected_cities},
                    "y": {"field": pollutant_column, "type": "quantitative", "title": f"{pollutant_label} ({pollutant['unit']})", "scale": {"zero": False}},
                    "color": {"field": "city", "type": "nominal", "legend": None},
                    "tooltip": [
                        {"field": "city", "type": "nominal"},
                        {"field": pollutant_column, "type": "quantitative", "title": pollutant_label, "format": ".2f"},
                    ],
                },
            }
            st.vega_lite_chart(box_data, box_spec, use_container_width=True)
            _render_interpretation(
                f"Distribusi {pollutant_label}",
                _boxplot_interpretation(detail_data, pollutant_label),
                "Titik di luar whisker adalah outlier statistik berdasarkan aturan 1,5 × IQR, bukan otomatis kesalahan data.",
            )
        else:
            st.info("Belum ada distribusi yang dapat ditampilkan.")

    # ---------------------------------------------------------------- bivariate
    with bivariate_tab:
        st.subheader("Hubungan Satu Polutan dengan European AQI")
        bivariate_label = st.selectbox(
            "Pilih polutan untuk dibandingkan dengan AQI",
            list(POLLUTANT_CONFIG.keys()),
            key="bivariate_pollutant",
        )
        bivariate_column = POLLUTANT_CONFIG[bivariate_label]["column"]
        paired = detail_data[[bivariate_column, "european_aqi", "city"]].copy()
        paired[bivariate_column] = pd.to_numeric(paired[bivariate_column], errors="coerce")
        paired["european_aqi"] = pd.to_numeric(paired["european_aqi"], errors="coerce")
        paired = paired.dropna(subset=[bivariate_column, "european_aqi"])
        paired = paired.loc[paired["european_aqi"] >= 0]

        st.caption("Setiap titik mewakili satu observasi kota-jam. Warna membedakan kota.")
        if len(paired) >= 3:
            r = paired[bivariate_column].corr(paired["european_aqi"], method="pearson")
            st.scatter_chart(paired, x=bivariate_column, y="european_aqi", color="city",
                             x_label=f"{bivariate_label} ({POLLUTANT_CONFIG[bivariate_label]['unit']})",
                             y_label="European AQI")
            _render_interpretation(
                f"{bivariate_label} vs European AQI",
                _correlation_sentence(bivariate_label, "European AQI", r, len(paired), "Pearson"),
                "European AQI Eropa merupakan indeks maksimum subindeks PM2.5, PM10, NO₂, O₃, dan SO₂. "
                "Karena polutan terpilih dapat menjadi komponen pembentuk indeks, korelasi sebagian mencerminkan konstruksi indeks; "
                "CO bukan komponen European AQI. Korelasi tidak membuktikan sebab-akibat.",
            )
        else:
            st.info("Pasangan observasi polutan dan AQI belum cukup untuk scatter plot dan korelasi.")

    # ---------------------------------------------------------------- multivariate
    with multivariate_tab:
        st.subheader("Keterkaitan Antarpolutan dan Faktor Meteorologi")
        st.caption(
            "Analisis mencakup enam polutan dan enam variabel meteorologi. European AQI tidak dimasukkan "
            "agar indeks turunan tidak mendominasi korelasi dengan polutan pembentuknya."
        )
        method = st.selectbox(
            "Metode korelasi",
            ["pearson", "spearman"],
            format_func=lambda value: "Pearson" if value == "pearson" else "Spearman",
            key="multivariate_corr_method",
        )
        analysis_columns = (
            [config["column"] for config in POLLUTANT_CONFIG.values()]
            + [config["column"] for config in METEOROLOGY_CONFIG.values()]
        )
        matrix, ranked_pairs, count_matrix = correlation_analysis(detail_data, analysis_columns, method)
        if matrix.empty or matrix.notna().sum().sum() == 0:
            st.info("Observasi berpasangan belum cukup untuk menghitung matriks korelasi.")
        else:
            display_labels = {
                config["column"]: label for label, config in {**POLLUTANT_CONFIG, **METEOROLOGY_CONFIG}.items()
            }
            corr_view = matrix.rename(index=display_labels, columns=display_labels)
            corr_long = (
                corr_view.rename_axis("Variabel X").reset_index()
                .melt(id_vars="Variabel X", var_name="Variabel Y", value_name="Korelasi")
                .dropna(subset=["Korelasi"])
            )
            st.markdown(f"**{method.title()} Correlation Matrix — 12 variabel**")
            if not corr_long.empty:
                corr_spec = {
                    "layer": [
                        {
                            "mark": {"type": "rect", "cornerRadius": 2},
                            "encoding": {
                                "x": {
                                    "field": "Variabel X",
                                    "type": "nominal",
                                    "title": "",
                                    "axis": {"labelFontSize": 11, "labelAngle": -35, "labelLimit": 150},
                                },
                                "y": {
                                    "field": "Variabel Y",
                                    "type": "nominal",
                                    "title": "",
                                    "axis": {"labelFontSize": 11, "labelAngle": 0, "labelLimit": 150},
                                },
                                "color": {
                                    "field": "Korelasi", "type": "quantitative", "title": "r",
                                    "scale": {"domain": [-1, 0, 1], "range": ["#B91C1C", "#F8FAFC", "#1D4ED8"]},
                                },
                                "tooltip": [
                                    {"field": "Variabel X", "type": "nominal"},
                                    {"field": "Variabel Y", "type": "nominal"},
                                    {"field": "Korelasi", "type": "quantitative", "format": ".3f"},
                                ],
                            },
                        },
                        {
                            "mark": {
                                "type": "text",
                                "fontSize": 12,
                                "fontWeight": "bold",
                                "color": "#111827",
                            },
                            "encoding": {
                                "x": {"field": "Variabel X", "type": "nominal"},
                                "y": {"field": "Variabel Y", "type": "nominal"},
                                "text": {"field": "Korelasi", "type": "quantitative", "format": ".2f"},
                            },
                        },
                    ]
                }
                st.vega_lite_chart(corr_long, corr_spec, use_container_width=True)
                _render_interpretation(
                    f"Correlation Matrix ({method.title()})",
                    (
                        f"Matriks memperlihatkan korelasi pasangan variabel. "
                        f"{len(ranked_pairs):,} pasangan memiliki koefisien yang dapat dihitung."
                    ),
                    "Korelasi gabungan seluruh kota dapat dipengaruhi perbedaan karakteristik antarkota. "
                    "Gunakan filter kota untuk memeriksa apakah pola tetap terlihat secara lokal. "
                    "Pearson mengukur pola linear; Spearman mengukur pola monotonik.",
                )
                if not ranked_pairs.empty:
                    top_pairs = ranked_pairs.head(5).copy()
                    top_pairs["Variabel A"] = top_pairs["variable_a"].map(display_labels)
                    top_pairs["Variabel B"] = top_pairs["variable_b"].map(display_labels)
                    top_pairs["Koefisien"] = top_pairs["correlation"].round(3)
                    top_pairs = top_pairs[["Variabel A", "Variabel B", "Koefisien", "n_pairs"]].rename(
                        columns={"n_pairs": "N pasangan"}
                    )
                    st.markdown("**Lima pasangan dengan korelasi absolut tertinggi**")
                    st.dataframe(top_pairs, hide_index=True, use_container_width=True)
                    first = ranked_pairs.iloc[0]
                    _render_interpretation(
                        "Pasangan korelasi terkuat",
                        _correlation_sentence(
                            display_labels.get(first["variable_a"], first["variable_a"]),
                            display_labels.get(first["variable_b"], first["variable_b"]),
                            first["correlation"],
                            int(first["n_pairs"]),
                            method,
                        ),
                        "Ranking berdasarkan nilai absolut koefisien, bukan bukti bahwa satu variabel menyebabkan variabel lain.",
                    )
                with st.expander("Jumlah pasangan observasi per variabel"):
                    st.dataframe(count_matrix.rename(index=display_labels, columns=display_labels), use_container_width=True)
            else:
                st.info("Belum ada pasangan variabel dengan observasi cukup.")

    # ---------------------------------------------------------------- meteorology
    with meteo_tab:
        st.subheader("Hubungan Polutan dengan Faktor Meteorologi")
        meteo_pollutant_label = st.selectbox(
            "Pilih satu polutan",
            list(POLLUTANT_CONFIG.keys()),
            key="meteorology_pollutant",
        )
        meteo_pollutant_column = POLLUTANT_CONFIG[meteo_pollutant_label]["column"]
        meteo_pollutant_unit = POLLUTANT_CONFIG[meteo_pollutant_label]["unit"]
        st.caption(
            "Scatter plot memperlihatkan pasangan observasi pada jam yang sama. "
            "Pilih kota tertentu pada filter global untuk memeriksa pola per kota."
        )
        meteo_columns = list(METEOROLOGY_CONFIG.values())
        scatter_cols = st.columns(2)
        for index, (meteo_label, meteo_config) in enumerate(METEOROLOGY_CONFIG.items()):
            meteo_column = meteo_config["column"]
            scatter_data = detail_data[[meteo_column, meteo_pollutant_column, "city"]].copy()
            scatter_data[meteo_column] = pd.to_numeric(scatter_data[meteo_column], errors="coerce")
            scatter_data[meteo_pollutant_column] = pd.to_numeric(scatter_data[meteo_pollutant_column], errors="coerce")
            scatter_data = scatter_data.dropna(subset=[meteo_column, meteo_pollutant_column])
            with scatter_cols[index % 2]:
                st.markdown(f"**{meteo_pollutant_label} vs {meteo_label}**")
                if len(scatter_data) >= 3:
                    r = scatter_data[meteo_column].corr(scatter_data[meteo_pollutant_column], method="pearson")
                    st.scatter_chart(
                        scatter_data,
                        x=meteo_column,
                        y=meteo_pollutant_column,
                        color="city",
                        x_label=f"{meteo_label} ({meteo_config['unit']})",
                        y_label=f"{meteo_pollutant_label} ({meteo_pollutant_unit})",
                    )
                    _render_interpretation(
                        f"{meteo_pollutant_label} vs {meteo_label}",
                        _correlation_sentence(meteo_label, meteo_pollutant_label, r, len(scatter_data), "Pearson"),
                        "Hubungan dihitung pada jam yang sama dan seluruh kota terpilih. Pola dapat dipengaruhi kota, musim, "
                        "aktivitas emisi, dan variabel lain yang tidak tersedia.",
                    )
                else:
                    st.info(f"Pasangan observasi {meteo_label} dan {meteo_pollutant_label} belum cukup.")

        st.divider()
        st.markdown("**Lagged Correlation — meteorologi mendahului polutan**")
        st.caption(
            "Lag 0 membandingkan jam yang sama. Lag 1, 3, 6, dan 12 membandingkan meteorologi pada waktu t "
            "dengan polutan pada t + lag. Pencocokan menggunakan kota dan timestamp aktual."
        )
        lag_results = calculate_lagged_correlations(
            detail_data,
            meteo_pollutant_column,
            [config["column"] for config in METEOROLOGY_CONFIG.values()],
            lags=(0, 1, 3, 6, 12),
        )
        valid_lags = lag_results.dropna(subset=["correlation"])
        if not valid_lags.empty:
            lag_results["meteorology_label"] = lag_results["meteorology"].map(
                {config["column"]: label for label, config in METEOROLOGY_CONFIG.items()}
            )
            lag_long = lag_results.dropna(subset=["correlation"]).copy()
            lag_spec = {
                "layer": [
                    {
                        "mark": {"type": "rect", "cornerRadius": 2},
                        "encoding": {
                            "x": {"field": "lag_hours", "type": "ordinal", "title": "Lag (jam)", "sort": [0, 1, 3, 6, 12]},
                            "y": {"field": "meteorology_label", "type": "nominal", "title": "Faktor meteorologi"},
                            "color": {
                                "field": "correlation", "type": "quantitative", "title": "Pearson r",
                                "scale": {"domain": [-1, 0, 1], "range": ["#B91C1C", "#F8FAFC", "#1D4ED8"]},
                            },
                            "tooltip": [
                                {"field": "meteorology_label", "type": "nominal", "title": "Faktor"},
                                {"field": "lag_hours", "type": "ordinal", "title": "Lag (jam)"},
                                {"field": "correlation", "type": "quantitative", "format": ".3f", "title": "Pearson r"},
                                {"field": "n_pairs", "type": "quantitative", "title": "N pasangan"},
                            ],
                        },
                    },
                    {
                        "mark": {"type": "text", "fontSize": 10, "color": "#111827"},
                        "encoding": {
                            "x": {"field": "lag_hours", "type": "ordinal", "sort": [0, 1, 3, 6, 12]},
                            "y": {"field": "meteorology_label", "type": "nominal"},
                            "text": {"field": "correlation", "type": "quantitative", "format": ".2f"},
                        },
                    },
                ]
            }
            st.vega_lite_chart(lag_long, lag_spec, use_container_width=True)
            best_lag = valid_lags.loc[valid_lags["correlation"].abs().idxmax()]
            best_label = next(
                label for label, config in METEOROLOGY_CONFIG.items()
                if config["column"] == best_lag["meteorology"]
            )
            timing = "pada jam yang sama" if int(best_lag["lag_hours"]) == 0 else f"{int(best_lag['lag_hours'])} jam sebelumnya"
            _render_interpretation(
                "Lagged Correlation",
                f"Korelasi absolut terbesar pada kombinasi yang dapat dihitung ditemukan antara {best_label} "
                f"{timing} dan {meteo_pollutant_label} (r = {best_lag['correlation']:.3f}; "
                f"n = {int(best_lag['n_pairs']):,} pasangan).",
                "Lag menunjukkan urutan waktu statistik, bukan bukti jeda sebab-akibat. Hasil lag berbeda dapat memiliki jumlah pasangan "
                "observasi berbeda; interpretasikan bersama coverage dan pola per kota.",
            )
            lag_table = lag_results[["meteorology_label", "lag_hours", "correlation", "n_pairs"]].rename(
                columns={"meteorology_label": "Faktor meteorologi", "lag_hours": "Lag (jam)",
                         "correlation": "Pearson r", "n_pairs": "N pasangan"}
            )
            with st.expander("Rincian koefisien dan jumlah pasangan"):
                st.dataframe(lag_table, hide_index=True, use_container_width=True)
        else:
            st.info("Data meteorologi yang selaras belum cukup untuk menghitung lagged correlation.")

    # ---------------------------------------------------------------- conclusion
    with conclusion_tab:
        st.subheader("Kesimpulan dan Temuan Utama")
        aqi = pd.to_numeric(detail_data["european_aqi"], errors="coerce").dropna()
        aqi = aqi.loc[aqi >= 0]
        if not aqi.empty:
            category = aqi.map(classify_european_aqi).value_counts()
            dominant_category = category.index[0]
            st.markdown(
                f"**Ringkasan AQI:** rata-rata {aqi.mean():.1f}, maksimum {aqi.max():.1f}, "
                f"dan kategori yang paling sering muncul adalah {dominant_category}."
            )
        else:
            st.markdown("**Ringkasan AQI:** belum tersedia observasi European AQI yang valid.")

        conclusion_pollutant = st.session_state.get("city_pollutant", "PM2.5")
        conclusion_config = POLLUTANT_CONFIG.get(conclusion_pollutant, POLLUTANT_CONFIG["PM2.5"])
        conclusion_column = conclusion_config["column"]
        city_means = detail_data.groupby("city")[conclusion_column].mean().dropna().sort_values(ascending=False)
        if not city_means.empty:
            st.markdown(
                f"**Perbandingan kota:** rata-rata {conclusion_pollutant} tertinggi terdapat di "
                f"{city_means.index[0]} ({_format_measure(city_means.iloc[0], ' ' + conclusion_config['unit'])})."
            )

        bivariate_label = st.session_state.get("bivariate_pollutant", "PM2.5")
        bivariate_column = POLLUTANT_CONFIG.get(bivariate_label, POLLUTANT_CONFIG["PM2.5"])["column"]
        bivariate_pairs = detail_data[[bivariate_column, "european_aqi"]].dropna()
        if len(bivariate_pairs) >= 3:
            bivariate_r = bivariate_pairs[bivariate_column].corr(bivariate_pairs["european_aqi"])
            st.markdown(
                f"**Bivariate:** korelasi Pearson {bivariate_label} dengan European AQI adalah "
                f"{bivariate_r:.3f} berdasarkan {len(bivariate_pairs):,} pasangan observasi."
            )

        method = st.session_state.get("multivariate_corr_method", "pearson")
        analysis_columns = (
            [config["column"] for config in POLLUTANT_CONFIG.values()]
            + [config["column"] for config in METEOROLOGY_CONFIG.values()]
        )
        _, ranked_pairs, _ = correlation_analysis(detail_data, analysis_columns, method)
        if not ranked_pairs.empty:
            first = ranked_pairs.iloc[0]
            labels = {
                config["column"]: label for label, config in {**POLLUTANT_CONFIG, **METEOROLOGY_CONFIG}.items()
            }
            st.markdown(
                f"**Keterkaitan antarvariabel:** pasangan dengan korelasi absolut tertinggi adalah "
                f"{labels[first['variable_a']]} dan {labels[first['variable_b']]} "
                f"({method.title()} r = {first['correlation']:.3f})."
            )

        lag_pollutant_label = st.session_state.get("meteorology_pollutant", "PM2.5")
        lag_pollutant_column = POLLUTANT_CONFIG.get(lag_pollutant_label, POLLUTANT_CONFIG["PM2.5"])["column"]
        lag_results = calculate_lagged_correlations(
            detail_data, lag_pollutant_column,
            [config["column"] for config in METEOROLOGY_CONFIG.values()],
        )
        valid_lags = lag_results.dropna(subset=["correlation"])
        if not valid_lags.empty:
            best_lag = valid_lags.loc[valid_lags["correlation"].abs().idxmax()]
            lag_name = next(
                label for label, config in METEOROLOGY_CONFIG.items()
                if config["column"] == best_lag["meteorology"]
            )
            st.markdown(
                f"**Meteorologi dan lag:** hubungan absolut terbesar yang teramati adalah {lag_name} "
                f"pada lag {int(best_lag['lag_hours'])} jam terhadap {lag_pollutant_label} "
                f"(Pearson r = {best_lag['correlation']:.3f}; n = {int(best_lag['n_pairs']):,})."
            )

        _render_interpretation(
            "Kesimpulan keseluruhan",
            "Temuan di atas merangkum pola yang muncul pada periode dan kota terpilih. Gunakan hasil ini untuk menentukan "
            "kota, polutan, dan rentang waktu yang perlu ditinjau lebih lanjut; jangan menyimpulkan sumber penyebab hanya "
            "dari korelasi atau urutan waktu.",
            "Data kualitas udara dan meteorologi berbasis model Open-Meteo/CAMS, bukan pengukuran langsung stasiun. "
            "Validasi lapangan dan data emisi lokal diperlukan sebelum rekomendasi kebijakan diterapkan.",
        )

        st.markdown("**Rekomendasi tindak lanjut**")
        st.markdown(
            "- Prioritaskan pemeriksaan data dan pemantauan pada kota, polutan, serta jam dengan nilai atau variasi tertinggi.\n"
            "- Bandingkan pola meteorologi dan polutan per kota sebelum menggeneralisasi hubungan ke seluruh wilayah.\n"
            "- Verifikasi temuan dengan data stasiun resmi dan informasi aktivitas emisi lokal sebelum menetapkan intervensi."
        )


# ---------------------------------------------------------------- machine learning

def read_forecast_evaluation(city: str) -> pd.DataFrame:
    """Return paired, matured forecasts where RF, persistence, CAMS and reference align."""
    return query(
        """
        WITH latest_ml AS (
            SELECT DISTINCT ON (city, forecast_at, horizon_hours)
                city,
                forecast_at,
                horizon_hours,
                random_forest_value,
                persistence_value,
                forecast_origin
            FROM ml.air_quality_forecast
            WHERE parameter_name = 'pm2_5'
              AND random_forest_value IS NOT NULL
              AND persistence_value IS NOT NULL
            ORDER BY city, forecast_at, horizon_hours, forecast_origin DESC
        ),
        latest_cams AS (
            SELECT DISTINCT ON (city, forecast_at, horizon_hours)
                city,
                forecast_at,
                horizon_hours,
                pm2_5 AS cams_value,
                forecast_origin
            FROM ml.cams_air_quality_forecast
            ORDER BY city, forecast_at, horizon_hours,
                     forecast_origin DESC, retrieved_at DESC
        )
        SELECT
            m.city,
            m.forecast_at,
            m.horizon_hours,
            m.random_forest_value,
            m.persistence_value,
            c.cams_value,
            a.pm2_5 AS reference_value
        FROM latest_ml AS m
        INNER JOIN latest_cams AS c
            ON c.city = m.city
           AND c.forecast_at = m.forecast_at
           AND c.horizon_hours = m.horizon_hours
        INNER JOIN staging.air_quality_raw AS a
            ON a.city = m.city
           AND a.valid_at = m.forecast_at
        WHERE m.city = %s
          AND a.valid_at <= (NOW() AT TIME ZONE 'Asia/Jakarta')
          AND a.pm2_5 IS NOT NULL
          AND m.random_forest_value IS NOT NULL
          AND m.persistence_value IS NOT NULL
          AND c.cams_value IS NOT NULL
        ORDER BY m.forecast_at DESC
        """,
        (city,),
    )


def _forecast_error_summary(frame: pd.DataFrame, prediction_column: str) -> tuple[int, float, float]:
    """Calculate MAE/RMSE against the later batch reference values."""
    valid = frame[[prediction_column, "reference_value"]].dropna()
    if valid.empty:
        return 0, float("nan"), float("nan")

    errors = (
        pd.to_numeric(valid[prediction_column], errors="coerce")
        - pd.to_numeric(valid["reference_value"], errors="coerce")
    ).dropna()
    if errors.empty:
        return 0, float("nan"), float("nan")

    mae = float(errors.abs().mean())
    rmse = float((errors.pow(2).mean()) ** 0.5)
    return len(errors), mae, rmse


def render_ml_forecast() -> None:
    """Compare the PM2.5 Random Forest forecast with CAMS Global."""
    if st.button("Muat ulang prediksi", key="ml_reload"):
        st.rerun()

    try:
        city_frame = query(
            """
            SELECT DISTINCT city
            FROM ml.air_quality_forecast
            WHERE parameter_name = 'pm2_5'
              AND random_forest_value IS NOT NULL
            ORDER BY city
            """
        )
    except (psycopg2.Error, OSError) as exc:
        st.info(
            "Struktur ML PM2.5 belum tersedia. Terapkan pembaruan Phase 4, "
            "kemudian jalankan DAG `air_quality_end_to_end`."
        )
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    if city_frame.empty:
        st.info(
            "Belum ada forecast PM2.5. Jalankan DAG `air_quality_end_to_end` "
            "dan pastikan task `ml_forecast_6h` berhasil."
        )
        return

    city = st.selectbox("Pilih kota", city_frame["city"].tolist(), key="ml_city")

    try:
        origin_frame = query(
            """
            SELECT MAX(forecast_origin) AS forecast_origin
            FROM ml.air_quality_forecast
            WHERE city = %s AND parameter_name = 'pm2_5'
            """,
            (city,),
        )
        if origin_frame.empty or pd.isna(origin_frame.iloc[0]["forecast_origin"]):
            st.info("Belum ada origin forecast PM2.5 untuk kota ini.")
            return

        origin = pd.Timestamp(origin_frame.iloc[0]["forecast_origin"])

        forecast = query(
            """
            SELECT
                forecast_origin,
                forecast_at,
                horizon_hours,
                predicted_value,
                selected_model,
                holdout_mae,
                holdout_rmse,
                random_forest_value,
                persistence_value,
                seasonal_naive_value
            FROM ml.air_quality_forecast
            WHERE city = %s
              AND parameter_name = 'pm2_5'
              AND forecast_origin = %s
            ORDER BY forecast_at
            """,
            (city, origin.to_pydatetime()),
        )

        holdout_metrics = query(
            """
            SELECT parameter_name, horizon_hours, model_name, mae, rmse,
                   train_rows, test_rows, is_selected
            FROM ml.model_metrics
            WHERE city = %s
              AND parameter_name = 'pm2_5'
              AND evaluated_at = (
                  SELECT MAX(evaluated_at)
                  FROM ml.model_metrics
                  WHERE city = %s AND parameter_name = 'pm2_5'
              )
            ORDER BY horizon_hours, is_selected DESC, mae
            """,
            (city, city),
        )

        history = query(
            """
            SELECT valid_at, pm2_5
            FROM staging.air_quality_raw
            WHERE city = %s
              AND valid_at <= %s
              AND pm2_5 IS NOT NULL
            ORDER BY valid_at DESC
            LIMIT 24
            """,
            (city, origin.to_pydatetime()),
        )

    except (psycopg2.Error, OSError) as exc:
        st.error("Data prediksi ML belum dapat dibaca dari PostgreSQL.")
        with st.expander("Detail teknis"):
            st.code(str(exc))
        return

    cams_error = None
    try:
        cams = query(
            """
            SELECT forecast_origin, forecast_at, horizon_hours,
                   pm2_5, domain, retrieved_at
            FROM ml.cams_air_quality_forecast
            WHERE city = %s
              AND forecast_origin = %s
            ORDER BY forecast_at
            """,
            (city, origin.to_pydatetime()),
        )
        evaluation = read_forecast_evaluation(city)
    except (psycopg2.Error, OSError) as exc:
        cams = pd.DataFrame(
            columns=[
                "forecast_origin", "forecast_at", "horizon_hours",
                "pm2_5", "domain", "retrieved_at",
            ]
        )
        evaluation = pd.DataFrame()
        cams_error = str(exc)

    if forecast.empty:
        st.info("Belum ada forecast ML untuk kota yang dipilih.")
        return

    forecast["forecast_origin"] = pd.to_datetime(forecast["forecast_origin"])
    forecast["forecast_at"] = pd.to_datetime(forecast["forecast_at"])
    forecast["horizon_hours"] = pd.to_numeric(forecast["horizon_hours"], errors="coerce")
    for column in [
        "predicted_value",
        "random_forest_value",
        "persistence_value",
        "seasonal_naive_value",
        "holdout_mae",
        "holdout_rmse",
    ]:
        forecast[column] = pd.to_numeric(forecast[column], errors="coerce")

    if not cams.empty:
        cams["forecast_origin"] = pd.to_datetime(cams["forecast_origin"])
        cams["forecast_at"] = pd.to_datetime(cams["forecast_at"])
        cams["horizon_hours"] = pd.to_numeric(cams["horizon_hours"], errors="coerce")
        cams["pm2_5"] = pd.to_numeric(cams["pm2_5"], errors="coerce")

    if not history.empty:
        history["valid_at"] = pd.to_datetime(history["valid_at"])
        history["pm2_5"] = pd.to_numeric(history["pm2_5"], errors="coerce")

    st.caption(
        f"Kota: **{city}** · Origin observasi: "
        f"**{origin:%d/%m/%Y %H:%M} WIB** · Horizon model: +1 sampai +6 jam"
    )

    if cams_error:
        st.info(
            "Tabel forecast CAMS belum tersedia atau task CAMS belum pernah sukses. "
            "Forecast Random Forest tetap dapat ditampilkan. Jalankan task "
            "`cams_forecast_pm25` melalui DAG."
        )
        with st.expander("Detail teknis CAMS"):
            st.code(cams_error)

    next_ml = forecast.sort_values("horizon_hours").iloc[0]
    next_cams = cams.sort_values("horizon_hours").iloc[0] if not cams.empty else None

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Prediksi Random Forest · +1 jam", f"{next_ml['random_forest_value']:.1f} µg/m³")
    k1.caption("Model ML PM2.5")
    if next_cams is not None:
        k2.metric(
            f"CAMS Global · +{int(next_cams['horizon_hours'])} jam",
            f"{next_cams['pm2_5']:.1f} µg/m³",
        )
        k2.caption("Titik forecast terdekat yang tersedia")
    else:
        k2.metric("Forecast CAMS Global", "Belum tersedia")
    k3.metric("Titik forecast CAMS", f"{len(cams):,}")
    k3.caption("Timestamp API dalam horizon enam jam")
    k4.metric("Titik evaluasi matang", f"{len(evaluation):,}")
    k4.caption("Target yang sudah memiliki referensi historis")

    st.subheader("PM2.5: historis dan forecast enam jam ke depan")
    chart_series = []

    if not history.empty:
        history_series = (
            history.sort_values("valid_at")
            .set_index("valid_at")["pm2_5"]
            .rename("Referensi historis")
        )
        chart_series.append(history_series)

    rf_series = (
        forecast.set_index("forecast_at")["random_forest_value"]
        .dropna()
        .rename("Random Forest")
    )
    persistence_series = (
        forecast.set_index("forecast_at")["persistence_value"]
        .dropna()
        .rename("Persistence")
    )
    chart_series.extend([rf_series, persistence_series])

    if not cams.empty:
        cams_series = (
            cams.set_index("forecast_at")["pm2_5"]
            .dropna()
            .rename("Open-Meteo / CAMS Global")
        )
        chart_series.append(cams_series)

    chart_data = pd.concat(chart_series, axis=1).sort_index()
    if chart_data.empty:
        st.info("Belum ada titik data yang dapat digambarkan.")
    else:
        st.line_chart(
            chart_data,
            x_label="Waktu (WIB)",
            y_label="Konsentrasi PM2.5 (µg/m³)",
        )

    st.caption(
        "CAMS Global memiliki resolusi waktu sumber tiga jam. Grafik memakai "
        "timestamp yang dikembalikan API apa adanya; sistem tidak membuat "
        "interpolasi atau nilai forecast buatan untuk mengisi jam yang tidak tersedia."
    )

    st.subheader("Tabel perbandingan forecast")
    forecast_table = forecast[
        [
            "forecast_at",
            "horizon_hours",
            "random_forest_value",
            "persistence_value",
            "predicted_value",
            "selected_model",
        ]
    ].copy()

    if not cams.empty:
        forecast_table = forecast_table.merge(
            cams[["forecast_at", "horizon_hours", "pm2_5"]].rename(
                columns={"pm2_5": "cams_pm2_5"}
            ),
            on=["forecast_at", "horizon_hours"],
            how="left",
        )
    else:
        forecast_table["cams_pm2_5"] = float("nan")

    forecast_table = forecast_table.rename(
        columns={
            "forecast_at": "Waktu target (WIB)",
            "horizon_hours": "Horizon (jam)",
            "random_forest_value": "Random Forest (µg/m³)",
            "persistence_value": "Persistence (µg/m³)",
            "predicted_value": "Model terpilih (µg/m³)",
            "selected_model": "Kandidat terpilih",
            "cams_pm2_5": "CAMS Global (µg/m³)",
        }
    )
    st.dataframe(forecast_table, width="stretch", hide_index=True)

    st.divider()
    st.subheader("Evaluasi aktual: Random Forest vs Persistence vs CAMS")

    if evaluation.empty:
        st.info(
            "Belum ada pasangan forecast yang dapat dinilai. Metrik akan muncul "
            "setelah timestamp target forecast terlewati dan data referensi batch "
            "untuk timestamp yang sama tersedia di staging."
        )
    else:
        count_rf, mae_rf, rmse_rf = _forecast_error_summary(
            evaluation, "random_forest_value"
        )
        count_persistence, mae_persistence, rmse_persistence = _forecast_error_summary(
            evaluation, "persistence_value"
        )
        count_cams, mae_cams, rmse_cams = _forecast_error_summary(
            evaluation, "cams_value"
        )

        e1, e2, e3, e4 = st.columns(4)
        e1.metric("Forecast sudah dinilai", f"{len(evaluation):,}")
        e2.metric("MAE Random Forest", f"{mae_rf:.2f} µg/m³" if pd.notna(mae_rf) else "—")
        e3.metric("MAE Persistence", f"{mae_persistence:.2f} µg/m³" if pd.notna(mae_persistence) else "—")
        e4.metric("MAE CAMS", f"{mae_cams:.2f} µg/m³" if pd.notna(mae_cams) else "—")

        evaluation_summary = pd.DataFrame(
            [
                {
                    "Metode": "Random Forest",
                    "Jumlah target": count_rf,
                    "MAE (µg/m³)": mae_rf,
                    "RMSE (µg/m³)": rmse_rf,
                },
                {
                    "Metode": "Persistence",
                    "Jumlah target": count_persistence,
                    "MAE (µg/m³)": mae_persistence,
                    "RMSE (µg/m³)": rmse_persistence,
                },
                {
                    "Metode": "Open-Meteo / CAMS Global",
                    "Jumlah target": count_cams,
                    "MAE (µg/m³)": mae_cams,
                    "RMSE (µg/m³)": rmse_cams,
                },
            ]
        )
        st.dataframe(evaluation_summary, width="stretch", hide_index=True)

        st.caption(
            "Evaluasi rolling hanya memakai target waktu yang sama dan memiliki "
            "prediksi dari ketiga metode serta nilai referensi batch. Nilai referensi "
            "berasal dari Open-Meteo/CAMS yang masuk kemudian, bukan sensor lapangan."
        )

        with st.expander("Detail titik evaluasi"):
            detail = evaluation.sort_values("forecast_at", ascending=False).rename(
                columns={
                    "forecast_at": "Waktu target (WIB)",
                    "horizon_hours": "Horizon (jam)",
                    "random_forest_value": "Random Forest",
                    "persistence_value": "Persistence",
                    "cams_value": "CAMS Global",
                    "reference_value": "Referensi batch",
                }
            )
            st.dataframe(detail, width="stretch", hide_index=True)

    with st.expander("Evaluasi holdout model ML"):
        if holdout_metrics.empty:
            st.info("Metrik holdout belum tersedia.")
        else:
            metrics_view = holdout_metrics.rename(
                columns={
                    "horizon_hours": "Horizon (jam)",
                    "model_name": "Kandidat",
                    "mae": "MAE (µg/m³)",
                    "rmse": "RMSE (µg/m³)",
                    "train_rows": "Baris training",
                    "test_rows": "Baris pengujian",
                    "is_selected": "Terpilih berdasarkan MAE",
                }
            )
            st.caption(
                "Holdout kronologis membandingkan Random Forest, Persistence, dan "
                "Seasonal Naive 24 jam. Kandidat terpilih ditentukan berdasarkan MAE "
                "pada data pengujian historis."
            )
            st.dataframe(metrics_view, width="stretch", hide_index=True)

    st.caption(
        "Seluruh prediksi menggunakan PM2.5 saja. Forecast merupakan keluaran model "
        "atmosfer, bukan pengukuran langsung sensor. Perbandingan terhadap referensi "
        "batch tidak dapat menggantikan validasi menggunakan stasiun pemantauan independen."
    )



def render_settings() -> None:
    st.subheader("Kontrol Pipeline")
    st.caption(
        "Kontrol ON/OFF setiap jalur. Perubahan disimpan di PostgreSQL dan "
        "dibaca oleh service terkait tanpa restart container."
    )

    try:
        settings = read_pipeline_settings()
    except Exception as exc:  # noqa: BLE001
        st.error(
            "Konfigurasi pipeline belum dapat dibaca. Pastikan migration "
            "pipeline-control-init sudah berhasil dijalankan."
        )
        st.exception(exc)
        return

    # Reconcile widget state with the persisted database value before widgets
    # are instantiated. This also rolls back a visual toggle if its DB update failed.
    for name, column in PIPELINE_SETTING_COLUMNS.items():
        widget_key = f"pipeline_toggle_{name}"
        persisted_value = bool(settings[column])
        if st.session_state.get(widget_key) != persisted_value:
            st.session_state[widget_key] = persisted_value

    if notice := st.session_state.pop("pipeline_settings_notice", None):
        st.success(notice)
    if error := st.session_state.pop("pipeline_settings_error", None):
        st.error(error)

    updated_at = format_control_timestamp(settings.get("updated_at"))
    updated_by = settings.get("updated_by") or "unknown"

    pipeline_cards = [
        {
            "name": "batch",
            "title": "Jalur Batch",
            "description": "Open-Meteo → Airflow → Spark → Data Warehouse → Data Quality → CAMS",
            "schedule": "Jadwal DAG: setiap 3 jam",
            "last_label": "Data batch terakhir",
            "last_sql": "SELECT MAX(valid_at) AS last_at FROM staging.air_quality_raw",
            "on_text": "Recovery historis, extraction, transformasi Spark, warehouse, DQ, dan CAMS diizinkan.",
            "off_text": "Startup Recovery dan seluruh proses batch dilewati. Run batch yang sedang berjalan dibiarkan selesai.",
        },
        {
            "name": "streaming",
            "title": "Jalur Streaming",
            "description": "Sensor Simulator → Spark Structured Streaming → Data Warehouse",
            "schedule": "Runtime control: polling status setiap 5 detik",
            "last_label": "Batch streaming terakhir diproses",
            "last_sql": "SELECT MAX(processed_at) AS last_at FROM staging.stream_quality_log",
            "on_text": "Simulator menghasilkan data dan Spark memproses file incoming.",
            "off_text": "Simulator berhenti menghasilkan data dan Spark menghentikan query secara graceful. Checkpoint dan file yang belum diproses dipertahankan.",
        },
        {
            "name": "ml",
            "title": "Jalur ML (Prediksi)",
            "description": "Feature Engineering → Training → Scoring → Evaluation → Forecast",
            "schedule": "Jadwal DAG ML: setiap 1 jam",
            "last_label": "Origin prediksi ML terakhir",
            "last_sql": "SELECT MAX(forecast_origin) AS last_at FROM ml.air_quality_forecast",
            "on_text": "DAG ML independen diizinkan menjalankan training, scoring, evaluasi, dan forecast.",
            "off_text": "Eksekusi ML berikutnya dilewati. Model dan hasil prediksi sebelumnya tetap tersimpan.",
        },
    ]

    for card in pipeline_cards:
        name = card["name"]
        enabled = bool(settings[PIPELINE_SETTING_COLUMNS[name]])
        with st.container(border=True):
            title_col, toggle_col = st.columns([5, 1])
            with title_col:
                st.markdown(f"**{card['title']}**")
                st.caption(card["description"])
            with toggle_col:
                st.toggle(
                    "Aktif",
                    key=f"pipeline_toggle_{name}",
                    on_change=update_pipeline_setting,
                    args=(name,),
                )

            if enabled:
                st.success("AKTIF · " + card["on_text"])
            else:
                st.info("NONAKTIF · " + card["off_text"])

            st.caption(card["schedule"])
            st.caption(
                f"{card['last_label']}: "
                f"{latest_pipeline_timestamp(card['last_sql'])}"
            )
            st.caption(f"Pengaturan terakhir: {updated_at} · oleh {updated_by}")

    st.divider()
    st.caption(
        "Catatan: ON berarti jalur diizinkan berjalan, bukan jaminan seluruh "
        "container sedang sehat. Perubahan Batch/ML berlaku pada pemeriksaan "
        "DAG berikutnya. Perubahan Streaming diterapkan secara runtime tanpa "
        "menghapus checkpoint."
    )


st.set_page_config(page_title="Kualitas Udara | Praktikum", layout="wide")
st.title("Kualitas Udara Lima Kota")
st.caption("Praktikum Big Data · waktu Asia/Jakarta")

tab_live, tab_batch, tab_analytics, tab_ml, tab_settings = st.tabs(
    ["Live (streaming)", "Per jam (batch)", "Analitik", "Prediksi (ML)", "Pengaturan"]
)
with tab_live:
    st.caption("Jalur streaming: sensor simulasi → Spark Structured Streaming → warehouse. Diperbarui otomatis tiap 5 detik.")
    render_live()
with tab_batch:
    st.caption("Jalur batch: Open-Meteo → Airflow → Spark → warehouse. Diperbarui tiap run DAG (tiap 3 jam).")
    render_batch()
with tab_analytics:
    st.caption("Multi-pollutant analytics: filter periode, kota, dan variabel; interpretasi berbasis data; serta kesimpulan dan rekomendasi.")
    render_analytics()
with tab_ml:
    st.caption("Jalur prediksi: Random Forest PM2.5 dibandingkan dengan Persistence dan Open-Meteo/CAMS Global.")
    render_ml_forecast()
with tab_settings:
    render_settings()
