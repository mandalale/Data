# Phase 4 — PM2.5 ML vs Open-Meteo CAMS Global

Patch ini memperbarui dashboard dan pipeline yang sudah ada. Tidak membuat aplikasi
atau DAG baru.

## File dalam patch

- `airflow/dags/air_quality_pipeline.py`
  - Menambahkan task `cams_forecast_pm25` setelah `ml_forecast_6h`.
- `spark/jobs/air_quality_ml.py`
  - Menyederhanakan input dan target ML menjadi PM2.5 saja.
  - Tetap membandingkan Random Forest, Persistence, dan Seasonal Naive 24 jam.
  - Menyimpan prediksi Random Forest dan Persistence secara terpisah agar dapat
    dibandingkan dengan CAMS.
- `spark/jobs/air_quality_cams_forecast.py`
  - File baru untuk mengambil forecast PM2.5 dengan `domains=cams_global`.
  - Menyimpan timestamp dan nilai yang dikembalikan API apa adanya.
  - Tidak menginterpolasi atau membuat nilai forecast yang tidak tersedia.
- `dashboard/app.py`
  - Mempertahankan tab Live, Per jam, dan Analitik.
  - Mengembangkan tab Forecast & Rekomendasi menjadi perbandingan PM2.5
    Random Forest, Persistence, dan CAMS Global.

## Cara memasang

1. Ekstrak ZIP patch ke folder root project yang berisi `docker-compose.yml`,
   misalnya `C:\bigdata\air-quality`.
2. Izinkan Windows mengganti tiga file yang sudah ada dan menambahkan satu file
   baru:
   - `airflow/dags/air_quality_pipeline.py`
   - `spark/jobs/air_quality_ml.py`
   - `spark/jobs/air_quality_cams_forecast.py`
   - `dashboard/app.py`
3. Build ulang image dashboard karena `Dockerfile.dashboard` menyalin `app.py`
   ke dalam image:

   ```powershell
   docker compose build dashboard
   docker compose up -d --force-recreate dashboard
   ```

4. Kode DAG dan script job ter-mount sebagai bind volume. Restart scheduler dan
   DAG processor agar definisi task baru segera dimuat:

   ```powershell
   docker compose restart airflow-scheduler airflow-dag-processor
   ```

5. Periksa apakah DAG terdaftar:

   ```powershell
   docker compose exec airflow-scheduler airflow dags list
   ```

6. Jalankan pipeline:

   ```powershell
   docker compose exec airflow-scheduler airflow dags trigger air_quality_end_to_end
   ```

7. Pantau task di Airflow UI. Urutan akhir yang diharapkan:

   ```text
   extract_api_to_raw
       >>
   spark_clean_transform
       >>
   load_data_warehouse
       >>
   quality_check
       >>
   ml_forecast_6h
       >>
   cams_forecast_pm25
   ```

   Jika task CAMS gagal karena API/network, hasil ML tetap sudah tersimpan. Task
   CAMS memiliki retry sebanyak dua kali.

## Verifikasi PostgreSQL

### 1. Forecast ML PM2.5

```powershell
docker compose exec postgres psql -U platform -d air_quality_dw -P pager=off -c "SELECT f.city, f.forecast_origin, COUNT(*) AS forecast_rows, MIN(f.forecast_at) AS first_target, MAX(f.forecast_at) AS last_target FROM ml.air_quality_forecast f WHERE f.parameter_name = 'pm2_5' AND f.forecast_origin = (SELECT MAX(f2.forecast_origin) FROM ml.air_quality_forecast f2 WHERE f2.city = f.city AND f2.parameter_name = 'pm2_5') GROUP BY f.city, f.forecast_origin ORDER BY f.city;"
```

Target normal: 6 baris per kota, karena model membuat horizon +1 sampai +6 jam.

### 2. Forecast CAMS Global

```powershell
docker compose exec postgres psql -U platform -d air_quality_dw -P pager=off -c "SELECT city, forecast_origin, COUNT(*) AS forecast_rows, MIN(forecast_at) AS first_target, MAX(forecast_at) AS last_target FROM ml.cams_air_quality_forecast GROUP BY city, forecast_origin ORDER BY forecast_origin DESC, city;"
```

Jumlah baris CAMS dapat berbeda per kota dan run karena sistem menyimpan timestamp
forecast yang benar-benar dikembalikan API dalam horizon enam jam. CAMS Global
memiliki resolusi temporal sumber tiga jam; tidak semua horizon per jam harus ada.

### 3. Periksa kolom hasil model

```powershell
docker compose exec postgres psql -U platform -d air_quality_dw -P pager=off -c "SELECT city, forecast_origin, forecast_at, horizon_hours, predicted_value, selected_model, random_forest_value, persistence_value FROM ml.air_quality_forecast WHERE parameter_name = 'pm2_5' ORDER BY forecast_origin DESC, city, forecast_at LIMIT 30;"
```

## Interpretasi evaluasi dashboard

- `Random Forest`: prediksi dari model ML yang dilatih hanya menggunakan lag PM2.5
  dan fitur kalender.
- `Persistence`: baseline yang mengasumsikan nilai PM2.5 berikutnya sama dengan
  nilai terakhir yang tersedia.
- `CAMS Global`: forecast eksternal Open-Meteo dengan domain `cams_global`.
- `MAE/RMSE rolling`: dihitung hanya pada target timestamp yang sama ketika
  prediksi dari ketiga metode tersedia dan target waktunya sudah terlewati.
- Nilai referensi yang datang kemudian berasal dari jalur batch Open-Meteo/CAMS,
  bukan pengukuran sensor lapangan. Hasil ini merupakan evaluasi terhadap
  referensi model atmosfer, bukan validasi independen terhadap sensor.

## Catatan keamanan

ZIP project awal menyertakan file `.env`. Jangan ikutkan `.env` atau kredensial
asli saat membagikan source code. Jika file tersebut memuat password/token yang
bukan sekadar kredensial lokal sementara, rotasikan nilainya.
