
"""
KALIMANTAN TIMUR - DATA AVAILABILITY TEST
========================================
Period       : 2026-10-01 to 2026-10-30
Air Quality  : CAMS Global
Meteorology  : Historical Forecast API
Model        : ECMWF IFS

This script is independent of the main Air Quality pipeline.
It only retrieves data, validates availability, and creates
two CSV files for the pilot test.
"""

import csv
import json
import math
import urllib.parse
import urllib.request

from datetime import datetime, timedelta
from collections import Counter


# ============================================================
# 1. CONFIGURATION
# ============================================================

START_DATE = "2026-10-01"
END_DATE = "2026-10-30"

TIMEZONE = "Asia/Jakarta"

# Sesuaikan dengan model ID yang digunakan pipeline utama.
# ecmwf_ifs     : ECMWF IFS HRES 9 km
# ecmwf_ifs025  : ECMWF IFS 0.25 degree
WEATHER_MODEL = "ecmwf_ifs"

AIR_QUALITY_URL = (
    "https://air-quality-api.open-meteo.com/v1/air-quality"
)

WEATHER_URL = (
    "https://historical-forecast-api.open-meteo.com/v1/forecast"
)

# Pusat grid CAMS hasil validasi sebelumnya.
LOCATIONS = [
    {
        "name": "Samarinda",
        "latitude": -0.500000,
        "longitude": 117.200010
    },
    {
        "name": "Balikpapan",
        "latitude": -1.2999954,
        "longitude": 116.800020
    },
    {
        "name": "Bontang",
        "latitude": 0.099998474,
        "longitude": 117.500000
    }
]

AIR_VARIABLES = [
    "pm2_5",
    "carbon_monoxide"
]

WEATHER_VARIABLES = [
    "wind_speed_10m",
    "wind_direction_10m",
    "boundary_layer_height"
]

EXPECTED_AIR_STEP_HOURS = 3
EXPECTED_WEATHER_STEP_HOURS = 1

SUMMARY_FILE = (
    "availability_summary_kaltim_oct_2026.csv"
)

DATA_FILE = (
    "pilot_data_kaltim_oct_2026.csv"
)


# ============================================================
# 2. HELPER FUNCTIONS
# ============================================================

def build_url(base_url, params):
    query = urllib.parse.urlencode(params, safe=",")
    return f"{base_url}?{query}"


def fetch_json(url, source_name):
    print(f"\nRequesting {source_name}...")

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "AirQuality-Pilot-Test/1.0"}
    )

    with urllib.request.urlopen(request, timeout=90) as response:
        result = json.loads(
            response.read().decode("utf-8")
        )

    if isinstance(result, dict) and result.get("error"):
        raise RuntimeError(
            f"{source_name}: {result.get('reason')}"
        )

    return result


def normalize_response(response):
    if isinstance(response, dict):
        return [response]

    if isinstance(response, list):
        return response

    raise ValueError("Unexpected API response format.")


def is_valid(value):
    if value is None:
        return False

    if isinstance(value, float) and math.isnan(value):
        return False

    return True


def get_series(hourly, variable):
    values = hourly.get(variable)

    if values is None:
        return []

    return values


def build_expected_times(start_date, end_date, step_hours):
    start = datetime.strptime(
        start_date, "%Y-%m-%d"
    )

    end = datetime.strptime(
        end_date, "%Y-%m-%d"
    ) + timedelta(hours=23)

    timestamps = []

    current = start

    while current <= end:
        timestamps.append(
            current.strftime("%Y-%m-%dT%H:%M")
        )

        current += timedelta(hours=step_hours)

    return timestamps


def detect_intervals(timestamps):
    parsed = sorted(
        datetime.fromisoformat(t)
        for t in timestamps
    )

    intervals = []

    for i in range(1, len(parsed)):
        difference = (
            parsed[i] - parsed[i - 1]
        ).total_seconds() / 3600

        intervals.append(difference)

    if not intervals:
        return "Insufficient timestamps"

    counts = Counter(intervals)

    return ", ".join(
        f"{int(hours)}h ({count}x)"
        for hours, count in sorted(counts.items())
    )


def haversine(lat1, lon1, lat2, lon2):
    radius = 6371.0

    p1 = math.radians(lat1)
    p2 = math.radians(lat2)

    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)

    a = (
        math.sin(dp / 2) ** 2
        + math.cos(p1)
        * math.cos(p2)
        * math.sin(dl / 2) ** 2
    )

    return (
        2 * radius
        * math.asin(math.sqrt(a))
    )


def safe_get(values, index):
    if index >= len(values):
        return None

    return values[index]


def percentage(numerator, denominator):
    if denominator == 0:
        return 0.0

    return numerator / denominator * 100


# ============================================================
# 3. BUILD EXPECTED TIMESTAMPS
# ============================================================

EXPECTED_AIR_TIMES = build_expected_times(
    START_DATE,
    END_DATE,
    EXPECTED_AIR_STEP_HOURS
)

EXPECTED_WEATHER_TIMES = build_expected_times(
    START_DATE,
    END_DATE,
    EXPECTED_WEATHER_STEP_HOURS
)

print("=" * 65)
print("KALTIM DATA AVAILABILITY TEST")
print("=" * 65)

print(f"Period              : {START_DATE} to {END_DATE}")
print(f"Timezone            : {TIMEZONE}")
print(f"Expected CAMS slots : {len(EXPECTED_AIR_TIMES)}")
print(f"Expected weather   : {len(EXPECTED_WEATHER_TIMES)}")
print(f"Weather model       : {WEATHER_MODEL}")


# ============================================================
# 4. REQUEST AIR QUALITY DATA - CAMS GLOBAL
# ============================================================

air_params = {
    "latitude": ",".join(
        str(x["latitude"]) for x in LOCATIONS
    ),

    "longitude": ",".join(
        str(x["longitude"]) for x in LOCATIONS
    ),

    "hourly": ",".join(AIR_VARIABLES),

    "start_date": START_DATE,
    "end_date": END_DATE,

    "timezone": TIMEZONE,

    "domains": "cams_global",

    "cell_selection": "nearest"
}

air_url = build_url(
    AIR_QUALITY_URL,
    air_params
)

air_responses = normalize_response(
    fetch_json(air_url, "CAMS GLOBAL AIR QUALITY")
)


# ============================================================
# 5. REQUEST METEOROLOGICAL DATA
# ============================================================

weather_params = {
    "latitude": ",".join(
        str(x["latitude"]) for x in LOCATIONS
    ),

    "longitude": ",".join(
        str(x["longitude"]) for x in LOCATIONS
    ),

    "hourly": ",".join(WEATHER_VARIABLES),

    "start_date": START_DATE,
    "end_date": END_DATE,

    "timezone": TIMEZONE,

    "models": WEATHER_MODEL,

    "wind_speed_unit": "ms"
}

weather_url = build_url(
    WEATHER_URL,
    weather_params
)

weather_responses = normalize_response(
    fetch_json(weather_url, "HISTORICAL FORECAST")
)


# ============================================================
# 6. VALIDATE RESPONSE COUNTS
# ============================================================

if len(air_responses) != len(LOCATIONS):
    raise RuntimeError(
        "CAMS response count does not match location count."
    )

if len(weather_responses) != len(LOCATIONS):
    raise RuntimeError(
        "Weather response count does not match location count."
    )


# ============================================================
# 7. PROCESS EACH LOCATION
# ============================================================

summary_rows = []
combined_rows = []

cams_grids = set()
weather_grids = set()

for i, location in enumerate(LOCATIONS):

    air = air_responses[i]
    weather = weather_responses[i]

    air_hourly = air.get("hourly", {})
    weather_hourly = weather.get("hourly", {})

    air_times = air_hourly.get("time", [])
    weather_times = weather_hourly.get("time", [])

    if not air_times:
        raise RuntimeError(
            f"No CAMS timestamps for {location['name']}"
        )

    if not weather_times:
        raise RuntimeError(
            f"No weather timestamps for {location['name']}"
        )

    # Returned model grid coordinates
    cams_lat = air.get("latitude")
    cams_lon = air.get("longitude")

    weather_lat = weather.get("latitude")
    weather_lon = weather.get("longitude")

    cams_grid = (
        round(cams_lat, 5),
        round(cams_lon, 5)
    )

    weather_grid = (
        round(weather_lat, 5),
        round(weather_lon, 5)
    )

    cams_grids.add(cams_grid)
    weather_grids.add(weather_grid)

    # Extract variables
    pm25 = get_series(air_hourly, "pm2_5")
    co = get_series(air_hourly, "carbon_monoxide")

    wind_speed = get_series(
        weather_hourly, "wind_speed_10m"
    )

    wind_direction = get_series(
        weather_hourly, "wind_direction_10m"
    )

    blh = get_series(
        weather_hourly, "boundary_layer_height"
    )

    # Build timestamp indexes
    air_index = {
        timestamp: idx
        for idx, timestamp in enumerate(air_times)
    }

    weather_index = {
        timestamp: idx
        for idx, timestamp in enumerate(weather_times)
    }

    # Expected timestamp coverage
    air_present = sum(
        timestamp in air_index
        for timestamp in EXPECTED_AIR_TIMES
    )

    weather_present = sum(
        timestamp in weather_index
        for timestamp in EXPECTED_WEATHER_TIMES
    )

    # CAMS completeness
    pm25_valid = sum(
        timestamp in air_index
        and is_valid(
            safe_get(pm25, air_index[timestamp])
        )
        for timestamp in EXPECTED_AIR_TIMES
    )

    co_valid = sum(
        timestamp in air_index
        and is_valid(
            safe_get(co, air_index[timestamp])
        )
        for timestamp in EXPECTED_AIR_TIMES
    )

    # Weather completeness
    def weather_valid_count(variable):
        return sum(
            timestamp in weather_index
            and is_valid(
                safe_get(
                    variable,
                    weather_index[timestamp]
                )
            )
            for timestamp in EXPECTED_WEATHER_TIMES
        )

    ws_valid = weather_valid_count(wind_speed)
    wd_valid = weather_valid_count(wind_direction)
    blh_valid = weather_valid_count(blh)

    # Matched CAMS and meteorological observations
    joint_pm25_weather = 0
    joint_pm25_co_weather = 0

    for timestamp in EXPECTED_AIR_TIMES:

        if timestamp not in air_index:
            continue

        if timestamp not in weather_index:
            continue

        ai = air_index[timestamp]
        wi = weather_index[timestamp]

        meteo_complete = (
            is_valid(safe_get(wind_speed, wi))
            and is_valid(safe_get(wind_direction, wi))
            and is_valid(safe_get(blh, wi))
        )

        pm25_available = is_valid(
            safe_get(pm25, ai)
        )

        co_available = is_valid(
            safe_get(co, ai)
        )

        if pm25_available and meteo_complete:
            joint_pm25_weather += 1

        if (
            pm25_available
            and co_available
            and meteo_complete
        ):
            joint_pm25_co_weather += 1

    # Distance between CAMS and weather grid centers
    weather_distance = haversine(
        cams_lat,
        cams_lon,
        weather_lat,
        weather_lon
    )

    # Interval diagnostics
    air_interval = detect_intervals(air_times)
    weather_interval = detect_intervals(weather_times)

    # Print results
    print("\n" + "=" * 65)
    print(f"CITY: {location['name'].upper()}")
    print("=" * 65)

    print(
        f"CAMS grid: "
        f"{cams_lat}, {cams_lon}"
    )

    print(
        f"Weather grid: "
        f"{weather_lat}, {weather_lon}"
    )

    print(
        f"CAMS-weather grid distance: "
        f"{weather_distance:.2f} km"
    )

    print(
        f"CAMS timestamps: "
        f"{len(air_times)} returned / "
        f"{len(EXPECTED_AIR_TIMES)} expected"
    )

    print(
        f"CAMS intervals: {air_interval}"
    )

    print(
        f"Weather timestamps: "
        f"{len(weather_times)} returned / "
        f"{len(EXPECTED_WEATHER_TIMES)} expected"
    )

    print(
        f"Weather intervals: {weather_interval}"
    )

    print("\n--- DATA COMPLETENESS ---")

    print(
        f"PM2.5: {pm25_valid}/"
        f"{len(EXPECTED_AIR_TIMES)} "
        f"({percentage(pm25_valid, len(EXPECTED_AIR_TIMES)):.2f}%)"
    )

    print(
        f"CO: {co_valid}/"
        f"{len(EXPECTED_AIR_TIMES)} "
        f"({percentage(co_valid, len(EXPECTED_AIR_TIMES)):.2f}%)"
    )

    print(
        f"Wind Speed: {ws_valid}/"
        f"{len(EXPECTED_WEATHER_TIMES)} "
        f"({percentage(ws_valid, len(EXPECTED_WEATHER_TIMES)):.2f}%)"
    )

    print(
        f"Wind Direction: {wd_valid}/"
        f"{len(EXPECTED_WEATHER_TIMES)} "
        f"({percentage(wd_valid, len(EXPECTED_WEATHER_TIMES)):.2f}%)"
    )

    print(
        f"BLH: {blh_valid}/"
        f"{len(EXPECTED_WEATHER_TIMES)} "
        f"({percentage(blh_valid, len(EXPECTED_WEATHER_TIMES)):.2f}%)"
    )

    print("\n--- TIMESTAMP ALIGNMENT ---")

    print(
        f"PM2.5 + all meteorology: "
        f"{joint_pm25_weather}/"
        f"{len(EXPECTED_AIR_TIMES)} "
        f"({percentage(joint_pm25_weather, len(EXPECTED_AIR_TIMES)):.2f}%)"
    )

    print(
        f"PM2.5 + CO + all meteorology: "
        f"{joint_pm25_co_weather}/"
        f"{len(EXPECTED_AIR_TIMES)} "
        f"({percentage(joint_pm25_co_weather, len(EXPECTED_AIR_TIMES)):.2f}%)"
    )

    # Save summary
    summary_rows.append({
        "city": location["name"],

        "cams_latitude": cams_lat,
        "cams_longitude": cams_lon,

        "weather_latitude": weather_lat,
        "weather_longitude": weather_lon,

        "weather_grid_distance_km": round(
            weather_distance, 2
        ),

        "cams_timestamps_returned": len(air_times),
        "cams_expected_timestamps": len(EXPECTED_AIR_TIMES),
        "cams_expected_timestamps_present": air_present,
        "cams_intervals": air_interval,

        "pm25_valid": pm25_valid,
        "pm25_coverage_pct": round(
            percentage(pm25_valid, len(EXPECTED_AIR_TIMES)), 2
        ),

        "co_valid": co_valid,
        "co_coverage_pct": round(
            percentage(co_valid, len(EXPECTED_AIR_TIMES)), 2
        ),

        "weather_timestamps_returned": len(weather_times),
        "weather_expected_timestamps": len(EXPECTED_WEATHER_TIMES),
        "weather_expected_timestamps_present": weather_present,
        "weather_intervals": weather_interval,

        "wind_speed_valid": ws_valid,
        "wind_speed_coverage_pct": round(
            percentage(ws_valid, len(EXPECTED_WEATHER_TIMES)), 2
        ),

        "wind_direction_valid": wd_valid,
        "wind_direction_coverage_pct": round(
            percentage(wd_valid, len(EXPECTED_WEATHER_TIMES)), 2
        ),

        "blh_valid": blh_valid,
        "blh_coverage_pct": round(
            percentage(blh_valid, len(EXPECTED_WEATHER_TIMES)), 2
        ),

        "joint_pm25_meteorology": joint_pm25_weather,
        "joint_pm25_meteorology_pct": round(
            percentage(
                joint_pm25_weather,
                len(EXPECTED_AIR_TIMES)
            ), 2
        ),

        "joint_pm25_co_meteorology": joint_pm25_co_weather
    })

    # Export aligned pilot dataset using CAMS 3-hour timestamps
    for timestamp in EXPECTED_AIR_TIMES:

        ai = air_index.get(timestamp)
        wi = weather_index.get(timestamp)

        combined_rows.append({
            "city": location["name"],
            "timestamp": timestamp,

            "cams_grid_latitude": cams_lat,
            "cams_grid_longitude": cams_lon,

            "weather_grid_latitude": weather_lat,
            "weather_grid_longitude": weather_lon,

            "pm2_5": (
                safe_get(pm25, ai)
                if ai is not None else None
            ),

            "carbon_monoxide": (
                safe_get(co, ai)
                if ai is not None else None
            ),

            "wind_speed_10m": (
                safe_get(wind_speed, wi)
                if wi is not None else None
            ),

            "wind_direction_10m": (
                safe_get(wind_direction, wi)
                if wi is not None else None
            ),

            "boundary_layer_height": (
                safe_get(blh, wi)
                if wi is not None else None
            )
        })


# ============================================================
# 8. GRID UNIQUENESS CHECK
# ============================================================

print("\n" + "=" * 65)
print("GRID UNIQUENESS CHECK")
print("=" * 65)

print(f"Unique CAMS grids: {len(cams_grids)}")
print(f"Unique weather grids: {len(weather_grids)}")

for grid in sorted(cams_grids):
    print(f"CAMS: {grid}")

for grid in sorted(weather_grids):
    print(f"Weather: {grid}")


# ============================================================
# 9. EXPORT SUMMARY CSV
# ============================================================

if summary_rows:
    with open(
        SUMMARY_FILE,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=summary_rows[0].keys()
        )

        writer.writeheader()
        writer.writerows(summary_rows)


# ============================================================
# 10. EXPORT ALIGNED PILOT DATA CSV
# ============================================================

if combined_rows:
    with open(
        DATA_FILE,
        "w",
        newline="",
        encoding="utf-8-sig"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=combined_rows[0].keys()
        )

        writer.writeheader()
        writer.writerows(combined_rows)


# ============================================================
# 11. FINAL STATUS
# ============================================================

print("\n" + "=" * 65)
print("FINAL DATA AVAILABILITY TEST")
print("=" * 65)

print(f"Total locations: {len(LOCATIONS)}")
print(f"Unique CAMS grids: {len(cams_grids)}")
print(f"Unique weather grids: {len(weather_grids)}")

print(f"\nSummary CSV: {SUMMARY_FILE}")
print(f"Pilot data CSV: {DATA_FILE}")

print("\nIMPORTANT:")
print("- Coverage percentages use expected timestamps as denominator.")
print("- CAMS expected resolution: 3 hours.")
print("- Weather expected resolution: 1 hour.")
print("- Joint coverage uses exact matching timestamps.")
print("- Main pipeline has not been modified.")

print("\nTEST COMPLETED.")
