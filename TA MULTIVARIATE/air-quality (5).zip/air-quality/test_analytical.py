"""
KALTIM ANALYTICAL FEASIBILITY TEST
==================================
Input:
    pilot_data_kaltim_oct_2026.csv

Scope:
    1. Data quality and timestamp checks
    2. Descriptive statistics by city
    3. Spearman correlations:
       PM2.5 and CO versus Wind Speed, BLH, and a simplified
       Ventilation Coefficient proxy
    4. Wind rose charts for each city
    5. Scatter plots for PM2.5 versus meteorological variables

This is a standalone exploratory script.
It does NOT modify the main Air Quality pipeline.

Dependencies:
    pip install pandas numpy scipy matplotlib
"""

from pathlib import Path
import sys
import math
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import spearmanr


# ============================================================
# 1. CONFIGURATION
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

if len(sys.argv) > 1:
    INPUT_FILE = Path(sys.argv[1])
    if not INPUT_FILE.is_absolute():
        INPUT_FILE = BASE_DIR / INPUT_FILE
else:
    INPUT_FILE = BASE_DIR / "pilot_data_kaltim_oct_2026.csv"

OUTPUT_DIR = BASE_DIR / "analytical_feasibility_outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

POLLUTANTS = {
    "pm2_5": "PM2.5",
    "carbon_monoxide": "CO",
}

METEOROLOGY = {
    "wind_speed_10m": "Wind Speed 10m",
    "boundary_layer_height": "Boundary Layer Height",
    "vc_proxy_m2_s": "Ventilation Coefficient Proxy",
}

REQUIRED_COLUMNS = [
    "city",
    "timestamp",
    "pm2_5",
    "carbon_monoxide",
    "wind_speed_10m",
    "wind_direction_10m",
    "boundary_layer_height",
]

# Wind direction sectors: meteorological convention
COMPASS_16 = [
    "N", "NNE", "NE", "ENE",
    "E", "ESE", "SE", "SSE",
    "S", "SSW", "SW", "WSW",
    "W", "WNW", "NW", "NNW",
]

# Wind speed classes (m/s) for wind rose
WIND_SPEED_EDGES = [1, 2, 4, 6]
WIND_SPEED_LABELS = ["<1", "1–2", "2–4", "4–6", "≥6"]


# ============================================================
# 2. HELPER FUNCTIONS
# ============================================================

def spearman_strength(rho):
    """Descriptive strength labels; thresholds are heuristic."""
    if pd.isna(rho):
        return "Not available"

    value = abs(rho)

    if value < 0.20:
        strength = "Very weak"
    elif value < 0.40:
        strength = "Weak"
    elif value < 0.60:
        strength = "Moderate"
    elif value < 0.80:
        strength = "Strong"
    else:
        strength = "Very strong"

    direction = "positive" if rho > 0 else "negative" if rho < 0 else "neutral"
    return f"{strength} {direction}"


def safe_spearman(x, y):
    """Return Spearman rho and p-value, handling invalid/constant series."""
    pair = pd.DataFrame({"x": x, "y": y}).dropna()

    if len(pair) < 3:
        return len(pair), np.nan, np.nan

    if pair["x"].nunique() < 2 or pair["y"].nunique() < 2:
        return len(pair), np.nan, np.nan

    result = spearmanr(pair["x"], pair["y"])
    return len(pair), float(result.statistic), float(result.pvalue)


def direction_sector(direction_degrees):
    """Map meteorological direction (wind FROM) to one of 16 sectors."""
    angle = float(direction_degrees) % 360
    index = int(((angle + 11.25) % 360) // 22.5)
    return COMPASS_16[index]


def add_timestamp_diagnostics(data):
    rows = []

    for city, group in data.groupby("city"):
        timestamps = (
            pd.to_datetime(group["timestamp"])
            .sort_values()
            .drop_duplicates()
        )

        diffs = timestamps.diff().dropna().dt.total_seconds() / 3600
        interval_counts = diffs.value_counts().sort_index()

        interval_text = (
            "; ".join(
                f"{int(hours)}h: {int(count)}"
                for hours, count in interval_counts.items()
            )
            if len(interval_counts)
            else "Insufficient timestamps"
        )

        rows.append({
            "city": city,
            "rows": len(group),
            "unique_timestamps": group["timestamp"].nunique(),
            "duplicate_timestamp_rows": int(group["timestamp"].duplicated().sum()),
            "first_timestamp": timestamps.min() if len(timestamps) else None,
            "last_timestamp": timestamps.max() if len(timestamps) else None,
            "observed_intervals": interval_text,
            "missing_pm25": int(group["pm2_5"].isna().sum()),
            "missing_co": int(group["carbon_monoxide"].isna().sum()),
            "missing_wind_speed": int(group["wind_speed_10m"].isna().sum()),
            "missing_wind_direction": int(group["wind_direction_10m"].isna().sum()),
            "missing_blh": int(group["boundary_layer_height"].isna().sum()),
        })

    return pd.DataFrame(rows)


def make_wind_rose(group, city):
    """Create a stacked wind rose using wind direction FROM and wind speed."""
    valid = group[["wind_direction_10m", "wind_speed_10m"]].dropna().copy()

    if valid.empty:
        print(f"WARNING: No valid wind data for {city}; wind rose skipped.")
        return None

    direction = valid["wind_direction_10m"].to_numpy(dtype=float) % 360
    speed = valid["wind_speed_10m"].to_numpy(dtype=float)

    # Sector 0 is North, then clockwise in 22.5-degree sectors.
    sector_index = (
        np.floor(((direction + 11.25) % 360) / 22.5).astype(int)
    )

    speed_class = np.digitize(speed, WIND_SPEED_EDGES, right=False)

    counts = np.zeros((len(WIND_SPEED_LABELS), 16), dtype=int)

    for s_idx, v_idx in zip(sector_index, speed_class):
        counts[v_idx, s_idx] += 1

    percentages = counts / len(valid) * 100

    theta = np.deg2rad(np.arange(16) * 22.5)
    width = np.deg2rad(22.5)

    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_zero_location("N")
    ax.set_theta_direction(-1)

    bottom = np.zeros(16)

    for class_index, label in enumerate(WIND_SPEED_LABELS):
        values = percentages[class_index]
        ax.bar(
            theta,
            values,
            width=width,
            bottom=bottom,
            align="center",
            label=f"{label} m/s",
            edgecolor="black",
            linewidth=0.35,
        )
        bottom += values

    ax.set_xticks(theta)
    ax.set_xticklabels(COMPASS_16)
    ax.set_title(
        f"Wind Rose — {city}\n"
        "(direction indicates where wind comes FROM)",
        pad=24,
    )
    ax.set_ylabel("Frequency (%)", labelpad=25)
    ax.legend(
        title="Wind speed",
        loc="upper left",
        bbox_to_anchor=(1.08, 1.08),
    )

    output_path = OUTPUT_DIR / f"wind_rose_{city.lower().replace(' ', '_')}.png"
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)

    # Dominant direction sector
    sector_totals = counts.sum(axis=0)
    dominant_index = int(np.argmax(sector_totals))
    dominant_sector = COMPASS_16[dominant_index]
    dominant_count = int(sector_totals[dominant_index])
    dominant_pct = dominant_count / len(valid) * 100

    return {
        "city": city,
        "valid_wind_observations": len(valid),
        "dominant_wind_from_sector": dominant_sector,
        "dominant_sector_count": dominant_count,
        "dominant_sector_pct": round(dominant_pct, 2),
        "mean_wind_speed_ms": round(valid["wind_speed_10m"].mean(), 3),
        "median_wind_speed_ms": round(valid["wind_speed_10m"].median(), 3),
        "wind_rose_file": str(output_path.name),
    }


def make_scatter(group, city, x_column, x_label, pollutant_column, pollutant_label):
    """Create one scatter plot per city and variable pair."""
    pair = group[[x_column, pollutant_column]].dropna()

    if pair.empty:
        return

    n, rho, p_value = safe_spearman(
        pair[x_column],
        pair[pollutant_column],
    )

    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.scatter(
        pair[x_column],
        pair[pollutant_column],
        alpha=0.65,
        edgecolors="none",
    )

    ax.set_xlabel(x_label)
    ax.set_ylabel(f"{pollutant_label} (µg/m³)")
    ax.set_title(f"{pollutant_label} vs {x_label} — {city}")

    if not pd.isna(rho):
        annotation = (
            f"Spearman ρ = {rho:.3f}\n"
            f"n = {n}\n"
            f"p-value = {p_value:.4g}"
        )
        ax.text(
            0.03,
            0.97,
            annotation,
            transform=ax.transAxes,
            va="top",
            bbox={"boxstyle": "round", "alpha": 0.12},
        )

    ax.grid(True, alpha=0.25)
    fig.tight_layout()

    safe_city = city.lower().replace(" ", "_")
    safe_x = x_column.replace("_", "-")
    safe_pollutant = pollutant_column.replace("_", "-")

    output_path = OUTPUT_DIR / (
        f"scatter_{safe_pollutant}_vs_{safe_x}_{safe_city}.png"
    )

    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)


# ============================================================
# 3. LOAD AND VALIDATE INPUT
# ============================================================

print("=" * 68)
print("KALTIM ANALYTICAL FEASIBILITY TEST")
print("=" * 68)

print(f"Input file : {INPUT_FILE}")
print(f"Output dir : {OUTPUT_DIR}")

if not INPUT_FILE.exists():
    raise FileNotFoundError(
        f"Input file not found: {INPUT_FILE}\n"
        "Place the CSV in the same folder as this script, "
        "or pass its path as an argument."
    )

data = pd.read_csv(INPUT_FILE)

missing_columns = [
    column for column in REQUIRED_COLUMNS
    if column not in data.columns
]

if missing_columns:
    raise ValueError(
        f"Missing required columns: {missing_columns}"
    )

data["timestamp"] = pd.to_datetime(
    data["timestamp"],
    errors="coerce",
)

numeric_columns = [
    "pm2_5",
    "carbon_monoxide",
    "wind_speed_10m",
    "wind_direction_10m",
    "boundary_layer_height",
]

for column in numeric_columns:
    data[column] = pd.to_numeric(
        data[column],
        errors="coerce",
    )

data = data.dropna(subset=["city", "timestamp"]).copy()
data = data.sort_values(["city", "timestamp"]).reset_index(drop=True)

# Simplified ventilation coefficient proxy:
# 10 m wind speed multiplied by boundary layer height.
# This is an exploratory proxy, not a full atmospheric ventilation diagnosis.
data["vc_proxy_m2_s"] = (
    data["wind_speed_10m"]
    * data["boundary_layer_height"]
)

print(f"\nTotal rows : {len(data)}")
print(f"Cities     : {', '.join(sorted(data['city'].unique()))}")
print(f"Period     : {data['timestamp'].min()} to {data['timestamp'].max()}")


# ============================================================
# 4. DATA QUALITY AND TIMESTAMP DIAGNOSTICS
# ============================================================

quality = add_timestamp_diagnostics(data)
quality.to_csv(
    OUTPUT_DIR / "data_quality_diagnostics.csv",
    index=False,
)

print("\n--- DATA QUALITY / TIMESTAMP ---")
print(quality.to_string(index=False))


# ============================================================
# 5. DESCRIPTIVE STATISTICS
# ============================================================

summary_variables = [
    "pm2_5",
    "carbon_monoxide",
    "wind_speed_10m",
    "wind_direction_10m",
    "boundary_layer_height",
    "vc_proxy_m2_s",
]

descriptive = (
    data.groupby("city")[summary_variables]
    .agg(["count", "mean", "median", "std", "min", "max"])
)

descriptive.columns = [
    f"{variable}_{stat}"
    for variable, stat in descriptive.columns
]

descriptive = descriptive.reset_index()

descriptive.to_csv(
    OUTPUT_DIR / "descriptive_summary_by_city.csv",
    index=False,
)

print("\n--- DESCRIPTIVE SUMMARY ---")
print(descriptive.round(3).to_string(index=False))


# ============================================================
# 6. SPEARMAN CORRELATION
# ============================================================

correlation_rows = []

for city, group in data.groupby("city"):

    for pollutant_column, pollutant_label in POLLUTANTS.items():

        for met_column, met_label in METEOROLOGY.items():

            n, rho, p_value = safe_spearman(
                group[pollutant_column],
                group[met_column],
            )

            correlation_rows.append({
                "city": city,
                "pollutant": pollutant_label,
                "meteorological_variable": met_label,
                "n_pairs": n,
                "spearman_rho": rho,
                "p_value": p_value,
                "strength_interpretation": spearman_strength(rho),
                "p_below_0_05_descriptive_only": (
                    bool(p_value < 0.05)
                    if not pd.isna(p_value)
                    else None
                ),
            })

correlations = pd.DataFrame(correlation_rows)

correlations.to_csv(
    OUTPUT_DIR / "spearman_correlation_results.csv",
    index=False,
)

print("\n--- SPEARMAN CORRELATION ---")
print(
    correlations[
        [
            "city",
            "pollutant",
            "meteorological_variable",
            "n_pairs",
            "spearman_rho",
            "p_value",
            "strength_interpretation",
        ]
    ].round(4).to_string(index=False)
)


# ============================================================
# 7. WIND ROSE AND WIND DIRECTION SUMMARY
# ============================================================

wind_rows = []

for city, group in data.groupby("city"):
    result = make_wind_rose(group, city)

    if result is not None:
        wind_rows.append(result)

wind_summary = pd.DataFrame(wind_rows)

wind_summary.to_csv(
    OUTPUT_DIR / "wind_direction_summary.csv",
    index=False,
)

print("\n--- WIND DIRECTION SUMMARY ---")
if not wind_summary.empty:
    print(wind_summary.to_string(index=False))


# ============================================================
# 8. SCATTER PLOTS
# ============================================================

scatter_variables = [
    ("wind_speed_10m", "Wind Speed 10m (m/s)"),
    ("boundary_layer_height", "Boundary Layer Height (m)"),
    ("vc_proxy_m2_s", "Ventilation Coefficient Proxy (m²/s)"),
]

for city, group in data.groupby("city"):

    for pollutant_column, pollutant_label in POLLUTANTS.items():

        for met_column, met_label in scatter_variables:

            make_scatter(
                group=group,
                city=city,
                x_column=met_column,
                x_label=met_label,
                pollutant_column=pollutant_column,
                pollutant_label=pollutant_label,
            )


# ============================================================
# 9. METHODOLOGICAL NOTES
# ============================================================

notes = """KALTIM ANALYTICAL FEASIBILITY TEST
==================================

Input:
- Pilot dataset for October 2026
- Three locations: Samarinda, Balikpapan, Bontang
- Expected CAMS analysis interval: 3 hours

Outputs:
- data_quality_diagnostics.csv
- descriptive_summary_by_city.csv
- spearman_correlation_results.csv
- wind_direction_summary.csv
- Wind rose PNG files
- Scatter plot PNG files

Interpretation cautions:
1. Spearman correlation describes monotonic association, not causation.
2. Time-series observations may be autocorrelated. Ordinary Spearman p-values
   do not correct for temporal autocorrelation and should be treated as
   descriptive/exploratory, not definitive significance tests.
3. Wind direction follows meteorological convention: it indicates the
   direction FROM which the wind comes. The downwind direction is opposite.
4. VC proxy = Wind Speed at 10 m x Boundary Layer Height.
   It is a simplified indicator, not a complete atmospheric ventilation
   calculation using wind speed averaged through the boundary layer.
5. CAMS is model output, not an independent ground measurement.
6. Correlation between PM2.5 and meteorology does not prove dispersion.
7. Regional transport requires spatial-temporal evidence across distinct
   grid cells and consistency with wind direction and timing.
8. Three-hour sampling can miss shorter-lived atmospheric variations.

This script does not modify the main data pipeline.
"""

(OUTPUT_DIR / "interpretation_notes.txt").write_text(
    notes,
    encoding="utf-8",
)


# ============================================================
# 10. FINAL STATUS
# ============================================================

print("\n" + "=" * 68)
print("ANALYTICAL FEASIBILITY TEST COMPLETED")
print("=" * 68)

print(f"Output directory: {OUTPUT_DIR}")
print("\nGenerated files:")

for output_file in sorted(OUTPUT_DIR.iterdir()):
    print(f"- {output_file.name}")

print("\nIMPORTANT:")
print("- Correlation is association, not causation.")
print("- Wind direction is the direction FROM which wind comes.")
print("- VC is a simplified proxy.")
print("- Regional transport is NOT tested by this script.")
print("- Main pipeline has NOT been modified.")
