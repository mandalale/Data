# Automatic Historical Gap Recovery

This update adds automatic recovery for missing hourly records in
`staging.air_quality_raw`.

## What changes

1. The Airflow scheduler container runs `recover_air_quality_gaps.py` before
   starting the scheduler process.
2. The startup wrapper then queues one `air_quality_end_to_end` DAG run so the
   clean staging table, warehouse, data-quality checks, ML forecast and CAMS
   forecast refresh immediately after startup.
3. Every regular DAG run (still every three hours) starts with the same gap
   recovery task. This catches gaps created by a missed API call while Docker
   remains running.
4. The recovery scans from `GAP_RECOVERY_START_DATE` (default `2026-01-01`) to
   the latest common complete historical date returned by Open-Meteo for all
   selected cities.
5. It compares the expected hourly timestamps with the actual timestamps in
   PostgreSQL. It checks gaps in the middle of the date range, not only after
   the latest timestamp.
6. It requests only city-month ranges that contain a missing timestamp or
   an existing row whose `pm10`, `carbon_monoxide`, or `nitrogen_dioxide`
   value is NULL.
7. Missing timestamps are inserted with the complete API payload. For existing
   timestamps, recovery fills only NULL values in those three selected
   predictors; existing PM2.5 and all other populated values are preserved.

The Airflow schedule remains `0 */3 * * *` (every three hours). The recovery
process does not change the schedule or the hourly timestamp resolution.

## Files added or changed

- `airflow/dags/scripts/recover_air_quality_gaps.py`: detects missing timestamps
  and NULL PM10/CO/NO2 values, validates CAMS Global responses, and performs
  advisory-lock-protected idempotent repair.
- `airflow/dags/scripts/backfill_air_quality_history.py`: historical backfill
  now recognizes NULL PM10/CO/NO2 values even when timestamps already exist.
- `airflow/dags/scripts/start_airflow_scheduler.sh` (new): runs startup recovery,
  queues the startup DAG run, then starts the scheduler.
- `airflow/dags/air_quality_pipeline.py` (changed): adds
  `recover_historical_gaps` as the first task and sets `max_active_runs=1`.
- `docker-compose.yml` (changed): configures the Airflow API base URL and
  healthcheck, and starts the scheduler through the wrapper.

## Apply the patch

1. Back up the existing project folder.
2. Extract the patch ZIP into the project root and allow it to overwrite the
   two changed existing files. Keep the current `.env` file.
3. Validate the Compose file:

   ```powershell
   docker compose config
   ```

4. Recreate the Airflow components affected by this change:

   ```powershell
   docker compose up -d --force-recreate airflow-api-server airflow-dag-processor airflow-scheduler
   ```

   Compose will also start required dependencies if they are stopped.
5. Follow startup recovery and scheduler logs:

   ```powershell
   docker compose logs -f airflow-scheduler
   ```

## Manual dry-run

Run this only when no other recovery task is currently executing. The dry-run
still connects to PostgreSQL and checks the existing timestamps, but it does
not insert records.

```powershell
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/recover_air_quality_gaps.py --dry-run
```

To test a restricted date range:

```powershell
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/recover_air_quality_gaps.py --start-date 2026-01-01 --end-date 2026-01-31 --dry-run
```

## Verify the raw table

The query below checks the number of rows and unique hourly timestamps per
city for the requested period:

```powershell
docker compose exec postgres psql -U platform -d air_quality_dw -P pager=off -c "SELECT city, COUNT(*) AS rows, COUNT(DISTINCT valid_at) AS unique_hours, MIN(valid_at) AS first_timestamp, MAX(valid_at) AS last_timestamp FROM staging.air_quality_raw WHERE valid_at >= TIMESTAMP '2026-01-01' AND valid_at < TIMESTAMP '2026-11-12' GROUP BY city ORDER BY city;"
```

## Operational behavior and safeguards

- `UNIQUE (city, valid_at)` remains the record identity.
- Recovery uses `ON CONFLICT (city, valid_at) DO UPDATE` with NULL-only
  enrichment for PM10, CO, and NO2. It preserves all already-populated values.
- A PostgreSQL session-level advisory lock prevents startup recovery and a
  scheduled recovery task from modifying the same target concurrently.
- Each city-month write commits independently. A failed month does not undo
  successfully recovered months. A later run safely retries remaining gaps.
- API requests use retry/backoff for temporary HTTP errors.
- If startup recovery fails, the wrapper logs the failure but still starts
  Airflow. The scheduled DAG recovery task can retry on its next run.
- `max_active_runs=1` prevents overlapping end-to-end DAG runs from rebuilding
  clean staging and warehouse tables concurrently.
- The startup DAG trigger occurs on each scheduler container start, even when
  no historical gap exists. This refreshes downstream layers and forecasts.
- Recovery repairs missing timestamp rows and enriches existing rows where
  PM10, CO, or NO2 is NULL. It does not overwrite non-NULL values and does not
  synthesize values when Open-Meteo itself returns NULL.
- If Open-Meteo returns NULL for one of the three selected predictors, that
  value remains NULL and is reported in `source_null_values`; a later recovery
  run may retry the city-month.

## Important source-data note

The API request uses `domains=cams_global`, the same source domain as the
existing historical backfill. It requests all seven existing raw-layer
parameters. Timestamp completeness is checked independently for each city.
