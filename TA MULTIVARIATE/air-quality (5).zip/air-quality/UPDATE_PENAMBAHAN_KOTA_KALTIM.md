# Update Penambahan Kota Kalimantan Timur

## Tujuan

Menambahkan Samarinda, Balikpapan, dan Bontang ke konfigurasi proyek tanpa menghapus Semarang, Jakarta, Bandung, Surabaya, atau Yogyakarta.

Total konfigurasi kota batch menjadi delapan kota.

## Koordinat yang ditambahkan

| Kota | Latitude | Longitude |
|---|---:|---:|
| Samarinda | -0.5022 | 117.1536 |
| Balikpapan | -1.2675 | 116.8289 |
| Bontang | 0.1324 | 117.4854 |

Koordinat request dipertahankan sesuai koordinat yang diberikan. Open-Meteo/CAMS dapat mengembalikan grid center terdekat; grid center hasil validasi disimpan sebagai hasil validasi spasial, bukan menggantikan koordinat request di konfigurasi.

## File yang diperbarui

- `airflow/dags/air_quality_pipeline.py`
- `airflow/dags/meteorology_pipeline.py`
- `airflow/dags/scripts/backfill_air_quality_history.py`
- `airflow/dags/scripts/backfill_pm25_history.py`
- `airflow/dags/scripts/recover_air_quality_gaps.py`
- `spark/jobs/air_quality_cams_forecast.py`
- `simulator/sensor_simulator.py` (hanya untuk konsistensi simulator)
- `spark/jobs/stream_clean_sensor.py` (normalisasi nama dan koordinat simulator)

Semua lima kota lama tetap ada. Tidak ada perintah DELETE, TRUNCATE, atau penghapusan data historis yang ditambahkan.

## Mengisi data historis kualitas udara

Setelah menjalankan ulang/redeploy container agar kode DAG dan script terbaru terbaca:

1. Pastikan Batch Processing dalam keadaan ON.
2. Jalankan dry-run untuk tiga kota baru:

```bash
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/backfill_air_quality_history.py \
  --city Samarinda --city Balikpapan --city Bontang --dry-run
```

3. Jika validasi API berhasil, jalankan backfill sebenarnya (tanpa `--dry-run`):

```bash
docker compose exec airflow-scheduler python /opt/airflow/dags/scripts/backfill_air_quality_history.py \
  --city Samarinda --city Balikpapan --city Bontang
```

Tanggal awal default script adalah `2026-01-01`. Jika `--end-date` tidak diberikan, script mencari tanggal historis terbaru yang lengkap untuk kota-kota yang dipilih. Proses menggunakan UPSERT dan pemeriksaan kelengkapan city-month; tidak perlu memakai `--force` untuk pengisian awal.

## Mengisi data meteorologi

Setelah backfill kualitas udara berhasil, jalankan DAG `meteorology_historical_backfill` secara manual melalui Airflow UI. DAG mengambil rentang tanggal dari `staging.air_quality_raw` dan memproses seluruh delapan kota yang terkonfigurasi.

Periksa task data quality check. Implementasi saat ini mengharapkan cakupan seluruh kota yang terkonfigurasi.

## Verifikasi setelah backfill

Periksa jumlah kota, rentang waktu, dan kelengkapan per kota:

```sql
SELECT city,
       COUNT(*) AS rows,
       MIN(valid_at) AS first_timestamp,
       MAX(valid_at) AS last_timestamp,
       COUNT(pm2_5) AS pm25_non_null,
       COUNT(pm10) AS pm10_non_null,
       COUNT(carbon_monoxide) AS co_non_null,
       COUNT(nitrogen_dioxide) AS no2_non_null
FROM staging.air_quality_raw
GROUP BY city
ORDER BY city;
```

Untuk warehouse meteorologi:

```sql
SELECT l.city,
       COUNT(*) AS rows,
       MIN(t.valid_at) AS first_timestamp,
       MAX(t.valid_at) AS last_timestamp,
       COUNT(f.wind_speed_10m) AS wind_speed_non_null,
       COUNT(f.wind_direction_10m) AS wind_direction_non_null,
       COUNT(f.boundary_layer_height) AS blh_non_null
FROM warehouse.fact_meteorology f
JOIN warehouse.dim_location l USING (location_key)
JOIN warehouse.dim_time t USING (time_key)
GROUP BY l.city
ORDER BY l.city;
```

## Batasan eksekusi

ZIP ini berisi perubahan source code dan instruksi backfill. Backfill aktual belum dijalankan dari sini karena memerlukan koneksi ke PostgreSQL dan lingkungan Docker Compose milik proyek. Setelah kode diterapkan di lingkungan tersebut, jalankan perintah di atas untuk mengambil dan menyimpan data Open-Meteo yang sebenarnya.
